<?php
$v = $_REQUEST['v'];
$play = $_REQUEST['autoplay'];
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Video Player - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--FACEBOOK SETTINGS ->
        <!--FACEBOOK SETTINGS ENDS -->
        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/jquery.videocontrols.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
        <style>
            body,html{
                overflow:hidden;
            }
        </style>
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
        <script>
	if (typeof window.console == 'undefined') {
		window.console = {log:function() {}};
	}	
	</script>
	
	<script src="build/jquery.js"></script>
	<script src="src/js/me-namespace.js" type="text/javascript"></script>
	<script src="src/js/me-utility.js" type="text/javascript"></script>
	<script src="src/js/me-i18n.js" type="text/javascript"></script>
	<script src="src/js/me-plugindetector.js" type="text/javascript"></script>
	<script src="src/js/me-featuredetection.js" type="text/javascript"></script>
	<script src="src/js/me-mediaelements.js" type="text/javascript"></script>
	<script src="src/js/me-shim.js" type="text/javascript"></script>
	
	<script src="src/js/mep-library.js" type="text/javascript"></script>
	<script src="src/js/mep-player.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-playpause.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-progress.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-time.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-speed.js" type="text/javascript"></script>	
	<script src="src/js/mep-feature-tracks.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-volume.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-stop.js" type="text/javascript"></script>
	<script src="src/js/mep-feature-fullscreen.js" type="text/javascript"></script>
	<link rel="stylesheet" href="src/css/mediaelementplayer.css" />
	<link rel="stylesheet" href="src/css/mejs-skins.css" />	

</head>
<body>

	<video width="100%" height="100%" id="player1" controls="controls" preload="none">
            <source src="<?php echo $v ?>"  type="video/mp4" />
	</video>
        <a class="videoImg"><img src="../images/mf.jpg" alt=""/></a>


<script  type="text/javascript">

var play = '<?php echo $play ?>';
function playm(){
    document.getElementById('player1').play();
    }

$('audio, video').bind('error', function(e) {

	//console.log('error',this, e, this.src, this.error.code);
});

jQuery(document).ready(function() {
	$('audio, video').mediaelementplayer({
		//mode: 'shim',
	
		pluginPath:'../build/', 
		enablePluginSmoothing:true,
		//duration: 489,
		//startVolume: 0.4,
		enablePluginDebug: true,
		//iPadUseNativeControls: true,
		//mode: 'shim',
		//forcePluginFullScreen: true,
		//usePluginFullScreen: true,
		//mode: 'native',
		//plugins: ['silverlight'],
		//features: ['playpause','progress','volume','speed','fullscreen'],
		success: function(me,node) {
			// report type
			var tagName = node.tagName.toLowerCase();
			$('#' + tagName + '-mode').html( me.pluginType  + ': success' + ', touch: ' + mejs.MediaFeatures.hasTouch);

			
			if (tagName === 'audio') {

				me.addEventListener('progress',function(e) {
					//console.log(e);
				}, false);
			
			}
			
			me.addEventListener('progress',function(e) {
				//console.log(e);
			}, false);
	
			
			// add events
			if (tagName === 'video' && node.id === 'player1') {
				appendMediaProperties($('#' + tagName + '-props'), me);
				appendMediaEvents($('#' + tagName + '-events'), me);
				
			}
		}		
	});
	


});



</script>


</body>
</html>