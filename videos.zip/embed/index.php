<?php
    header('../videos/allvideos/');