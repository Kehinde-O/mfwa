<?php include 'handler.php'; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <style>
            ::-moz-selection {
                background: #b3d4fc;
                text-shadow: none;
            }

            ::selection {
                background: #b3d4fc;
                text-shadow: none;
            }


            

            h1 {
                margin: 0 10px;
                font-size: 50px !important;
                font-family: 'Oswald-Bold';
                text-align: center;
            }

            h1 span {
                color: #bbb;
            }

            h3 {
                margin: 1.5em 0 0.5em;
            }

            p {
                margin: 1em 0;
            }

            ul {
                padding: 0 0 0 40px;
                margin: 1em 0;
            }

            .container {
                max-width: 380px;
                _width: 380px;
                margin: 0 auto;
                font-size: 20px;
                padding:40px 0px;
            }

            /* google search */

            #goog-fixurl ul {
                list-style: none;
                padding: 0;
                margin: 0;
            }

            #goog-fixurl form {
                margin: 0;
            }

            #goog-wm-qt,
            #goog-wm-sb {
                border: 1px solid #bbb;
                font-size: 16px;
                line-height: normal;
                vertical-align: top;
                color: #444;
                border-radius: 2px;
            }

            #goog-wm-qt {
                width: 220px;
                height: 20px;
                padding: 5px;
                margin: 5px 10px 0 0;
                box-shadow: inset 0 1px 1px #ccc;
            }

            #goog-wm-sb {
                display: inline-block;
                height: 32px;
                padding: 0 10px;
                margin: 5px 0 0;
                white-space: nowrap;
                cursor: pointer;
                background-color: #f5f5f5;
                background-image: -webkit-linear-gradient(rgba(255,255,255,0), #f1f1f1);
                background-image: -moz-linear-gradient(rgba(255,255,255,0), #f1f1f1);
                background-image: -ms-linear-gradient(rgba(255,255,255,0), #f1f1f1);
                background-image: -o-linear-gradient(rgba(255,255,255,0), #f1f1f1);
                -webkit-appearance: none;
                -moz-appearance: none;
                appearance: none;
                *overflow: visible;
                *display: inline;
                *zoom: 1;
            }

            #goog-wm-sb:hover,
            #goog-wm-sb:focus {
                border-color: #aaa;
                box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
                background-color: #f8f8f8;
            }

            #goog-wm-qt:hover,
            #goog-wm-qt:focus {
                border-color: #105cb6;
                outline: 0;
                color: #222;
            }

            input::-moz-focus-inner {
                padding: 0;
                border: 0;
            }
        </style>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Error 404 - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <meta name="author" content="Kehinde Omotoso">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/simple-line-icon.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="fonts/font-awesome.css">
        <link rel="stylesheet" href="fonts/source-sans-pro.css">
        <link rel="stylesheet" href="css/flick.css">
        <link href="engine0/style.css" rel="stylesheet" type="text/css"/>
        <link href="engine1/style.css" rel="stylesheet" type="text/css"/>
        <link href="css/videojs.css" rel="stylesheet" type="text/css"/>
        <link href="css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.videocontrols.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="css/main.css">
        <link rel="icon ico" href="images/mf.jpg">
    </head>
    <body>
        <div class="pageloader"><img src="images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="howitworks/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><a href="join/"><span><i class="icon icon-user"></i> New Member?</span> Register</a></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <!--<div class="col-sm-4 col-xs-8 navTile animated bounceInLeft">
                    <h2>MISS <span>FASHION</span> WEEK</h2>
                    <div class="text lead">Africa Contest</div>
                </div> -->
                <ul>
                    <li><a href="" class="active">Home</a></li>
                    <li class='signMore'><a href="join/">Apply Now</a>
                        <div class="animated bounceInDown">
                            <a href="join/">CONTESTANT</a>
                            <a href='ambassador/'>AMBASSADORS </a>
                            <a href='sponsors/'>SPONSORS </a>
                            <a href='howitworks/'>HOW IT WORKS</a>
                            <a href="rules/">RULES AND REGULATIONS</a>
                            <a href="quickform/">QUICK FORM</a>
                            <a href="specs/">IMAGE AND VIDEO SPECIFICATION</a>
                        </div>
                    </li>
                    <li><a href="models/">Models</a></li>
                    <li><a href="judges/">Judges</a></li>
                    <li><a href="winners/">Winners</a></li>
                    <li><a href="about/">About Us</a></li>
                    <li><a href="blog/">Blog</a></li>
                </ul>
                <div class="drop visible-xs">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <div class="container">
            <h1>Not found <span>:(</span></h1>
            <p>Sorry, but the page you were trying to view does not exist.</p>
            <p>It looks like this was the result of either:</p>
            <ul>
                <li>a mistyped address</li>
                <li>an out-of-date link</li>
            </ul>
            <script>
                var GOOG_FIXURL_LANG = (navigator.language || '').slice(0,2),GOOG_FIXURL_SITE = location.host;
            </script>
            <script src="//linkhelp.clients.google.com/tbproxy/lh/wm/fixurl.js"></script>
        </div>
        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="email" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social">
                    <h5>Connect with us</h5>
                    <a class="social"><i class="icon icon-social-facebook"></i></a>
                    <a class="social"><i class="icon icon-social-youtube"></i></a>
                    <a class="social"><i class="icon icon-social-google"></i></a>
                    <a class="social"><i class="icon icon-social-twitter"></i></a>
                    <a class="social"><i class="icon icon-social-instagram"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if (count($blog) > 3) {
                    $count = 3;
                }

                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                ?>
            </div>
            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>


        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/flick.js"></script>
        <script src="js/plugins.js"></script>
        <script type="text/javascript" src="js/grids.js"></script>
        <script src="js/videojs.js" type="text/javascript"></script>
        <script src="engine0/wowslider.js" type="text/javascript"></script>
        <script src="engine0/script.js" type="text/javascript"></script>
        <script type="text/javascript" src="engine1/script.js"></script>
        <script src="js/jquery.vmap.js" type="text/javascript"></script>
        <script src="js/jquery.vmap.world.js" type="text/javascript"></script>
        <script src="js/jquery.videocontrols.js" type="text/javascript"></script>
        <script src="js/main.js"></script>
        <script type="text/javascript">
            $('.alv').click(function() {
                var id = $(this).attr('id');
                var action = $(this).attr('data-action');
                var email = '<?php echo $slikemail ?>';
                if (email.length > 0) {
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            $('#' + id).html('<i class="icon icon-like"></i>&nbsp;&nbsp;&nbsp; Vote ' + xhttp.responseText);
                        }
                    };
                    xhttp.open("GET", "handler.php?likevote&action=vote&contestant=" + id + "&email=" + email, true);
                    xhttp.send(null);
                }
                else {
                    $('.likevote').removeClass('bounceOutDown').addClass('bounceInUp').css('display', 'block');
                }
            });

            $('.share a').click(function() {
                var id = $(this).attr('id');
                var action = 'share';
                var href = $(this).attr('href');
                xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        $('#sharer' + id).html('<i class="icon icon-share"></i>&nbsp;&nbsp;&nbsp; Share ' + xhttp.responseText);
                    }
                };
                xhttp.open("GET", "handler.php?likevote&action=share&contestant=" + id, true);
                xhttp.send(null);
            });


            $('#subscribeButton').click(function() {
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if (name.length > 0 && email.length > 0) {
                    $('#subscribeName').css('border-color', 'green');
                    $('#subscribeMail').css('border-color', 'green');
                    if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                        xhttp.onreadystatechange = function() {
                            if (xhttp.readyState === 4 && xhttp.status === 200) {
                                $('.subs').css('display', 'block');
                            }
                        };
                        xhttp.open("GET", "handler.php?subscribe&email=" + email + "&name=" + name, true);
                        xhttp.send(null);
                    }
                    else {
                        $('#subscribeMail').css('border-color', 'red');
                    }
                }
                else {
                    $('#subscribeName').css('border-color', 'red');
                    $('#subscribeMail').css('border-color', 'red');
                }
            });
        </script>


    </body> 

    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>


    <div class="sideSocials blogSocial">
        <a class="" href="http://www.facebook.com/missfashionweekafrica"><i class="icon icon-social-facebook"></i></a>
        <a class="" href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA"><i class="icon icon-social-youtube"></i></a>
        <a class="" href="http://www.pinterest.com/missfwafrica"><i class="icon icon-social-pinterest"></i></a>
        <a class="" href="http://www.twitter.com/missfwafrica"><i class="icon icon-social-twitter"></i></a>
        <a class="" href="http://www.instagram.com/missfashionweekafrica"><i class="icon icon-social-instagram"></i></a>
        <a class="" href="http://missfashionweekafrica.tumblr.com/"><i class="icon icon-social-tumblr"></i></a>
        <?php
        $wp = new dataBaseContent();
        $wpp = $wp->webcontent();
        ?>
        <a class="" href="tel:<?php echo $wpp[0]['WHATSAPP'] ?>" title="<?php echo $wpp[0]['WHATSAPP'] ?>"><i class="fa fa-whatsapp"></i></a>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div> 
   

</html>

    </body>
</html>
