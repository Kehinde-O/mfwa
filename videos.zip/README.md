--Most front-end functions are handled in the handler.php file
--Most back-end functions are handled in the officials/server/index.php file

--Database Information localhost
	--Database name: missfw
	--Database Password: no password
	--Database Username: root
	--Database file: missfw.sql
	
	
--Database Information online
	--Database name: missfw
	--Database Password: <?php ?>
	--Database Username: fashion_missfw
	--Database file: missfw.sql
	
	

--Cpanel Information
	-- Address: http://missfashionweekafrica.com/cpanel
	-- Username: fashionweek
	-- Password: @@##Fashion1
	
--Switch database connection in file: handler.php on line  12 and 13
	--line 12 is for localhost connection
	--line 13 is for online i.e missfashionweekafrica.com connection
	--Uncomment or comment line 12 or 13 to switch