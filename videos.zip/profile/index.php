<?php
include '../handler.php';
$email = $_SESSION['useremail'];
$accountInfo = $mfdb->query("SELECT * FROM quickform where email='$email'");
$aInfo = $accountInfo->fetch_assoc();
$characters = "1234567890ABCFGHIJKLMNPQRSTVWXYZabcdfghijklmnpqrstvwxyz";
$string = '';
$max = strlen($characters) - 1;
for ($i = 0; $i < 12; $i++) {
    $string .= $characters[mt_rand(0, $max)];
}
if (mysqli_num_rows($accountInfo) > 0) {
    $userexist = true;
} else {
    $userexist = false;
}
if (!$userexist) {
    $_SESSION['loginerror'] = '<div class="text-danger">Session expired, please log in again.</div><br/>';
    header('location:../join/');
}
$getInfo = $mfdb->query("SELECT * FROM quickform where email='$email'")->fetch_assoc();
$fname = $getInfo['firstName'];
$lname = $getInfo['lastName'];
$ref = $getInfo['reference'];
$fbid = $getInfo['fbid'];
$address = $getInfo['address'];
$phone = $getInfo['phone'];
$countryy = $getInfo['country'];
$statee = $getInfo['state'];
$pwww = $getInfo['pw'];
$accountStatus = $getInfo['accountStatus'];
$accountSetup = $getInfo['accountSetup'];
$securityQuestion = $getInfo['securityQuestion'];
$securityAnswer = $getInfo['securityAnswer'];
$applied = $getInfo['applied'];
$secondmedia = $getInfo['secondmedia'];
$thirdmedia = $getInfo['thirdmedia'];
$lastmedia = $getInfo['lastmedia'];
$appprocess = $getInfo['appprocess'];
$nextdate = $getInfo['nextDate'];
$step = $getInfo['step'];
$nextmsg = $getInfo['nextMsg'];
$passs = $getInfo['password'];
//$mfdb->query("UPDATE quickform SET fbid='$fbid',firstName='$fname',lastName='$lname',address='$address',phone='$phone',country='$countryy',state='$state',reference='$ref',pw='$pwww',accountStatus='$accountStatus',accountSetup='$accountSetup',password='$passs',securityQuestion='$securityQuestion',securityAnswer='$securityAnswer',applied='$applied',secondmedia='$secondmedia',thirdmedia='$thirdmedia',lastmedia='$lastmedia',appprocess='$appprocess',nextDate='$nextdate',step='$step','nextMsg='$nextmsg' WHERE email='$email'");

if (isset($_POST['setup'])) {
    $sq = stripcslashes($_POST['sq']);
    $sa = stripcslashes($_POST['sa']);
    $epa = $_POST['password'];
    $pa = md5($_POST['password']);
    $mfdb->query("UPDATE quickform SET accountSetup='true',step='1',securityQuestion='$sq',securityAnswer='$sa',password='$pa' WHERE email='$email'");
    //$mfdb->query("UPDATE quickform SET fbid='$fbid',firstName='$fname',lastName='$lname',address='$address',phone='$phone',country='$countryy',state='$state',reference='$ref',pw='$pwww',accountStatus='$accountStatus',accountSetup='true',password='$pa',securityQuestion='$sq',securityAnswer='$sa',applied='$applied',secondmedia='$secondmedia',thirdmedia='$thirdmedia',lastmedia='$lastmedia',appprocess='$appprocess',nextDate='$nextdate',step='2','nextMsg='$nextmsg' WHERE email='$email'");
    $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $fname . ' ' . $lname . ',<br/><br/>Your change of password was successful, your new password is "<b>' . $epa . '</b>". <br/><br/>Keep this email safe, so that if you forget your password, you can always refer back to this email.<br/><br/>Have any questions? Email us at team@missfashionweekafrica.com.<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
    $headers = "From: support@missfashionweekafrica.com \r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    mail($email, 'Your change of password was successful - MissFashionWeekAfrica', $mailmsg, $headers);
    header('location:../profile/');
}
if (isset($_POST['prefiles'])) {
    echo $headshotf = $_POST['headshotf'];
    echo $fulllengths = $_POST['fulllengths'];
    echo $fulllengthf = $_POST['fulllengthf'];
    echo $headshots = $_POST['headshots'];
    $mfdb->query("UPDATE quickform SET secondmedia='true',step='3',appprocess='true' WHERE email='$email'");
    $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $fname . ' ' . $lname . ',<br/><br/>Your stage 1 photo uploads was successful, you only have 2 more steps to complete your application. <br/><br/>Within 24hrs our judges will review and score your photos. You would receive your scores through this email.  <br/><br/>Please always check your email for further instructions. <br/><br/>Have any questions? Email us at team@missfashionweekafrica.com.<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
    $headers = "From: support@missfashionweekafrica.com \r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    mail($email, 'Stage 1 submissions received - MissFashionWeekAfrica', $mailmsg, $headers);
    header('location:../profile/');
}
//simpassport
if (isset($_REQUEST['swimpassport'])) {
    $mfdb->query("UPDATE quickform SET thirdmedia='true',step='4',appprocess='true' WHERE email='$email'");
    $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $fname . ' ' . $lname . ',<br/><br/>Step 4 of 5 of your Application "Swim wear and international passport upload" was successful.<br/><br/>'
            . 'Within 24hrs our judges will review and score your submissions and you would receive your scores through this email. <br/><br/>'
            . 'Please always check your email for further instructions.<br/><br/>'
            . 'Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>'
            . 'Thanks,<br/><br/>'
            . 'Miss Fashion Week Africa.';
    $headers = "From: support@missfashionweekafrica.com \r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    mail($email, 'Step 4 of 5 Completed - MissFashionWeekAfrica', $mailmsg, $headers);
    header('location:../profile/');
}


//finalvideo
if (isset($_REQUEST['finalvideo'])) {

    $mfdb->query("UPDATE quickform SET lastmedia='true',step='5' WHERE email='$email'");
    $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $fname . ' ' . $lname . ',<br/><br/>Congratulations, Step 5 of 5 of your Application "Interview Video Upload" has been completed..<br/><br/>'
            . 'Within 24hrs our judges will review and score your submissions and you would receive your scores through this email. <br/><br/>'
            . 'Please always check your email for further instructions.<br/><br/>'
            . 'Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>'
            . 'Thanks,<br/><br/>'
            . 'Miss Fashion Week Africa.';
    $headers = "From: support@missfashionweekafrica.com \r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    mail($email, 'Congratulations, Step 5 of 5 Completed MissFashionWeekAfrica', $mailmsg, $headers);
    header('location:../profile/');
}
/* Create Profile ***********************************8/
 * 
 */
$fn = str_replace('\'', '`', $getInfo['firstName']);
$fn = str_replace('\'\'', '`', $fn);
$ln = str_replace('\'', '`', $getInfo['lastName']);
$ln = str_replace('\'\'', '`', $ln);
$nemail = str_replace('\'', '`', $getInfo['email']);
$nemail = str_replace('\'\'', '`', $nemail);
$pn = str_replace('\'', '`', filter_input(INPUT_POST, 'phoneNumber'));
$pn = str_replace('\'\'', '`', $pn);
$bust = str_replace('\'', '`', filter_input(INPUT_POST, 'bust'));
$bust = str_replace('\'\'', '`', $bust);
$waist = str_replace('\'', '`', filter_input(INPUT_POST, 'waist'));
$waist = str_replace('\'\'', '`', $waist);
$hips = str_replace('\'', '`', filter_input(INPUT_POST, 'hips'));
$hips = str_replace('\'\'', '`', $hips);
$shoe = str_replace('\'', '`', filter_input(INPUT_POST, 'shoe'));
$shoe = str_replace('\'\'', '`', $shoe);
$apn = str_replace('\'', '`', filter_input(INPUT_POST, 'aphoneNumber'));
$apn = str_replace('\'\'', '`', $apn);
$homea = str_replace('\'', '`', filter_input(INPUT_POST, 'address'));
$homea = str_replace('\'\'', '`', $homea);
$ahomea = str_replace('\'', '`', filter_input(INPUT_POST, 'aaddress'));
$ahomea = str_replace('\'\'', '`', $ahomea);
$country = str_replace('\'', '`', filter_input(INPUT_POST, 'country'));
$country = str_replace('\'\'', '`', $country);
$state = str_replace('\'', '`', filter_input(INPUT_POST, 'state'));
$state = str_replace('\'\'', '`', $state);
$city = str_replace('\'', '`', filter_input(INPUT_POST, 'city'));
$city = str_replace('\'\'', '`', $city);
$height = str_replace('\'', '`', filter_input(INPUT_POST, 'height'));
$height = str_replace('\'\'', '`', $height);
$gender = filter_input(INPUT_POST, 'gender');
$gender = str_replace('\'\'', '`', $gender);
$ageDay = filter_input(INPUT_POST, 'ageDay');
$ageDay = str_replace('\'\'', '`', $ageDay);
$ageMonth = filter_input(INPUT_POST, 'ageMonth');
$ageMonth = str_replace('\'\'', '`', $ageMonth);
$ageYear = filter_input(INPUT_POST, 'ageYear');
$ageYear = str_replace('\'\'', '`', $ageYear);
$reason = str_replace('\'', '`', filter_input(INPUT_POST, 'reason'));
$reason = str_replace('\'\'', '`', $reason);

$submit = $_POST['createProfile'];

if (isset($_POST['createProfile'])) {

    $mfdb->query("INSERT INTO application"
            . "(reference,firstName,lastName,emailAddress,phoneNumber,aphoneNumber,homeAddress,ahomeAddress,country,state,city,height,gender,applicationStatus,ageDay,ageMonth,ageYear,reason,bust,waist,hips,shoe,share,vote,judged,lastStepJudged,paid,catwalkscore,headshotscore,fulllenghtscore,swimwearscore,interviewscore,nominated,nominatedno,top20)"
            . "VALUES"
            . "('$ref','$fn','$ln','$nemail','$pn','$apn','$homea','$ahomea','$country','$state','$city','$height','$gender','uncompleted','$ageDay','$ageMonth','$ageYear','$reason','$bust','$waist','$hips','$shoe','0','0','uncompleted','0','false','0','0','0','0','0','false','0','false')");
    $mfdb->query("UPDATE quickform SET applied='true',step='2' WHERE email='$email'");
    header('location:../profile/');
}
/* Create Profile Ends **************** */


/* View Profile Begins ********************* */
$watch = '';
$dbvideos = array();
$videos = $mfdb->query("SELECT * FROM videos WHERE reference='$ref' ORDER BY id DESC");
while ($v = $videos->fetch_assoc()) {
    $dbvideos[] = array(
        'VIDEO' => $v['videoReference'],
        'NAME' => $v['videoName'],
        'DATE' => $v['date'],
        'TIME' => $v['time'],
        'LINK' => $v['shortLink']
    );
}
if (isset($_REQUEST['watch'])) {
    $watch = $_REQUEST['watch'];
} else {
    $watc = $dbvideos[0]['LINK'];
}
$dbvideos = array();
$wv = $mfdb->query("SELECT * FROM videos WHERE reference='$ref'");
while ($v = $wv->fetch_assoc()) {
    $dbvideos[] = array(
        'VIDEO' => $v['videoReference'],
        'NAME' => $v['videoName'],
        'DATE' => $v['date'],
        'VIEWS' => $v['views'],
        'LINK' => $v['shortLink']
    );
}
$pictures = array();
$pv = $mfdb->query("SELECT * FROM applicationdocuments WHERE reference='$ref'");
while ($v = $pv->fetch_assoc()) {
    $pictures[] = array(
        'PICTURE' => $v['documentReference'],
        'TYPE' => $v['documentType']
    );
}
$swimw = $mfdb->query("SELECT swimwearscore FROM application WHERE reference='$ref'");
$heads = $mfdb->query("SELECT headshotscore FROM application WHERE reference='$ref'");
$fulll = $mfdb->query("SELECT fulllenghtscore FROM application WHERE reference='$ref'");
$cat = $mfdb->query("SELECT catwalkscore FROM application WHERE reference='$ref'");
$inter = $mfdb->query("SELECT interviewscore FROM application WHERE reference='$ref'");
if (mysqli_num_rows($swimw) > 0) {
    $swimwear = $swimw->fetch_assoc();
}
if (mysqli_num_rows($heads) > 0) {
    $headshot = $heads->fetch_assoc();
}
if (mysqli_num_rows($fulll) > 0) {
    $fulllength = $fulll->fetch_assoc();
}
if (mysqli_num_rows($cat) > 0) {
    $catwalk = $cat->fetch_assoc();
}
if (mysqli_num_rows($inter) > 0) {
    $interview = $inter->fetch_assoc();
}
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Profile - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/lightgallery.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
        <style>
            .lead small{
                font-weight:bold;
                color:#888;
            }
            .pictureChoose a{
                max-height: 260px;
            }
        </style>
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader col-xs-12'>
            <h2 class='col-sm-3 col-xs-5'>PROFILE</h2>
            <div class="col-xs-5 pull-right profileName text-right"><?php echo $fname . ' ' . $lname . ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>' . $ref ?></b></div>
        </section>

        <div class="clearfix"></div>


        <div class='profile col-sm-12 col-xs-12 center-block' style="overflow:hidden">

            <?php if ($aInfo['accountSetup'] !== 'true') { ?>
                <div class="getStarted col-xs-12 animated">
                    <div class="lead text-center col-xs-6 center-block gsa">
                        Welcome <?php echo $fname . ' ' . $lname ?>
                        <a class="center-block col-xs-12 col-sm-6">Get Started</a>
                    </div>
                </div>


                <div class="paymentForm col-xs-12  animated slideInRight" style="">
                    <div class="col-xs-6 center-block gsa">
                        <div class="lead text-center">Account Setup. <small>Step 1 of 5</small><br/></div>
                        <div class="col-sm-7 col-xs-11 center-block login accountForms whiteBg no-border">
                            <form class="" action="" method="post">
                                <select class="col-xs-12" name="sq" required>
                                    <option>Select Security Question  *</option>
                                    <option>What is your first pets name</option>
                                    <option>What is your mothers maiden name</option>
                                </select>
                                <input class="col-xs-12" id="securitya" placeholder="Security Answe" type="text" name="sa" required/>
                                <div ckass="col-sm-12" style="padding:5px 0px;"><span class="passSpan col-sm-12" style="display:none;"></span></div>
                                <input class="col-xs-12" placeholder="New Password" id="password" type="password" name="password" required/>
                                <div ckass="col-sm-12" style="padding:5px 0px;"><span class="cpassSpan col-sm-12" style="display:none;"></span></div>
                                <input class="col-xs-12" placeholder="Confirm New Password" id="cpassword" type="password" name="cpassword" required/>
                                <button class="bigButton center-block col-xs-12 col-sm-8 setupbtn" name="setup" disabled>Continue</button>
                            </form>
                        </div>
                    </div>
                </div>


            <?php } ?>

            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'NotVerified' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'true') { ?>
                <div class="paymentForm col-xs-12" style="display:block;">
                    <div class="col-sm-5 col-xs-12 center-block login accountForms no-overflow">
                        <h4 class="title">Make Payment</h4>
                        <div class="well text-well">
                            <b>Note:</b> Application will not be ready for judgement until after payment is completed.
                        </div>
                        <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
                            <input type="hidden" name="cmd" value="_s-xclick">
                            <input type="hidden" name="hosted_button_id" value="5WYWAUS9XL3H2">
                            <input type="hidden" name="on0" value="reference"/>
                            <input type="hidden" name="os0" value="<?php echo $ref ?>"/>
                            <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
                            <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
                        </form>


                    </div>
                </div>
            <?php } ?>

            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['applied'] === 'false' && $aInfo['appprocess'] === 'false') { ?>
                <div class="paymentForm col-xs-12 animated" style="display:block;">
                    <div class="col-xs-8 center-block gsa">
                        <div class="lead text-center">Create Profile.  <small>Step 2 of 5</small><br/></div>
                        <div class="col-sm-12 col-xs-11 center-block login accountForms whiteBg no-border">
                            <form class="createprofile accountForms" action="" method="post">
                                <!-- <div class="col-sm-4 col-xs-12"></div> -->
                                <div class="col-sm-4 col-xs-12">
                                    <label class="col-sm-12 col-xs-12">First Name <span>*</span></label>
                                    <input type="text" required value="<?php echo $getInfo['firstName']; ?>" class='col-sm-12 col-xs-12' disabled placeholder='First Name' name="firstName"/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Last Name <span>*</span></label>
                                    <input type='text' required value="<?php echo $getInfo['lastName']; ?>" class='col-sm-12 col-xs-12' disabled placeholder='Last Name' name="lastName"/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Email Address <span>*</span></label>
                                    <input type='text' required value="<?php echo $getInfo['email']; ?>" class='col-sm-12 col-xs-12' disabled placeholder='Email Address' name="emailAddress"/>
                                </div>
                                <div class="clearfix"></div>


                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Phone Number <span>*</span></label>
                                    <input type='text' required class='col-sm-12 col-xs-12' value="<?php echo $getInfo['phone']; ?>" placeholder='Phone Number' name="phoneNumber"/> 
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Alternative Phone Number</label>
                                    <input type='text' class='col-sm-12 col-xs-12' value="<?php echo $preapn; ?>" placeholder='Alternative Phone Number' name="aphoneNumber"/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Home Address <span>*</span></label>
                                    <input type='text' required class='col-sm-12 col-xs-12' value="<?php echo $getInfo['address']; ?>" placeholder='Home Address' name="address"/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Alternative Address</label>
                                    <input type='text' class='col-sm-12 col-xs-12' value="<?php echo $preahomea; ?>" placeholder='Alternative Address' name="aaddress"/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <label class='col-sm-12 col-xs-12'>Country <span>*</span></label>
                                    <input type='hidden' class='col-sm-12 col-xs-12' value="<?php echo $getInfo['country']; ?>" placeholder='Country' name="country"/>
                                    <input type='text' class='col-sm-12 col-xs-12' value="<?php echo $getInfo['country']; ?>" placeholder='Country' disabled/>
                                </div>

                                <div class="col-sm-4 col-xs-12">
                                    <div class='col-sm-6'>
                                        <label class='col-sm-12 col-xs-12'>State <span>*</span></label>
                                        <input type='hidden' class='col-sm-12 col-xs-12' value="<?php echo $getInfo['state']; ?>" placeholder='State' name="state"/>
                                        <input type='text' class='col-sm-12 col-xs-12' value="<?php echo $getInfo['state']; ?>" placeholder='State' disabled/>
                                    </div><div class='col-sm-1'></div>
                                    <div class='col-sm-5'>
                                        <label class='col-sm-12 col-xs-12'>City <span>*</span></label>
                                        <input type='text' required class='col-sm-12 col-xs-12' placeholder='city' name="city" />
                                    </div>
                                </div>
                                <div class="col-sm-12" style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Date Of Birth <span>*</span></label>
                                    <div class="col-sm-3">
                                        <select required class='col-sm-12 col-xs-12' name="ageDay" type="number" required>
                                            <option value="">Day</option>
                                            <?php
                                            for ($i = 1; $i < 32; $i++) {
                                                echo '<option>' . $i . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-3">
                                        <select required class='col-sm-12 col-xs-12' name="ageMonth" type="number" required>
                                            <option value="">Month</option>
                                            <?php
                                            $month = array('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
                                            for ($i = 0; $i < 12; $i++) {
                                                echo '<option>' . $month[$i] . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-1"></div>
                                    <div class="col-sm-4 col-xs-12">
                                        <select required class='col-sm-12 col-xs-12' name="ageYear" type="number" required>
                                            <option value="">Year</option>
                                            <?php
                                            for ($i = date("Y") - 50; $i < date("Y") - 12; $i++) {
                                                echo '<option>' . $i . '</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class='col-sm-6' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Height (cm) <span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="height">
                                        <option value="">Select Height In (cm)</option>
                                        <?php
                                        for ($i = 150; $i < 251; $i++) {
                                            echo '<option>' . $i . '</option>';
                                            //$i+=4;
                                        }
                                        ?>
                                    </select>
                                </div><div class='col-sm-1'></div>
                                <div class='col-sm-5' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Gender <span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="gender">
                                        <option>Female</option>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                                <div class='col-sm-6' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Bust (cm)<span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="bust">
                                        <option value="">Select Bust Size In (cm)</option>
                                        <?php
                                        for ($i = 50; $i < 101; $i++) {
                                            echo '<option>' . $i . '</option>';
                                            //$i+=4;
                                        }
                                        ?>
                                    </select>
                                </div><div class='col-sm-1'></div>
                                <div class='col-sm-5' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Waist (cm)<span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="waist">
                                        <option value="">Select Waist Size In (cm)</option>
                                        <?php
                                        for ($i = 40; $i < 101; $i++) {
                                            echo '<option>' . $i . '</option>';
                                            //$i+=4;
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="clearfix"></div>
                                <div class='col-sm-6' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Hips (cm)<span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="hips">
                                        <option value="">Select Hips Size In (cm)</option>
                                        <?php
                                        for ($i = 50; $i < 101; $i++) {
                                            echo '<option>' . $i . '</option>';
                                            //$i+=4;
                                        }
                                        ?>
                                    </select>
                                </div><div class='col-sm-1'></div>
                                <div class='col-sm-5' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Shoe (cm) USA Size<span>*</span></label>
                                    <select required class='col-sm-12 col-xs-12' name="shoe">
                                        <option value="">Select Shoe Size In (cm) USA Size</option>
                                        <?php
                                        for ($i = 4; $i < 14; $i++) {
                                            echo '<option>' . $i . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class='col-sm-12' style="padding:0px 5px;">
                                    <label class='col-sm-12 col-xs-12'>Reason For Participating <span>*</span></label>
                                    <textarea rows="10" placeholder="Reason For Participating" resize="none" required name="reason" class="col-sm-12"><?php echo $preReason; ?></textarea>
                                </div>
                                <div class="clearfix"></div>
                                <button class="bigButton center-block col-xs-12 col-sm-6" name="createProfile">Save Profile</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php } ?>




            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'false' && $aInfo['appprocess'] === 'false') { ?>
                <div class="lead text-center">Pre Media Upload.  <small>Step 3 of 5</small><br/></div>
                <div class='account col-sm-10 col-xs-11 center-block'>
                    <div class='col-sm-5 col-xs-12 login accountForms pull-right'>
                        <h5 class='title'>Headshot (White Background only) Side View UPLOAD.</h5>
                        <div class="well text-well">
                            Picture showing model's side head shot view (Headshot).
                            <br/><br/> <b>Pictures taken with Make Up will be disqualified.</b>
                        </div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <label for="headshots" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='headshots' name='files'/>
                        <input type='hidden' value='HEAD SHOT SIDE VIEW' class='fileTypes'/>
                        <input type='hidden' value='3' class='documentStep'/>
                    </div>



                    <div class='col-sm-5 col-xs-12 login accountForms pull-left'>
                        <h5 class='title'>Headshot (White Background only) Front View UPLOAD.</h5>
                        <div class="well text-well">
                            Picture showing model's front head shot view (Headshot).
                            <br/><br/> <b>Pictures taken with Make Up will be disqualified.</b>
                        </div>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="headshotf" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='headshotf' name='files'/>
                        <input type='hidden' value='HEAD SHOT FRONT VIEW' class='fileTypes'/>
                        <input type='hidden' value='3' class='documentStep'/>
                    </div>

                    <div class="clearfix"></div>

                    <div class='col-sm-5 col-xs-12 login accountForms pull-right'>
                        <h5 class='title'>Full Length (Plain Background, preferable White) Photo Front Upload.</h5>
                        <div class="well text-well">
                            Picture showing model's full length front view photo of the model taken 
                            in front of a plain background, wearing body 
                            hugging clothes, e.g singlet and leggings.
                            <br/><br/> <b>Pictures taken with Make Up will be disqualified.</b>
                        </div>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="fulllengthf" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='fulllengthf' name='files'/>
                        <input type='hidden' value='FULL LENGTH PHOTO FRONT' class='fileTypes'/>
                        <input type='hidden' value='3' class='documentStep'/>
                    </div>


                    <div class='col-sm-5 col-xs-12 login accountForms pull-left'>
                        <h5 class='title'>Full Length Photo (White Background only) Side View UPLOAD.</h5>
                        <div class="well text-well">
                            Picture showing model's full length side view photo of the model taken 
                            in front of a plain background, wearing body 
                            hugging clothes, e.g singlet and leggings..<br/>
                            <br/><br/> <b>Pictures taken with Make Up will be disqualified.</b>
                        </div>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="fulllengths" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='fulllengths' name='files'/>
                        <input type='hidden' value='FULL LENGTH PHOTO SIDE' class='fileTypes'/>
                        <input type='hidden' value='3' class='documentStep'/>
                    </div>

                    <div class='clearfix'></div>
                    <br/><br/><br/>
                    <form action="" method="post">
                        <input type="hidden" name="headshotf_i" id="headshotf_i"/>
                        <input type="hidden" name="fulllengths_i" id="fulllengths_i"/>
                        <input type="hidden" name="fulllengthf_i" id="fulllengthf_i"/>
                        <input type="hidden" name="headshotfs_i" id="headshotfs_i"/>
                    <button type="submit" name="prefiles" class="bigButton col-sm-5 col-xs-12 center-block" style="color:#fff;text-decoration:none;display:none;">Save Uploads</button>
                    </form>
                </div>
                <div class='clearfix'></div>
            <?php } ?>


            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'Verified' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'true' && $aInfo['thirdmedia'] === 'false' && $aInfo['appprocess'] === 'false') { ?>
                <div class="lead text-center">Swim wear photo and a scanned copy of international passport upload.  <small>Step 4 of 5</small><br/></div>
                <div class='account col-sm-10 col-xs-11 center-block'>
                    <div class='col-sm-5 col-xs-12 login accountForms pull-right'>
                        <h5 class='title'>Swim Wear Photo UPLOAD</h5>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="swimwear" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='swimwear' name='files'/>
                        <input type='hidden' value='SWIM WEAR PHOTO' class='fileTypes'/>
                        <input type='hidden' value='4' class='documentStep'/>
                    </div>



                    <div class='col-sm-5 col-xs-12 login accountForms pull-left intupload' style="display:none">
                        <h5 class='title'>Scanned Copy of International Passport UPLOAD</h5>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="passport" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='passport' name='files'/>
                        <input type='hidden' value='SCANNED COPY OF INTERNATIONAL PASSPORT' class='fileTypes'/>
                        <input type='hidden' value='4' class='documentStep'/>
                    </div>


                    <div class='col-sm-5 col-xs-12 login accountForms pull-left intpass'>
                        <h5 class='title'>Do you have a valid international passport? *.</h5>
                        <div class="well text-well">Please Note: if you don't have an international passport ready, please get it ready before application deadline date.</div>
                        <select class="col-sm-12" style="" id="intpasschoose">
                            <option>Please Select</option>
                            <option>Yes</option>
                            <option>No</option>
                        </select>
                    </div>



                    <div class='clearfix'></div>
                    <br/><br/><br/>
                    <a href="?swimpassport=true" class="bigButton col-sm-5 col-xs-12 center-block" style="color:#fff;text-decoration:none;display:none;">Save Uploads</a>

                </div>
                <div class='clearfix'></div>
            <?php } ?>


            <?php if (isset($_REQUEST['uploadpass'])) { ?>
                <div class="lead text-center">Scanned copy of international passport upload.<br/></div>
                <div class='account col-sm-10 col-xs-11 center-block'>


                    <div class='col-sm-5 col-xs-12 login accountForms center-block intupload' style="">
                        <h5 class='title'>Scanned Copy of International Passport UPLOAD</h5>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Image Format, Please select another image only in jpg format</div>
                        <label for="passport" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='passport' name='files'/>
                        <input type='hidden' value='SCANNED COPY OF INTERNATIONAL PASSPORT' class='fileTypes'/>
                        <input type='hidden' value='4' class='documentStep'/>
                    </div>




                    <div class='clearfix'></div>
                    <br/><br/><br/>
                    <a href="" class="bigButton col-sm-5 col-xs-12 center-block" style="color:#fff;text-decoration:none;display:none;">Save</a>

                </div>
                <div class='clearfix'></div>
            <?php } ?>
                
                

            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'Verified' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'true' && $aInfo['thirdmedia'] === 'true' && $aInfo['lastmedia'] === 'false' && $aInfo['appprocess'] === 'false') { ?>
                <div class="lead text-center">Interview Video Upload.  <small>Step 5 of 5</small><br/></div>
                <div class='account col-sm-10 col-xs-11 center-block'>
                    <div class='col-sm-5 col-xs-12 login accountForms center-block'>
                        <h5 class='title'>Interview Video</h5>
                        <div class="well text-well">
                            Upload a video only in <b>MP4</b> format, not more than 60 seconds,  telling us why you should be Miss Fashion Week Africa.
                        </div>
                        <br/><br/>
                        <div class="text-danger well text-well errorupload" style="display:none;">Sorry!!, there was an error uploading your file, please try to upload again</div>
                        <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Video Format, Please select another video only in .MP4 format</div>
                        <label for="beauty" class="chooseLabel">Choose File
                            <div id="progress" class="progress">
                                <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                            </div>
                        </label>
                        <input type='file' class='col-sm-12 col-xs-12 videoChoose notuploaded' id='beauty' name='files'/>
                        <input type='hidden' value='Interview Video' class='fileTypes'/>
                        <input type='hidden' value='5' class='documentStep'/>
                    </div>

                    <div class='clearfix'></div>
                    <br/><br/><br/>
                    <a href="?finalvideo=true" class="bigButton col-sm-4 col-xs-12 col-xs-12 center-block" style="color:#fff;text-decoration:none;display:none;">Save</a>

                </div>
                <div class='clearfix'></div>
            <?php } ?>

            <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'Verified' && $aInfo['appprocess'] === 'true') { ?>
                <br/><br/><br/><br/><br/>
                <div class="lead text-center" style="color:#1abc9c;">Processing Application <i class="icon icon-hourglass vector1"></i> <br/></div>
                <div class="bigButton center-block col-xs-12 col-sm-4 col-xs-12">Your Application is being processed. Please always check your Email for the next instruction.</div>
                <br/><br/><br/><br/><br/>
            </div>
            <div class='clearfix'></div>
        <?php } ?>


        <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'Verified' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'true' && $aInfo['thirdmedia'] === 'true' && $aInfo['lastmedia'] === 'true' && $aInfo['appprocess'] === 'false' && $aInfo['step'] === '5' && !isset($_REQUEST['uploadpass'])) { ?>
            <h2 style="color:#777;margin:0;">Profile Information</h2>
        <?php } ?>
    </div>


    <?php if ($aInfo['accountSetup'] === 'true' && $aInfo['accountStatus'] === 'Verified' && $aInfo['applied'] === 'true' && $aInfo['secondmedia'] === 'true' && $aInfo['thirdmedia'] === 'true' && $aInfo['lastmedia'] === 'true' && $aInfo['appprocess'] === 'false' && $aInfo['step'] === '5' && !isset($_REQUEST['uploadpass'])) { ?>

        <div class="col-sm-12 col-xs-12 center-block" style="background:#f9f9f9;overflow:hidden;">

            <div class="col-sm-6 col-xs-12" style="background:#fff;overflow:hidden;padding:30px; margin-top:20px;">
                <table class="table table-bordered">
                    <tbody>
                        <?php
                        $intp = $mfdb->query("SELECT * FROM applicationdocuments WHERE reference='$ref' AND documentType LIKE '%SCANNED COPY OF INTERNATIONAL PASSPORT%'");
                        if (mysqli_num_rows($intp) < 1) {
                            ?>
                        <div class="showing col-sm-12" style="background:#d35400 !important;color:#fff !important;padding:15px;">
                            <div class="col-sm-12 col-xs-12 shw text-center" style="background:#d35400 !important;color:#fff !important;"><b>Scanned Copy of International Passport</b> has not been uploaded yet. <a href="?uploadpass=true" style="color:#fff;font-weight:bolder;">Click Here</a> to upload</div>
                        </div>
                        <br/>
                    <?php } ?>
                    <?php
                    $app = $mfdb->query("SELECT * FROM application WHERE reference='$ref'")->fetch_assoc();
                    ?>
                    <tr>
                        <td>First Name</td>
                        <td><?php echo $app['firstName'] ?></td>
                    </tr>
                    <tr>
                        <td>Last Name</td>
                        <td><?php echo $app['lastName'] ?></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><?php echo $app['emailAddress'] ?></td>
                    </tr>
                    <tr>
                        <td>Reference Number</td>
                        <td><?php echo $app['reference'] ?></td>
                    </tr>
                    <tr>
                        <td>Primary Phone Number</td>
                        <td><?php echo $app['phoneNumber'] ?></td>
                    </tr>
                    <tr>
                        <td>Secondary Phone Number</td>
                        <td><?php echo $app['aphoneNumber'] ?></td>
                    </tr>
                    <tr>
                        <td>Primary Home Address</td>
                        <td><?php echo $app['homeAddress'] ?></td>
                    </tr>
                    <tr>
                        <td>Country</td>
                        <td><?php echo $app['country'] ?></td>
                    </tr>
                    <tr>
                        <td>State</td>
                        <td><?php echo $app['state'] ?></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td><?php echo $app['city'] ?></td>
                    </tr>
                    <tr>
                        <td>Height</td>
                        <td><?php echo $app['height'] ?></td>
                    </tr>
                    <tr>
                        <td>Gender</td>
                        <td><?php echo $app['gender'] ?></td>
                    </tr>
                    <tr>
                        <td>Age</td>
                        <td><?php echo date("Y") - $app['ageYear'] ?></td>
                    </tr>
                    <tr>
                        <td>Votes</td>
                        <td><?php echo $app['vote'] ?> Votes</td>
                    </tr>
                    <tr>
                        <td>Shared</td>
                        <td><?php echo $app['share'] ?> Shares</td>
                    </tr>
                    <tr>
                        <td>Bust</td>
                        <td><?php echo $app['Bust'] ?>cm</td>
                    </tr>
                    <tr>
                        <td>Waist</td>
                        <td><?php echo $app['Waist'] ?>cm</td>
                    </tr>
                    <tr>
                        <td>Hips</td>
                        <td><?php echo $app['Hips'] ?>cm</td>
                    </tr>
                    <tr>
                        <td>Shoe</td>
                        <td><?php echo $app['Shoe'] ?> USA</td>
                    </tr>
                    <tr>
                        <td>Head Shot Score</td>
                        <td><?php echo $app['headshotscore'] ?> /10</td>
                    </tr>
                    <tr>
                        <td>Full Length Score</td>
                        <td><?php echo $app['fulllenghtscore'] ?> /10</td>
                    </tr>
                    <tr>
                        <td>Swim Wear Score</td>
                        <td><?php echo $app['swimwearscore'] ?> /10</td>
                    </tr>
                    <tr>
                        <td>Catwalk Score</td>
                        <td><?php echo $app['catwalkscore'] ?> /10</td>
                    </tr>
                    <tr>
                        <td>Interview Score</td>
                        <td><?php echo $app['interviewscore'] ?> /10</td>
                    </tr>
                    <tr>
                        <td>Application Process</td>
                        <td><?php echo $app['applicationStatus'] ?></td>
                    </tr>
                    <tr>
                        <td>Profile Views</td>
                        <td><?php echo $getInfo['profilecount'] ?></td>
                    </tr>
                    <tr>
                        <td>Reason To Become Miss Fashion Week Africa</td>
                        <td><?php echo str_replace('`', '\'', $app['reason']) ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="col-sm-6 col-xs-12 profile_files pull-right videoList" style="margin-top:20px;">
                <?php
                for ($i = 0; $i < count($dbvideos); $i++) {
                    echo '<a href="../videos/?watch=' . $dbvideos[$i]['LINK'] . '"><div class="videoSingle col-xs-12 col-sm-6">
                    <div class="col-xs-12 col-sm-12" style="padding:0px;">
                        <img src="../images/playvideo.png" alt=""/>
                    </div>
                    <div class="col-xs-12 col-sm-12" style="padding:10px 0px;">
                        <a href="../videos/?watch=' . $dbvideos[$i]['LINK'] . '">' . $dbvideos[$i]['NAME'] . '</a>
                        <span class="col-xs-12 videoviews"> ' . $dbvideos[$i]['VIEWS'] . ' views</span>
                        <span class="col-xs-12 videoviews"><i class="icon icon-calendar"></i> ' . $dbvideos[$i]['DATE'] . '</span>
                    </div>
                </div></a>';
                }
                ?>

                <div class="title col-sm-12 col-xs-12" style="background:#fff;padding:5px;margin-top:5px;">
                    <h4>Uploaded Pictures</h4>
                </div>
                <div class="pictureChoose">
                    <?php
                    for ($i = 0; $i < count($pictures); $i++) {
                        echo '<a href="../images/models/' . $pictures[$i]['PICTURE'] . '" class="col-xs-12 col-sm-6">
                        <div class="pc">
                    <div class="col-xs-12 col-sm-12" style="padding:10px 0px;">
                        <img src="../images/models/' . $pictures[$i]['PICTURE'] . '" alt="' . $pictures[$i]['TYPE'] . '"/>
                    </div>
                    <div class="col-xs-12 col-sm-12 text-center" style="text-align:center !important;">
                        <span class="picturename" style="text-align:center !important;">' . $pictures[$i]['TYPE'] . '</span>
                    </div>
                </div></a>';
                    }
                    ?>
                </div>
            </div>





        </div>


    <?php } ?>

    <div class='clearfix'></div>
    <section class="footer">
        <div class="clearfix"></div>
        <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
        <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
    </section>
    <script src="../js/jquery.js"></script>
    <script src="../js/plugins.js"></script>
    <script src="../js/jquery.ui.widget.js" type="text/javascript"></script>
    <script src="../js/jquery.fileupload.js" type="text/javascript"></script>
    <script src="../js/countries.js" type="text/javascript"></script>
    <script src="../js/gallery/lightgallery.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-fullscreen.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-thumbnail.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-zoom.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-hash.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-autoplay.js" type="text/javascript"></script>
    <script src="../js/gallery/lg-pager.js" type="text/javascript"></script>
    <script src="../js/main.js"></script>
    <script type="text/javascript">


        //var up = $('.videoChoose.notuploaded.uploaded').length;
        var nu = $('.videoChoose.notuploaded').length;
        //alert(nu);
        setInterval(function() {
            var up = $('.videoChoose.notuploaded.uploaded').length;
            if (nu > 0) {
                //alert('yes');
                if (up === nu) {
                    //alert(nu + ' ' + up);
                    $('.bigButton').fadeIn(1000);
                }
                else{
                    $('.bigButton').fadeOut(1000);
                }
            }
        }, 5000);
        $('#intpasschoose').change(function() {
            var selected = $(this).find('option:selected').val();
            if (selected === 'Yes') {
                $('.intpass').css('display', 'none');
                $('.intupload').fadeIn(1000);
            }
            else if (selected === 'No') {
                $('.bigButton').fadeIn(1000);
            }
            else if (selected === 'Please Select') {
                $(this).css('border-color', 'red');
                $('.intupload').css('display', 'none');
                $('.bigButton').fadeOut(1000);
            }
        });
        var abort = 0;
        /*$('#editorial').change(function() {
         $('.bigButton').fadeIn(1000);
         });*/
        $('.pictureChoose').lightGallery();
        $('.vrs ul li').click(function() {
            $('.vrs ul li').removeClass('active');
            $(this).addClass('active');
            var view = $(this).attr('data-view');
            $('.vrsd').fadeOut(200);
            $('.' + view).fadeIn(500);
        });

        $('.setupbtn').prop('disabled', true);
        $('#password').blur(function() {
            if ($(this).val().length < 6) {
                $('.setupbtn').prop('disabled', true);
                $('.passSpan').fadeIn(500).text('Password is too short').css('color', 'red');
            }
            else {
                $('.passSpan').fadeOut(500);
            }
        });
        $('#password').keyup(function() {
            if ($(this).val().length > 5) {
                $('.passSpan').fadeOut(500);
            }
        });
        $('#cpassword').keyup(function() {
            if ($(this).val() !== $('#password').val()) {
                $('.setupbtn').prop('disabled', true);
                //$('.cpassSpan').fadeIn(500).text('Password do not match').css('color', 'red');
            } else {
                $('.setupbtn').prop('disabled', false);
                $('.cpassSpan').fadeOut(500);
            }
        });
        $('#cpassword').blur(function() {
            if ($(this).val() !== $('#password').val()) {
                $('.setupbtn').prop('disabled', true);
                $('.cpassSpan').fadeIn(500).text('Password do not match').css('color', 'red');
            }
        });

        $('.getStarted a').click(function() {
            $('.getStarted').addClass('slideOutLeft').animate({display: 'block'}, 200, function() {
                $(this).css('display', 'none');
                $('.paymentForm').css('display', 'block');
            });
        });

        var ref = "<?php echo $ref; ?>";
        var fname = "<?php echo $fname; ?>";
        var lname = "<?php echo $lname; ?>";

        var ft = '';
        var docstep = '';
        $('.videoChoose').change(function(e) {
            ft = $(this).parent().find('.fileTypes').val();
            var thisid = $(this).attr('id');
            $(this).parent().find('.errorupload').fadeOut();
        });
        $('.videoChoose').change(function(e) {
            ft = $(this).parent().find('.fileTypes').val();
            if (ft === 'Interview Video') {
                var nf = $(this).val();
                if (nf.indexOf('.mp4') ===-1) {
                    //alert('Invalid Video Format');
                    abort = true;
                    $('.invalidvideo').fadeIn(1000);
                } else {
                    abort = false;
                    $('.invalidvideo').fadeOut(1000);
                }
            }
        });
        $('.videoChoose').change(function() {
            docstep = $(this).parent().find('.documentStep').val();
        });
        
        $(function() {
            'use strict';
            // Change this to the location of your server-side upload handler:
            var url = window.location.hostname === 'upload.php' ?
                    '//jquery-file-upload.appspot.com/' : 'upload.php';
            $('.videoChoose').fileupload({
                url: url,
                dataType: 'json',
                done: function(e, data) {
                    $(this).parent().css('opacity', .9);
                    $(this).addClass('uploaded');
                    $(this).parent().find('#progress').fadeIn().find('.progress-bar').removeClass('progress-bar-danger').addClass('progress-bar-success').text('Saved, Click Here to change.');
                    /*var uploaded = $('.uploaded').length;
                     if (uploaded === 6) {
                     $('.uploaded').fadeOut(1000).delay(2000, function() {
                     $('.completeUpload').fadeIn(1000);
                     $('html,body').animate({scrollTop: $('.completeUpload').offset().top - 500}, 100);
                     });
                     }*/
                    var ext = '.'+data.result.Files.Ext;
                    var error = data.result.Files.Error;
                    var errortype = data.result.Files.ErrorType;
                    console.clear();
                    console.log(data.result.Files.Error+' '+errortype);
                    if(error > 0){
                        $(this).parent().find('.errorupload').fadeIn();
                    }
                    if(errortype.length > 0){
                        $(this).parent().find('#progress').fadeIn().find('.progress-bar').addClass('progress-bar-danger').removeClass('progress-bar-success').text(errortype);
                    }
                },fail:function(e, data){
                    $(this).parent().find('.errorupload').fadeIn();
                    $(this).parent().find('#progress').fadeIn(1000);
                    $(this).parent().find('#progress .progress-bar').removeClass('progress-bar-success').addClass('progress-bar-danger').text('Upload Failed');
                },start: function(e, data) {
                    if(abort === true){
                        data.abort();
                        $(this).parent().find('#progress').fadeIn().find('.progress-bar').removeClass('progress-bar-danger').addClass('progress-bar-success');
                        $(this).parent().find('#progress').fadeOut(1000);}
                    $(this).parent().find('#progress').fadeIn(1000);
                    console.clear();
                },
                progressall: function(e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    $(this).parent().find('#progress .progress-bar').css(
                            'width',
                            progress + '%'
                            );
                    $(this).parent().find('#progress .progress-bar').text('Please wait... ' + progress + '%');
                }
            }).bind('fileuploadsubmit', function(e, data) {
                data.formData = {fileT: ft, reference: ref,fn: fname,ln: lname,docStep: docstep};
            });
        });
    </script>

    

</body> 
<div class="minnav">
    <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
</div>  
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</html>