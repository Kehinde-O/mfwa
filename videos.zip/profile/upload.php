<?php

header('Vary: Accept');
if (isset($_SERVER['HTTP_ACCEPT']) &&
        (strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false)) {
    header('Content-type: application/json');
} else {
    header('Content-type: text/plain');
}
include '../handler.php';
$dir = '../images/models/';
$fileType = $_POST['fileT'];
$docstep = $_POST['docStep'];
$ref = $_REQUEST['reference'];
$fn = $_REQUEST['fn'];
$ln = $_REQUEST['ln'];
$characters = "1234567890ABCFGHIJKLMNPQRSTVWXYZabcdfghijklmnpqrstvwxyz";
$string = '';
$max = strlen($characters) - 1;
for ($i = 0; $i < 12; $i++) {
    $string .= $characters[mt_rand(0, $max)];
}
if (!is_dir($dir)) {
    mkdir($dir, 0775);
}
$file = $_FILES['files']['tmp_name'];
$file_name = $_FILES['files']['name'];
$file_name = $ref . '_' . str_replace(' ', '_', $file_name);



$fileinfo = pathinfo($file_name);
$type = $fileinfo['extension'];
if ($type === 'mp4' && $fileType ==='Interview Video') {
    $vname = $file_name;
    $checkDoc = $mfdb->query("SELECT * FROM videos WHERE reference='$ref' AND applicationStep='5'");
    $docResult = $checkDoc->fetch_assoc();

    if (mysqli_num_rows($checkDoc) > 0) {
        if (is_file('../videos/' . $docResult['videoReference'])) {
            unlink('../videos/' . $docResult['videoReference']);
        }
        if (move_uploaded_file($file, '../videos/' . $vname)) {
            if (!is_file('../videos/' . $vname)) {
                $result = array(
                    "Files" => array(
                        "Error" => 1
                    )
                );
                echo json_encode($result);
            }
            if (is_file('../videos/' . $vname)) {
                if ($mfdb->query("UPDATE videos SET shortLink='$string',videoReference='$vname' WHERE reference='$ref' AND applicationStep='5'")) {
                    $ckk = $mfdb->query("SELECT * FROM videos WHERE videoName='Interview Video for $fn $ln' AND reference='$ref'");
                    if (mysqli_num_rows($ckk) > 0) {
                        $result = array(
                            "Files" => array(
                                "Error" => 0
                            )
                        );
                        echo json_encode($result);
                    } else {
                        $result = array(
                            "Files" => array(
                                "Error" => 1
                            )
                        );
                        echo json_encode($result);
                    }
                } else {
                    $result = array(
                        "Files" => array(
                            "Error" => 1
                        )
                    );
                    echo json_encode($result);
                }
            } else {
                $result = array(
                    "Files" => array(
                        "Error" => 1
                    )
                );
                echo json_encode($result);
            }
        } else {
            $result = array(
                "Files" => array(
                    "Error" => 1
                )
            );
            echo json_encode($result);
        }
    } else {
        if (move_uploaded_file($file, '../videos/' . $vname)) {
            if (is_file('../videos/' . $vname)) {
                if ($mfdb->query("INSERT INTO videos "
                                . "(reference,firstName,lastName,time,date,videoName,applicationStep,shortLink,videoReference,judged,judgedby) " . "VALUES('$ref','$fn','$ln','$time','$date','Interview Video for $fn $ln','5','$string','$vname','false','')")) {
                    $ckk = $mfdb->query("SELECT * FROM videos WHERE videoName='Interview Video for $fn $ln' AND reference='$ref'");
                    if (mysqli_num_rows($ckk) > 0) {
                        $result = array(
                            "Files" => array(
                                "Error" => 0
                            )
                        );
                        echo json_encode($result);
                    } else {
                        $result = array(
                            "Files" => array(
                                "Error" => 1
                            )
                        );
                        echo json_encode($result);
                    }
                } else {
                    $result = array(
                        "Files" => array(
                            "Error" => 1
                        )
                    );
                    echo json_encode($result);
                }
            } else {
                $result = array(
                    "Files" => array(
                        "Error" => 1
                    )
                );
                echo json_encode($result);
            }
        } else {
            $result = array(
                "Files" => array(
                    "Error" => 1
                )
            );
            echo json_encode($result);
        }
    }
} else if (getimagesize($file)) {
    $checkDoc = $mfdb->query("SELECT documentReference,documentType FROM applicationdocuments WHERE documentType='$fileType' AND reference='$ref'");
    $docResult = $checkDoc->fetch_assoc();

    if (mysqli_num_rows($checkDoc) > 0) {
        if (is_file('../images/models' . '/' . $docResult['documentReference'])) {
            unlink('../images/models' . '/' . $docResult['documentReference']);
            if (is_file('../images/models' . '/thumb_' . $docResult['documentReference'])) {
                unlink('../images/models' . '/thumb_' . $docResult['documentReference']);
            }
        }
        //session_unset($_SESSION['lastFileName']);
        if (move_uploaded_file($file, $dir . '/' . $file_name)) {
            if ($mfdb->query("UPDATE applicationdocuments SET documentReference='$file_name' WHERE reference='$ref' AND documentType='$fileType'")) {
                $ckk = $mfdb->query("SELECT * FROM applicationdocuments WHERE documentReference='$file_name' AND reference='$ref' AND documentType='$fileType'");
                if (mysqli_num_rows($ckk) > 0) {
                    $result = array(
                        "Files" => array(
                            "Error" => 0
                        )
                    );
                    echo json_encode($result);
                } else {
                    $result = array(
                        "Files" => array(
                            "Error" => 1
                        )
                    );
                    echo json_encode($result);
                }
            } else {
                $result = array(
                    "Files" => array(
                        "Error" => 1
                    )
                );
                echo json_encode($result);
            }
        } else {
            $result = array(
                "Files" => array(
                    "Error" => 1
                )
            );
            echo json_encode($result);
        }
    } else {
        if (move_uploaded_file($file, '../images/models' . '/' . $file_name)) {
            if ($mfdb->query("INSERT INTO applicationdocuments "
                            . "(reference,applicationStep,documentReference,documentType,judged,judgedby) "
                            . "VALUES('$ref','$docstep','$file_name','$fileType','false','')")) {
                $ckk = $mfdb->query("SELECT * FROM applicationdocuments WHERE documentReference='$file_name' AND reference='$ref' AND documentType='$fileType'");
                if (mysqli_num_rows($ckk) > 0) {
                    $result = array(
                        "Files" => array(
                            "Error" => 0
                        )
                    );
                    echo json_encode($result);
                } else {
                    $result = array(
                        "Files" => array(
                            "Error" => 1
                        )
                    );
                    echo json_encode($result);
                }
            } else {
                $result = array(
                    "Files" => array(
                        "Error" => 1
                    )
                );
                echo json_encode($result);
            }
        } else {
            $result = array(
                "Files" => array(
                    "Error" => 1
                )
            );
            echo json_encode($result);
        }
    }
} else {
    $result = array(
        "Files" => array(
            "Error" => 1,
            "ErrorType" => "Invalid File Format"
        )
    );
    echo json_encode($result);
}

