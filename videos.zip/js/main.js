$(".slider > .item:gt(0)").hide();
$(".account > .login-panel:gt(0)").hide();


$('.get-started-btn').click(function() {
    if ($('.bigHead').fadeOut(1000)) {
        $('.account > .login-panel').fadeOut(1000, function() {
            $('.account > .login-panel.requirements').fadeIn(1000);
            $('.bigHead').removeClass('bounceInDown');
            $('.bigHead').removeClass('bounceOutUp');
        });
        $('.bigHead').addClass('bounceOutUp');
    }

});

$('.register-btn').click(function() {
    $('.account > .login-panel').fadeOut(1000);
    $('.account > .login-panel.register').fadeIn(1000);
});

$('.login-drive').click(function() {
    $('.account > .login-panel').fadeOut(1000);
    $('.account > .login-panel.login-box').fadeIn(1000);
    $('.bigHead').removeClass('bounceInDown').addClass('bounceOutUp');
});

$('.cancel-btn').click(function() {
    $('.account > .login-panel').fadeOut(1000);
    $('.account > .login-panel.started').fadeIn(1000);
    $('.bigHead').fadeIn(1000);
    $('.bigHead').removeClass('bounceOutUp').addClass('bounceInDown');
});


setInterval(function() {
    //$('.slider .item .bg').removeClass('scaleing');
    $('.slider > .item:first').removeClass('active').fadeOut(1000, function() {
        $('.slider > .item .bg').removeClass('scaleing');
    }).next().addClass('active').fadeIn(1000, function() {
        $('.slider > .item.active .bg').addClass('scaleing');
    }).end().appendTo('.slider');
}, 10000);

$(document).ready(function() {
    $('.pageloader').delay(1200).css('opacity', '0').css('display', 'none');
    var windowWidth = $(window).width();
    if (windowWidth <= 900) {
        $('.header .navigation ul').appendTo('.minnav');
        $('.achieved-list').addClass('js-flickity');
    }
    else {
        $('.minnav ul').appendTo('.navigation');
        $('.achieved-list').removeClass('js-flickity');
    }
});

$(window).resize(function() {
    var windowWidth = $(window).width();
    if (windowWidth <= 900) {
        $('.header .navigation ul').appendTo('.minnav');
        $('.achieved-list').addClass('js-flickity');
    }
    else {
        $('.minnav ul').appendTo('.navigation');
        $('.achieved-list').removeClass('js-flickity');
        $('.fixhead').animate({right: '0'}, 200);
    }
});

$('.drop').click(function() {
    $('.drop').addClass('close');
    if ($('.minnav').css('right') === '-250px') {
        $('body').animate({left: '-250px'}, 200);
        $('.fixhead').animate({right: '250px'}, 200);
        $('.minnav').animate({right: '0'}, 200);
    }
    else {
        $('.drop').removeClass('close');
        $('body').animate({left: '0'}, 200);
        $('.fixhead').animate({right: '0'}, 200);
        $('.minnav').animate({right: '-250px'}, 200);
    }
});

var lfixadent = $(".header"), postl = $(".header").offset();
$(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() > (postl.top + 300))
        {
            lfixadent.addClass('fixhead');
            lfixadent.addClass('bounceInDown');
            //$('.minnav').css('top','98px');
        }
        else if ($(this).scrollTop() <= postl.top + 50 && lfixadent.hasClass('fixhead'))
        {
            lfixadent.removeClass('fixhead');
            lfixadent.removeClass('bounceInDown');
            //$('.minnav').css('top','0px');
        }


    });
});




$(function() {
    var wall = new Freewall('.modelsHome');
    //wall.fitWidth();
});


$(function() {

    function initMap() {

        var location = new google.maps.LatLng(9.0525716, 7.4961747);

        var mapCanvas = document.getElementById('map');
        var mapOptions = {
            center: location,
            zoom: 10,
            panControl: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            draggable: !("ontouchend" in document)
        };
        var map = new google.maps.Map(mapCanvas, mapOptions);

        var markerImage = 'images/marker.png';

        var marker = new google.maps.Marker({
            position: location,
            map: map,
            icon: markerImage
        });

        var contentString = '<div class="info-window">' +
                '<h3>We Are Here</h3>' +
                '<div class="info-content">' +
                '<p>Miss Fahion Week Africa</p>' +
                '</div>' +
                '</div>';

        var infowindow = new google.maps.InfoWindow({
            content: contentString,
            maxWidth: 300
        });
        infowindow.open(map, marker);
        marker.addListener('mouseover', function() {
            infowindow.open(map, marker);
        });

        var mapStyles = [{"featureType": "landscape", "stylers": [{"saturation": -100}, {"lightness": 65}, {"visibility": "on"}]}, {"featureType": "poi", "stylers": [{"saturation": -100}, {"lightness": 51}, {"visibility": "simplified"}]}, {"featureType": "road.highway", "stylers": [{"saturation": -100}, {"visibility": "simplified"}]}, {"featureType": "road.arterial", "stylers": [{"saturation": -100}, {"lightness": 30}, {"visibility": "on"}]}, {"featureType": "road.local", "stylers": [{"saturation": -100}, {"lightness": 40}, {"visibility": "on"}]}, {"featureType": "transit", "stylers": [{"saturation": -100}, {"visibility": "simplified"}]}, {"featureType": "administrative.province", "stylers": [{"visibility": "off"}]}, {"featureType": "water", "elementType": "labels", "stylers": [{"visibility": "on"}, {"lightness": -25}, {"saturation": -100}]}, {"featureType": "water", "elementType": "geometry", "stylers": [{"hue": "#ffff00"}, {"lightness": -25}, {"saturation": -97}]}];

        map.set('styles', mapStyles);

    }

    google.maps.event.addDomListener(window, 'load', initMap);


});

var sample_data = [];
$('#footerMap').vectorMap({
    map: 'world_en',
    backgroundColor: null,
    color: '#ffffff',
    hoverOpacity: 0.7,
    selectedColor: '#666666',
    enableZoom: false,
    showTooltip: true,
    values: sample_data,
    scaleColors: ['#C8EEFF', '#006491'],
    normalizeFunction: 'polynomial'
});

$('#checkRules').click(function() {
    $('.regRules').css('display', 'block');
});

$('#notCheckedRules').click(function() {
    $('.regRules').css('display', 'none');
});

$('#checkedRules').click(function() {
    $('.register form').submit();
});

var guides = $('.howitworks .accountForms');
for (i = 0; i < guides.length; i++) {
    // $('.howitworks .accountForms:nth-child('+i+')').find('.title').text(i);
}

$('#homeVideo').click(function() {
    var video = document.getElementById('homeVideo');
    if (video.paused === true) {
        video.play();
    }
    else {
        video.pause();
    }
});

var curVlink = $('.switchVideos li.active').attr('dataView');
$('#' + curVlink).css('display', 'block');

$('.switchVideos li').click(function() {
    $('.switchVideos li').removeClass('active');
    $(this).addClass('active');
    var dataView = $(this).attr('dataView');
    $('.switchForm').find('.videoLinks').css('display', 'none');
    $('.switchForm').find('#' + dataView).fadeIn(1000);

});
$('.blogSocial span.co').click(function(){
   var action = $(this).attr('data-action');
   if(action === 'close'){
       //alert(action);
       $('.blogSocial a').css('display','none');
       $('.blogSocial span.cl').css('display','none');
       $('.blogSocial span.op').fadeIn(100);
   }
   else if(action === 'open'){
       //alert(action);
       $('.blogSocial a').css('display','block');
       $('.blogSocial span.op').css('display','none');
       $('.blogSocial span.cl').fadeIn(100);
   }
});


var xhttp;
if (window.XMLHttpRequest) {
    xhttp = new XMLHttpRequest();
} else {
    // code for IE6, IE5
    xhttp = new ActiveXObject("Microsoft.XMLHTTP");
}


function closecms() {
    $('.contactMsgi').removeClass('bounceInUp').addClass('bounceOutDown');
}

function opencms() {
    $('.contactMsgi.o').removeClass('bounceOutDown').addClass('bounceInUp').css('display', 'block');
}


var sWidth = $('.socialTeam').width();
var saa;
var sA = $('.socialTeam').each(function() {
    saa = $(this).find('a').length;
    $(this).find('a').css('width', 100 / saa + '%');
});

function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.HORIZONTAL}, 'google_translate_element');
}
/*$('.alv').click(function(){
 var id = $(this).attr('id');
 var action = $(this).attr('data-action');
 var email = $(this).attr('data-email');
 alert(email);
 });*/
