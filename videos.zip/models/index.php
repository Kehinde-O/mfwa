<?php
include '../handler.php';
$lebtn = $_POST['lebtn'];
$slikemail = $_SESSION['likemail'];
if (isset($lebtn)) {
    $likemail = $_POST['likemail'];
    if (!empty($likemail)) {
        $_SESSION['likemail'] = $_POST['likemail'];
        $slikemail = $_SESSION['likemail'];
        header('location:../models/');
    }
}
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>All Models - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/" class="active">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-3 col-xs-4 pull-left'>MODELS</h2>
            <form action="" method="post" class="msearch col-sm-3 col-xs-7 pull-right">
                <input type="text" placeholder="Look up contastants" name="model" class="col-sm-10 col-xs-9"/>
                <button type="submit" class="btn btn-primary col-sm-2 col-xs-3"><i class="icon icon-magnifier"></i> </button>
            </form>
        </section>

        <section class="about team col-sm-11 col-xs-11 center-block">

            <?php if (!isset($_POST['model'])) { ?>

                <?php
                $jdd = $mfdb->query("SELECT * FROM application ORDER BY vote DESC");
                while ($g = $jdd->fetch_assoc()) {
                    $jd[] = array(
                        'ID' => $g['id'],
                        'REFERENCE' => $g['reference'],
                        'FIRSTNAME' => $g['firstName'],
                        'LASTNAME' => $g['lastName'],
                        'EMAIL' => $g['emailAddress'],
                        'PHONE' => $g['phoneNumber'],
                        'PHONE2' => $g['aphoneNumber'],
                        'ADDRESS' => $g['homeAddress'],
                        'ADDRESS2' => $g['ahomeAddress'],
                        'COUNTRY' => $g['country'],
                        'STATE' => $g['state'],
                        'CITY' => $g['city'],
                        'HEIGHT' => $g['height'],
                        'GENDER' => $g['gender'],
                        'APPSTATUS' => $g['applicationStatus'],
                        'DAY' => $g['ageDay'],
                        'MONTH' => $g['ageMonth'],
                        'YEAR' => $g['ageYear'],
                        'REASON' => $g['reason'],
                        'SHARES' => $g['share'],
                        'VOTES' => $g['vote']
                    );
                }
                for ($i = 0; $i < count($jd); $i++) {
                    $con = $jd[$i]['REFERENCE'];
                    $age = date("Y") - $jd[$i]['YEAR'];
                    $pic = $mfdb->query("SELECT * FROM applicationdocuments WHERE reference='$con' AND documentType='HEAD SHOT FRONT VIEW'")->fetch_assoc();
                    ?><div class="col-sm-3 teamMate">
                <div class="tVeil">
                        <div class="ageH animate bounceInUp">
                            <div class="col-sm-6 col-xs-5">HEIGHT<br/><?php echo $jd[$i]['HEIGHT'] ?> cm</div>
                            <div class="col-sm-6  col-xs-5">AGE<br/><?php echo $age ?></div>
                        </div>
                </div>
                <div class="mate">
                    <img src="<?php if(!empty($pic['documentReference'])){ echo '../images/models/'. $pic['documentReference'];} else{ echo '../images/loading.gif';} ?>" alt="" />
                        
                    <h4 class="name"><?php echo $jd[$i]['FIRSTNAME'] . ' ' . $jd[$i]['LASTNAME'] . ' <span>' . $jd[$i]['COUNTRY']?></span></h4><br/>
                        <div class="socialTeam">
                            <a class="twitter alv" style="color:#fff !important" id="vote<?php echo $jd[$i]['REFERENCE']?>" data-action="vote" data-email="<?php echo $slikemail?>"><i class="icon icon-like"></i>&nbsp;&nbsp;&nbsp; Vote <?php echo $jd[$i]['VOTES'] ?></a>
                        </div>
                        <div class="socialTeam share">
                            <span class="col-sm-12 col-xs-12 share-text" id="sharer<?php echo $jd[$i]['REFERENCE']?>"><i class="icon icon-share"></i>&nbsp;&nbsp;&nbsp; Share <?php echo $jd[$i]['SHARES']?></span>
                            <a class="facebook" id="<?php echo $jd[$i]['REFERENCE'] ?>" data-share="facebook" href="https://www.facebook.com/sharer/sharer.php?u=missfashionweekafrica.com/models/media/<?php echo $jd[$i]['REFERENCE'] ?>.html" target="_blank"><i class="icon icon-social-facebook"></i></a>
                            <a class="linkedin" id="<?php echo $jd[$i]['REFERENCE'] ?>" data-share="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=missfashionweekafrica.com/models/media/<?php echo $jd[$i]['REFERENCE'] ?>.html&title=<?php echo $jd[$i]['FIRSTNAME'] ?>%40MissFashionWeekAfrica&summary=&source=missfashionweekafrica.com/models/media/<?php echo $jd[$i]['REFERENCE'] ?>.html" target="_blank"><i class="icon icon-social-linkedin"></i></a>
                            <a class="twitter" id="<?php echo $jd[$i]['REFERENCE']?>" data-share="twitter" href="https://twitter.com/home?status=missfashionweekafrica.com/models/media/<?php echo $jd[$i]['REFERENCE'] ?>.html" target="_blank"><i class="icon icon-social-twitter"></i></a>
                            <a class="google" id="<?php echo $jd[$i]['REFERENCE'] ?>" data-share="google" href="https://plus.google.com/share?url=missfashionweekafrica.com/models/media/<?php echo $jd[$i]['REFERENCE'] ?>.html" target="_blank"><i class="icon icon-social-google"></i></a>
                        </div>
                        

                        <div class="socialTeam">
                            <a href="media/<?php echo $jd[$i]['REFERENCE']?>.html"><i class="icon icon-eye"></i> VIEW PROFILE</a>
                        </div>
                </div>
            </div>
                <?php }?>

            <?php } ?>


            <?php if (isset($_POST['model'])) { ?>

                <?php
                $m = $_POST['model'];
                $gc = $mfdb->query("SELECT * FROM application WHERE reference LIKE '%$m%' OR firstName LIKE '%$m%' OR lastName LIKE '%$m%' OR country LIKE '%$m%' OR state LIKE '%$m%' ORDER BY vote DESC");
                $jdd = array();
                while ($g = $gc->fetch_assoc()) {
                    $jdd[] = array(
                        'ID' => $g['id'],
                        'REFERENCE' => $g['reference'],
                        'FIRSTNAME' => $g['firstName'],
                        'LASTNAME' => $g['lastName'],
                        'EMAIL' => $g['emailAddress'],
                        'PHONE' => $g['phoneNumber'],
                        'PHONE2' => $g['aphoneNumber'],
                        'ADDRESS' => $g['homeAddress'],
                        'ADDRESS2' => $g['ahomeAddress'],
                        'COUNTRY' => $g['country'],
                        'STATE' => $g['state'],
                        'CITY' => $g['city'],
                        'HEIGHT' => $g['height'],
                        'GENDER' => $g['gender'],
                        'APPSTATUS' => $g['applicationStatus'],
                        'DAY' => $g['ageDay'],
                        'MONTH' => $g['ageMonth'],
                        'YEAR' => $g['ageYear'],
                        'REASON' => $g['reason'],
                        'SHARES' => $g['share'],
                        'VOTES' => $g['vote']
                    );
                }
                for ($i = 0; $i < count($jdd); $i++) {
                    $con = $jdd[$i]['REFERENCE'];
                    $age = date("Y") - $jdd[$i]['YEAR'];
                    $pic = $mfdb->query("SELECT * FROM applicationdocuments WHERE reference='$con' AND documentType='HEAD SHOT FRONT VIEW'")->fetch_assoc();
                    echo '<div class="col-sm-3 teamMate">
                <div class="tVeil">
                        <div class="ageH animate bounceInUp">
                            <div class="col-sm-6 col-xs-5">HEIGHT<br/> ' . $jdd[$i]['HEIGHT'] . 'FT</div>
                            <div class="col-sm-6  col-xs-5">AGE<br/> ' . $age . '</div>
                        </div>
                </div>
                <div class="mate">
                    <img src="../images/models/' . $pic['documentReference'] . '" alt="" />
                        
                    <h4 class="name">' . $jdd[$i]['FIRSTNAME'] . ' ' . $jdd[$i]['LASTNAME'] . ' <span>' . $jdd[$i]['COUNTRY'] . '</span></h4><br/>
                        <div class="socialTeam">
                            <a class="twitter alv" style="color:#fff !important" id="vote' . $jdd[$i]['REFERENCE'] . '" data-action="vote" data-email="' . $slikemail . '"><i class="icon icon-like"></i>&nbsp;&nbsp;&nbsp; Vote ' . $jdd[$i]['VOTES'] . '</a>
                        </div>
                        <div class="socialTeam share">
                            <span class="col-sm-12 col-xs-12 share-text" id="sharer' . $jdd[$i]['REFERENCE'] . '"><i class="icon icon-share"></i>&nbsp;&nbsp;&nbsp; Share ' . $jdd[$i]['SHARES'] . '</span>
                            <a class="facebook" id="' . $jdd[$i]['REFERENCE'] . '" data-share="facebook" href="https://www.facebook.com/sharer/sharer.php?u=missfashionweekafrica.com/contestant/dashBoard/' . $jdd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-facebook"></i></a>
                            <a class="linkedin" id="' . $jdd[$i]['REFERENCE'] . '" data-share="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=missfashionweekafrica.com/contestant/dashBoard/' . $jdd[$i]['ID'] . '.contestant&title=' . $jdd[$i]['FIRSTNAME'] . '%40MissFashionWeekAfrica&summary=&source=missfashionweekafrica.com/contestant/dashBoard/' . $jdd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-linkedin"></i></a>
                            <a class="twitter" id="' . $jdd[$i]['REFERENCE'] . '" data-share="twitter" href="https://twitter.com/home?status=missfashionweekafrica.com/contestant/dashBoard/' . $jdd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-twitter"></i></a>
                            <a class="google" id="' . $jdd[$i]['REFERENCE'] . '" data-share="google" href="https://plus.google.com/share?url=missfashionweekafrica.com/contestant/dashBoard/' . $jdd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-google"></i></a>
                        </div>
                        

                        <div class="socialTeam">
                            <a href="media/' . $jdd[$i]['REFERENCE'] . '.html"><i class="icon icon-eye"></i> VIEW PROFILE</a>
                        </div>
                </div>
            </div>';
                }
                ?>
            <?php if(count($jdd) === 0){
                echo '<h1>No results found</h1> <br/><a href="">Back to All Models</a>';
            } ?>
            <?php } ?>

            <div class="clearfix"><br/></div>
        </section>


        <div class='clearfix'></div>


        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="text" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
            </div>
            <a class="extralink" target="_blank"></a>

            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if (count($blog) > 3) {
                    $count = 3;
                }

                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="../blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                ?>
            </div>

            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>

        <script src="../js/jquery.js"></script>
        <script src="../js/flick.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/jquery.vmap.js" type="text/javascript"></script>
        <script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
        <script type="text/javascript">
            var email = '<?php echo $slikemail ?>';
            $('.alv').click(function() {
                var id = $(this).attr('id');
                
                if (email.length > 0) {
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            $('#' + id).html('<i class="icon icon-like"></i>&nbsp;&nbsp;&nbsp; Vote ' + xhttp.responseText);
                        }
                    };
                    xhttp.open("GET", "../handler.php?likevote&action=vote&reference=" + id + "&email=" + email, true);
                    xhttp.send(null);
                }
                else {
                    $('.likevote').removeClass('bounceOutDown').addClass('bounceInUp').css('display', 'block');
                }
            });

            $('.share a').click(function() {
                var id = $(this).attr('id');
                var href = $(this).attr('href');
                xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        $('#sharer' + id).html('<i class="icon icon-share"></i>&nbsp;&nbsp;&nbsp; Share ' + xhttp.responseText);
                    }
                };
                xhttp.open("GET", "../handler.php?likevote&action=share&&reference=" + id + "&email=" + email, true);
                xhttp.send(null);
            });



            $('#subscribeButton').click(function() {
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if (name.length > 0 && email.length > 0) {
                    $('#subscribeName').css('border-color', 'green');
                    $('#subscribeMail').css('border-color', 'green');
                    if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                        xhttp.onreadystatechange = function() {
                            if (xhttp.readyState === 4 && xhttp.status === 200) {
                                $('.subs').css('display', 'block');
                            }
                        };
                        xhttp.open("GET", "../handler.php?subscribe&email=" + email + "&name=" + name, true);
                        xhttp.send(null);
                    }
                    else {
                        $('#subscribeMail').css('border-color', 'red');
                    }
                }
                else {
                    $('#subscribeName').css('border-color', 'red');
                    $('#subscribeMail').css('border-color', 'red');
                }
            });</script>

    </body> 
    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>


    <div class="sideSocials blogSocial">
        <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
        <span>SHARE</span>
        <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-facebook"></i></a>
        <a class="google" href="http://plus.google.com/share?url=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-google"></i></a>
        <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link ?>&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
        <a class="twitter" href="http://www.twitter.com/<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-twitter"></i></a>
        <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url=<?php echo $actual_link ?>&media=http://missfashionweekafrica.com/images/mf.jpg" target="_blank"><i class="icon icon-social-pinterest"></i></a>

        <span class="co cl" data-action="close" title="Close Share Panel"><i class="icon icon-control-forward"></i><i class="icon icon-control-forward"></i></span>
        <span class="co op" data-action="open" title="Open Share Panel"><i class="icon icon-control-rewind"></i><i class="icon icon-control-rewind"></i></span>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div>  

    <div class="contactMsgi likevote vote animated bounceInRight col-sm-3">
        <h3 class="title">TO VOTE FAVOURITE MODEL <i class="icon icon-close pull-right" onclick="closecms();" style="cursor:pointer;"></i></H3>
        <div class="well text-center">Please enter a valid email address to Vote for your favorite Model throughout this browsing session.</div>
        <form action="" method="post">

            <input type="text" name="likemail" placeholder="Email Address" id="" class="col-sm-8 center-block" style="outline-color: rgba(0,0,0,0);margin-bottom:10px;padding:10px;"/>
            <button type="submit" class="close-btn center-block col-sm-4 col-xs-5 btn btn-primary" name="lebtn">Go</button>
        </form>
        <div class="clearfix"></div>
        <br/>
        <div class="well text-center">
            <a href="quickform" class="">OR Sign up with your facebook account to begin.</a>
            <br><br>
            <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
            <br><br>
        </div>

    </div>

    <div class="socialFrame">
        <iframe class="col-sm-8 center-block col-xs-8" name="socialframe"></iframe>
        <div class="col-sm-12 col-xs-12 text-center">
            <br/>
            <a class="closeFrame"><i class="icon icon-close"></i> Close</a>
        </div>
    </div>

    <script src="../js/main.js"></script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</html>
