<?php
include 'handler.php';
$contact = !empty($_POST['contact']) ? $_POST['contact'] : "";
$lebtn = !empty($_POST['lebtn']) ? $_POST['lebtn'] : "";
$slikemail = isset($_SESSION['likemail']) ? $_SESSION['likemail'] : "";
if (isset($lebtn)) {
    $likemail = isset($_POST['likemail']) ? $_POST['likemail'] : "";
    if (!empty($likemail)) {
        $_SESSION['likemail'] = $_POST['likemail'];
        $slikemail = $_SESSION['likemail'];
    }
}
if (isset($contact)) {
    $cm = filter_input(INPUT_POST, 'cemail');
    $cn = filter_input(INPUT_POST, 'cname');
    $cpn = filter_input(INPUT_POST, 'cpn');
    $cmsg = filter_input(INPUT_POST, 'cmessage');
    $date = date("D") . ' ' . date("m") . ', ' . date("Y");
    $ckdb = $mfdb->query("SELECT message,email FROM messages WHERE message='$cmsg' AND email='$cm'");
    if (mysqli_num_rows($ckdb) < 1) {
        $mfdb->query("INSERT INTO messages"
                . "(email,name,phone,message,type,date) "
                . "VALUES"
                . "('$cm','$cn','$cpn','$cmsg','inbox','$date')");
    }
}
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Home - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!--<meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/simple-line-icon.css">
        <link rel="stylesheet" href="css/animate.min.css">
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="fonts/font-awesome.css">
        <link rel="stylesheet" href="fonts/source-sans-pro.css">
        <link rel="stylesheet" href="css/flick.css">
        <link href="engine0/style.css" rel="stylesheet" type="text/css"/>
        <link href="engine1/style.css" rel="stylesheet" type="text/css"/>
        <link href="css/videojs.css" rel="stylesheet" type="text/css"/>
        <link href="css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery.videocontrols.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="css/main.css">
        <link rel="icon ico" href="images/mf.jpg">

    <body><div class="pageloader"><img src="images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <!--<div class="col-sm-4 col-xs-8 navTile animated bounceInLeft">
                    <h2>MISS <span>FASHION</span> WEEK</h2>
                    <div class="text lead">Africa Contest</div>
                </div> -->
                <ul>
                    <li><a href="" class="active">Home</a></li>
                    <li><a href="models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="models/">Contestants</a>
                            <a href="quickform/">Entry Form</a>
                            <a href='howitworks/'>HOW IT WORKS</a>
                            <a href="specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="judges/">Our Judges</a></li>
                    <li><a href="contact/">Contact Us</a></li>
                    <li><a href="about/">About Us</a></li>
                    <li><a href="blog/">Blog</a></li>
                    <li><a href="videos/">Videos</a></li>
                </ul>
                <div class="drop visible-xs">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <!-- Start WOWSlider.com BODY section --> <!-- add to the <body> of your page -->
        <div id="wowslider-container0">
            <div class="ws_images"><ul>
                    <li><img src="data0/images/model429241__copy.jpg" alt="Your Chance To Win $5,000 Grand Cash Price" title="Your Chance To Win $5,000 Grand Cash Price" id="wows0_0"/>Miss Fashion Week Africa</li>
                    <li><img src="data0/images/model429242_1920__copy.jpg" alt="Your Chance To Appear at the world famous New York Fashion Week" title="Your Chance To Appear at the world famous New York Fashion Week" id="wows0_1"/>Miss Fashion Week Africa</li>
                </ul></div>
            <div class="ws_bullets"><div>
                    <a href="#" title="Your Chance To Win $5,000 Grand Cash Price"><span><img src="data0/tooltips/model429241__copy.jpg" alt="Your Chance To Win $5,000 Grand Cash Price"/>1</span></a>
                    <a href="#" title="Your Chance To Appear at the world famous New York Fashion Week"><span><img src="data0/tooltips/model429242_1920__copy.jpg" alt="Your Chance To Appear at the world famous New York Fashion Week"/>2</span></a>
                </div></div><div class="ws_script" style="position:absolute;left:-99%"><a href="http://wowslider.net">http://wowslider.net/</a> by WOWSlider.com v8.7</div>
            <div class="ws_shadow"></div>
            <a href="join/" class="col-sm-3 col-xs-5 btn btn-danger applynow">APPLY NOW</a>
        </div>	
        <script type="text/javascript" src="engine0/wowslider.js"></script>
        <script type="text/javascript" src="engine0/script.js"></script>
        <!-- End WOWSlider.com BODY section -->

        <!-- Slider Begins -->

        <!-- Slider Ends -->


        <section class="modelStatue">
            <!-- <div class="modelsHomeTitle">
                 <h1>Miss Fashion Week <span>Africa</span></h1>
                 <div class="clearfix"></div>
                 <div class="balls">
                     <span></span>
                     <span></span>
                     <span></span>
                 </div>
             </div>
            -->
            <div class="statue col-sm-3 text-right">
                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3>Miss Fashion Week &nbsp;<i class="icon icon-globe"></i></h3>
                        Miss Fashion Week offers everyone the opportunity to chase their dreams.
                        Once you register, not only you have a chance to win some amazing awards, 
                        but you will... <a href="about/">Learn More</a>
                    </div>
                </div>

                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3>AMBASSADORS &nbsp;<i class="icon icon-briefcase"></i></h3>
                        Are you interested in being our brand ambassador? We  have opportunities
                        for people who share our vision to be part of our team. Send us your details 
                        through the contact us form <a href="contact/"> Here</a>
                    </div>
                </div>

                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3>Sponsors &nbsp;<i class="icon icon-briefcase"></i></h3>
                        Many corporations are asking how to get involved.
                        We have sponsorship opportunities available. 
                        Please click the button bellow 
                        to fill out a quick form to collaborate with us.
                        <a href="contact/">Click Here Now</a>
                    </div>
                </div>
            </div>

            <div class="statue statueMiddle col-sm-6">
                <h3 class="title">DO YOU HAVE WHAT IT TAKES? THE NEXT MISS FASHION WEEK STAR COULD COME FROM 
                    AFRICA! <span class="colouredTitle">IT COULD BE YOU OR SOMEONE YOU KNOW!!</span>
                </h3>
                <div class="statueMiddleBody">
                    Hooray!!! United States’ based Miss Fashion Week, LLC has included
                    the African continent in auditions for the 2017 Miss Fashion Week modeling contest.
                    Models and aspiring models in Africa can now compete with those from the rest 
                    of the world to win cash prizes, modeling contracts, access to international 
                    modeling agencies, fashion designers, photographers, fashion bloggers, 
                    publishers, and other relevant contacts in the industry.
                    <div class="clearfix"><br/></div>

                    Auditions have been concluded, and winners selected, in Tampa (Florida);
                    Orlando (Florida); Dallas (Texas); Austin (Texas); Salt Lake City (Utah);
                    Seattle (Washington); Tysons Corner (Virginia); Baltimore (Maryland);
                    District of Columbia; Knoxville (Tennessee); Harrisburg (Pennsylvania);
                    Johnson City (Tennessee); Toronto (Canada), The Bahamas; Puerto Rico; 
                    and India.  Auditions are now being held in other US major cities US and international countries.  
                    <div class="clearfix"><br/></div>

                    <b>Miss Fashion Week Africa:</b> Based on an exclusive agreement with Menes Konsult Limited
                    (of Dallas and Nigeria) and Europlaw Group Limited (of South Africa and UK), 
                    the African segment of the contest, Miss Fashion Week Africa, has become a reality.
                    Contestants must be of African origin. Current and aspiring models are encouraged
                    to register in petite and plus sizes, as well as, runway categories.  Three winners
                    from Africa (Miss Fashion Week Africa, First Runner-up, and Second Runner-up) will 
                    proceed to the grand finale in Florida, USA on December 10, 2016.
                    <div class="clearfix"><br/></div>


                </div>
            </div>

            <div class="statue col-sm-3 text-left">
                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3><i class="icon icon-notebook"></i>&nbsp; Rules And Regulations</h3>
                        TO BE ELIGIBLE FOR THIS PROGRAM YOU NEED TO BE:<br/>
                        1. An African model. <br/>
                        2. Between the age of 18 - 30 years <br/>
                        3. Possess a valid international passport with at least two (2) years to expiration date
                        <a href="rules/">Read Now</a>
                    </div>
                </div> 
                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3><i class="icon icon-wrench"></i>&nbsp; HOW IT WORKS</h3>
                        1). Check Your Eligibility  2). Enter to qualify 
                        3). Complete Application-Steps 1 to 3 4). Complete Application-Step 4 
                        5).  Complete Application-Step 5 6).Keep Informed... 
                        <a href="howitworks/">Learn More</a>
                    </div>
                </div>
                <div class="statueHolder col-sm-12 col-xs-12">
                    <div class="col-sm-12 col-xs-12">
                        <h3><i class="icon icon-picture"></i>&nbsp; Image and Video Spec</h3>
                        Know the specifications of the images and video to upload.
                        Correct type of images and video will enhance your chance to win. 
                        <a href="specs/">Learn More.</a>
                    </div>
                </div>

            </div>
        </section>

        <section class="achievements">
            <?php
            $ache = new dataBaseContent();
            $ach = $ache->webContent();
            ?>
            <div class="viel"></div>
            <div class="achieved-list">
                <div class="achieved">
                    <h2 class="achieved-head picTag"><i class="icon icon-people"></i></h2>
                    <span>MODELS</span>
                    <h2 class="achieved-head"><?php echo $ach[0]['MODELS']; ?></h2>
                </div>
                <div class="achieved">
                    <h2 class="achieved-head picTag"><i class="icon icon-picture"></i></h2>
                    <span>PHOTOS</span>
                    <h2 class="achieved-head"><?php echo $ach[0]['PHOTOS']; ?></h2>
                </div>
                <div class="achieved">
                    <h2 class="achieved-head picTag"><i class="icon icon-globe"></i></h2>
                    <span>COUNTRIES</span>
                    <h2 class="achieved-head"><?php echo $ach[0]['COUNTRIES']; ?></h2>
                </div>
                <div class="achieved">
                    <h2 class="achieved-head picTag"><i class="icon icon-briefcase"></i></h2>
                    <span>CITIES</span>
                    <h2 class="achieved-head"><?php echo $ach[0]['CITIES']; ?></h2>
                </div>
                <div class="achieved">
                    <h2 class="achieved-head picTag"><i class="icon icon-credit-card"></i></h2>
                    <span>GRAND PRICE</span>
                    <h2 class="achieved-head"><?php echo $ach[0]['GRANDPRICE']; ?></h2>
                </div>
            </div>
        </section>


        <!-- <section class="about htm team col-sm-12 col-xs-12 center-block">
            <!--<div class="modelsHomeTitle">
                <h1><span class="colouredTitle">Top</span> Models</h1>
                <div class="col-sm-12">
                    <a href="models/" class="allC col-sm-3 col-xs-6 center-block">View All</a>
                </div>
                <div class="clearfix"></div>
            </div>

            <?php
            /*$j = new dataBaseContent();
            $jd = $j->contestant();
            $count = 0;
            if (count($jd) > 4) {
                $count = 4;
            } else {
                $count = count($jd);
            }
            for ($i = 0; $i < $count; $i++) {
                $con = $jd[$i]['CONTESTANT'];
                $age = date("Y") - $jd[$i]['YEAR'];
                $pic = $mfdb->query("SELECT documentReference FROM applicationdocuments WHERE reference='$con' AND documentType='beauty'")->fetch_assoc();
                echo '<div class="col-lg-3 col-sm-6 col-xs-12 teamMate">
                <div class="tVeil">
                        <div class="ageH animate bounceInUp">
                            <div class="col-sm-6 col-xs-5">HEIGHT<br/> ' . $jd[$i]['HEIGHT'] . 'FT</div>
                            <div class="col-sm-6  col-xs-5">AGE<br/> ' . $age . '</div>
                        </div>
                </div>
                <div class="mate">
                    <img src="contestant/applicationFiles/contestData/' . $jd[$i]['CONTESTANT'] . '/' . $pic['documentReference'] . '" alt="" />
                        
                    <h4 class="name">' . $jd[$i]['FIRSTNAME'] . ' ' . $jd[$i]['LASTNAME'] . ' <span>' . $jd[$i]['COUNTRY'] . '</span></h4><br/>
                        <div class="socialTeam">
                            <a id="vote' . $jd[$i]['CONTESTANT'] . '" class="alv google" style="color:#fff !important;" data-action="vote" data-email="' . $slikemail . '"><i class="icon icon-like"></i>&nbsp;&nbsp;&nbsp; Vote ' . $jd[$i]['VOTES'] . '</a>
                        </div>
                        <div class="socialTeam share">
                            <span class="col-sm-12 col-xs-12 share-text google" id="sharer' . $jd[$i]['ID'] . '"><i class="icon icon-share"></i>&nbsp;&nbsp;&nbsp; Share ' . $jd[$i]['SHARES'] . '</span>
                            <a class="facebook" id="' . $jd[$i]['ID'] . '" data-share="facebook" href="https://www.facebook.com/sharer/sharer.php?u=missfashionweekafrica.com/contestant/dashBoard/' . $jd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-facebook"></i></a>
                            <a class="linkedin" id="' . $jd[$i]['ID'] . '" data-share="linkedin" href="https://www.linkedin.com/shareArticle?mini=true&url=missfashionweekafrica.com/contestant/dashBoard/' . $jd[$i]['ID'] . '.contestant&title=' . $jd[$i]['FIRSTNAME'] . '%40MissFashionWeekAfrica&summary=&source=missfashionweekafrica.com/contestant/dashBoard/' . $jd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-linkedin"></i></a>
                            <a class="twitter" id="' . $jd[$i]['ID'] . '" data-share="twitter" href="https://twitter.com/home?status=missfashionweekafrica.com/contestant/dashBoard/' . $jd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-twitter"></i></a>
                            <a class="google" id="' . $jd[$i]['ID'] . '" data-share="google" href="https://plus.google.com/share?url=missfashionweekafrica.com/contestant/dashBoard/' . $jd[$i]['ID'] . '.contestant" target="_blank"><i class="icon icon-social-google"></i></a>
                        </div>
                        

                        <div class="socialTeam">
                            <a class="google" href="contestant/dashBoard/' . $jd[$i]['CONTESTANT'] . '.contestant" style="color:#fff !important;"><i class="icon icon-eye"></i> VIEW PROFILE</a>
                        </div>
                </div>
            </div>';
            } */
            ?>

            <div class="clearfix"><br/></div>
        </section>
        <div class="clearfix"></div>

        <div class="col-sm-12 hv">
       
            <div class="col-sm-5 col-xs-12 hvList">
                <div class="col-sm-6 hlist">
                    <img src="contestant/applicationFiles/contestData/1/contestant5.jpe" alt=""/>
                    <div class="videoViel"><img src="images/playvideo.png" alt=""/></div>
                </div>
                <div class="col-sm-6 hlist">
                    <img src="contestant/applicationFiles/contestData/1/contestant5.jpe" alt=""/>
                    <div class="videoViel"><img src="images/playvideo.png" alt=""/></div>
                </div>
                <div class="col-sm-6 hlist">
                    <img src="contestant/applicationFiles/contestData/1/contestant5.jpe" alt=""/>
                    <div class="videoViel"><img src="images/playvideo.png" alt=""/></div>
                </div>
                <div class="col-sm-6 hlist">
                    <img src="contestant/applicationFiles/contestData/1/contestant5.jpe" alt=""/>
                    <div class="videoViel"><img src="images/playvideo.png" alt=""/></div>
                </div>
            </div>
        </div> -->
        <div class="clearfix"></div>


        <section class="sponsorList">
            <div class="js-flickity" data-flickity-options='{ "autoPlay": true, "freeScroll":true,"contain": true }'>
                <?php
                $g = new dataBaseContent();
                $gs = $g->sponsors();
                for ($i = 0; $i < count($gs); $i++) {
                    echo '<a href="' . $gs[$i]['LINK'] . '" title="' . $gs[$i]['NAME'] . '" target="_blank"><img src="images/sponsors/' . $gs[$i]['LOGO'] . '" alt=""/><span class="col-sm-12 center-block name">' . $gs[$i]['NAME'] . '</span></a>';
                }
                ?>
            </div>
            <!--<a href="contact/" class="become-sponsor">BECOME A SPONSOR</a> -->
        </section>






        <section class="contactForm">

            <div class="col-sm-6 pull-left">
                <div class="col-sm-12 title">
                    <span class="lineHr col-sm-3 col-xs-2"><span class="pull-left"></span></span>
                    <span class="col-sm-6 col-xs-8"><h3>Contact Us</h3></span>
                    <span class="lineHr col-sm-3 col-xs-2"><span class="pull-right"></span></span>
                </div>
                <form class="cForm col-sm-12 col-xs-12" action="" method="post">
                    <input type="text" placeholder="Full Name" class="col-sm-7 col-xs-6 pull-left" name="cname"/>
                    <input type="number" placeholder="Phone Number" class="col-sm-4 col-xs-5 pull-right" name="cpn"/>
                    <div class='clearfix'></div>
                    <input type="email" placeholder="Email" class="col-sm-12 col-xs-12" name="cemail"/>
                    <div class='clearfix'></div>
                    <textarea class="col-sm-12 col-xs-12" placeholder="Message..." required name="cmessage"></textarea>
                    <div class='clearfix'></div>
                    <button type="submit" class="btn col-sm-4 btn-default" name="contact">Submit</button>
                </form>

                <div class='clearfix'></div>

                <?php
                $aad = new dataBaseContent();
                $ad = $aad->webContent();
                ?>
                <div class="col-sm-12 addressing">
                    <div class="col-sm-6 addre col-xs-12">
                        <div class="col-sm-12 addreData"><i class="icon icon-phone"></i> Phone</div>
                        <div class="col-sm-12 addreValue"><?php echo $ad[0]['PHONE'] ?></div>
                    </div>
                    <div class="col-sm-6 addre col-xs-12">
                        <div class="col-sm-12 addreData"><i class="icon icon-envelope"></i> E-mail</div>
                        <div class="col-sm-12 addreValue"><?php echo $ad[0]['EMAIL'] ?></div>
                    </div>
                    <div class="clearfix hidden-xs"><br/><br/><br/></div>
                    <div class="col-sm-12 addre col-xs-12">
                        <div class="col-sm-12 addreData"><i class="icon icon-location-pin"></i> Office Address</div>
                        <div class="col-sm-12 addreValue"><?php echo $ad[0]['ADDRESS'] ?></div>
                    </div>
                </div>

            </div>
            <div class='clearfix visible-xs'><br/></div>
            <iframe class="col-sm-6 col-xs-12 pull-right map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3940.122694670876!2d7.4961747143266315!3d9.052571591113018!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104e0bb94dfb7de5%3A0x7ad6c4cf2db7dbba!2s78+Ralph+Shodeinde+St%2C+Abuja!5e0!3m2!1sen!2sng!4v1471943210091" frameborder="0" style="border:0;padding:0px;" allowfullscreen>
            </iframe>
            <div class="clearfix"></div>
        </section>




        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="email" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if (count($blog) > 3) {
                    $count = 3;
                }

                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                ?>
            </div>
            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>


        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/flick.js"></script>
        <script src="js/plugins.js"></script>
        <script type="text/javascript" src="js/grids.js"></script>
        <script src="js/videojs.js" type="text/javascript"></script>
        <script src="engine0/wowslider.js" type="text/javascript"></script>
        <script src="engine0/script.js" type="text/javascript"></script>
        <script type="text/javascript" src="engine1/script.js"></script>
        <script src="js/jquery.vmap.js" type="text/javascript"></script>
        <script src="js/jquery.vmap.world.js" type="text/javascript"></script>
        <script src="js/jquery.videocontrols.js" type="text/javascript"></script>
        <script type="text/javascript">


            $('#subscribeButton').click(function() {
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if (name.length > 0 && email.length > 0) {
                    $('#subscribeName').css('border-color', 'green');
                    $('#subscribeMail').css('border-color', 'green');
                    if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                        xhttp.onreadystatechange = function() {
                            if (xhttp.readyState === 4 && xhttp.status === 200) {
                                $('.subs').css('display', 'block');
                            }
                        };
                        xhttp.open("GET", "handler.php?subscribe&email=" + email + "&name=" + name, true);
                        xhttp.send(null);
                    }
                    else {
                        $('#subscribeMail').css('border-color', 'red');
                    }
                }
                else {
                    $('#subscribeName').css('border-color', 'red');
                    $('#subscribeMail').css('border-color', 'red');
                }
            });
        </script>


    </body> 

    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>


    <div class="sideSocials blogSocial">
        <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
        <span>SHARE</span>
        <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-facebook"></i></a>
        <a class="google" href="http://plus.google.com/share?url=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-google"></i></a>
        <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link ?>&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
        <a class="twitter" href="http://www.twitter.com/<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-twitter"></i></a>
        <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url=<?php echo $actual_link ?>&media=http://missfashionweekafrica.com/images/mf.jpg" target="_blank"><i class="icon icon-social-pinterest"></i></a>
        
        <span class="co cl" data-action="close" title="Close Share Panel"><i class="icon icon-control-forward"></i><i class="icon icon-control-forward"></i></span>
        <span class="co op" data-action="open" title="Open Share Panel"><i class="icon icon-control-rewind"></i><i class="icon icon-control-rewind"></i></span>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div> 
    <div class="contactMsgi likevote vote animated bounceInRight col-sm-3">
        <h3 class="title">TO VOTE FAVOURITE MODEL <i class="icon icon-close pull-right" onclick="closecms();" style="cursor:pointer;"></i></H3>
        <div class="well text-center">Please enter a valid email address to Vote for your favorite Model throughout this browsing session.</div>
        <form action="" method="post">

            <input type="text" name="likemail" placeholder="Email Address" id="" class="col-sm-8 center-block" style="outline-color: rgba(0,0,0,0);margin-bottom:10px;padding:10px;"/>
            <button type="submit" class="close-btn center-block col-sm-4 col-xs-5 btn btn-primary" name="lebtn">Go</button>
        </form>
        <div class="clearfix"></div>
        <br/>
        <div class="well text-center">
            <a href="quickform" class="">OR Sign up with your facebook account to begin.</a>
            <br><br>
            <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
            <br><br>
        </div>

    </div>

    <?php
    if (isset($contact)) {
        echo '<div class="contactMsgi animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> THANK YOU</H3>
        <div class="cmt text-center">Dear ' . $cn . ' Your message has been successfully sent to our officials. Messages are always reviewed after 1 business day.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div> ';
    }
    ?>
    <script src="js/main.js"></script>
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</html>
