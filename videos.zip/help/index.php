<?php
include '../handler.php';
?><!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Rules And Regulations - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
        <style>
            .isu a{
                color:#e74c3c !important;
            }
            .ans{
                font-size:medium;
                line-height:28px;
                color:#777;
                margin-bottom:65px;
                display:block;
                width:100%;
            }
            .ans a{
                font-size:medium;
                font-weight:bold;
                color:#2c3e50 !important;
                list-style:disc !important;
                display:block;
                margin-bottom:3px;
            }
            .ans a:not([id]){
                display:inline;
                font-size:small;
                color:#c0392b !important;
            }
        </style>
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-6 col-xs-6'>FAQ-FREQUENTLY ASKED QUESTIONS (HELP)</h2>
        </section>

        <div class='account howitworks isu col-sm-10 col-xs-11 center-block'>

            <div class='col-sm-9 col-xs-12 accountForms center-block'>
                <h4 class='title'>GENERAL ENQUIRY</h4>
                <ul>
                    <li><a href="#1">What is this competition all about?</a></li>
                    <li><a href="#2">How can I apply for the Miss Fashion Week Contest?</a></li>
                    <li><a href="#3">What are the requirements/criteria to participate?</a></li>
                    <li><a href="#4">Do I need to pay to participate?</a></li>
                    <li><a href="#5">Will there be physical auditions for models?</a></li>
                    <li><a href="#6">How will the Winners be selected?</a></li>
                    <li><a href="#7">What are the categories that will be judged?</a></li>
                    <li><a href="#8">Where and when is the grand finale?</a></li>
                    <li><a href="#9">I reside in -- -- -- country, can I still apply?</a></li>
                    <li><a href="#10">When is the contest going to take place?</a></li>
                    <li><a href="#11">When is the deadline to submit my application?</a></li>
                    <li><a href="#12">I am a fashion designer, photographer, publisher, etc and I would like to work/partner with yourcompany on this project.</a></li>
                    <li><a href="#13">I would like to be a promoter or brand ambassador for this contest.</a></li>
                </ul>
                <br/>
                <h4 class='title'>TECHNICAL ISSUES</h4>
                <ul>
                    <li><a href="#14">I am having issues with filling the Quick Entry Form.</a></li>
                    <li><a href="#15">My video is not uploading, what do I do?</a></li>
                    <li><a href="#16">I have submitted my Photos but I have not received any confirmation email.</a></li>
                </ul>
                <br/><br/><br/>
                <h4 class='title text-center'>GENERAL ENQUIRY</h4>

                <div class="ans">
                    <a id="1">What is this competition all about?</a>
                    United States’ based Miss Fashion Week, LLC has included the African continent in

                    auditions for the 2017 Miss Fashion Week modeling contest. Models and aspiring

                    models in Africa can now compete with those from the rest of the world to win

                    cash prizes, modeling contracts, access to international modeling agencies,

                    fashion designers, photographers, fashion bloggers, publishers, and other

                    relevant contacts in the industry. Current and aspiring models are encouraged to

                    register. Three winners from Africa (Miss Fashion Week Africa, First Runner-up,

                    and Second Runner-up) will proceed to the grand finale in Florida, USA in

                    December 2016. Prizes and Rewards: Three finalists from Africa will receive the

                    following goodies: - A total of $3,000 (plus opportunity to win the $5000 grand

                    finale cash prize) - Appearances at the world famous New York Fashion Week -

                    Modeling Contracts and Brand Ambassador Contracts - Access to international

                    modeling agencies, fashion designers, photographers, magazines, media,

                    bloggers, publishers, and other relevant contacts.
                </div>


                <div class="ans">
                    <a id="2">How can I apply for the Miss Fashion Week Contest?</a>
                    Hello, thanks for your interest. You must first qualify to compete in the Miss

                    Fashion Week Contest. Go to http://missfashionweekafrica.com/quickform/ to fill

                    a quick form and submit. Qualifying contestants will receive an email with

                    instructions on the next steps to take.
                </div>


                <div class="ans">
                    <a id="3">What are the requirements/criteria to participate?</a>
                    Hello, the Miss Fashion Week Africa is for all aspiring and existing African models

                    between the ages of 18-30yrs, you need to possess a valid International Passport

                    too, because three Winners from Africa will go on an all-expense paid trip to the

                    United States to take part in the grand finale.
                </div>


                <div class="ans">
                    <a id="4">Do I need to pay to participate?</a>
                    Hello, thanks for your interest. There is a $25 charge to apply. Miss Fashion Week

                    Africa is an international modeling contest for aspiring and existing models. Three

                    finalists from Africa will receive the following goodies: - A total of $3,000 (plus

                    opportunity to win the $5000 grand finale cash prize) - Appearances at the world

                    famous New York Fashion Week - Modeling Contracts and Brand Ambassador

                    Contracts - Access to international modeling agencies, fashion designers,

                    photographers, magazines, media, bloggers, publishers, and other relevant

                    contacts.
                </div>


                <div class="ans">
                    <a id="5">Will there be physical auditions for models?</a>
                    Hello, there are no auditions for this year, but that would be possible next year.

                    We want to give all models in Africa an equal chance to participate that is why

                    Miss Fashion Week Africa contest is based online this year.
                </div>


                <div class="ans">
                    <a id="6">How will the Winners be selected?</a>
                    Hello, go to <a href="http://missfashionweekafrica.com/howitworks/">http://missfashionweekafrica.com/howitworks/</a> to check out the

                    HOW IT WORKS page for details.
                </div>


                <div class="ans">
                    <a id="7">What are the categories that will be judged?</a>
                    Hi, the categories that will be judged are; Cat Walk Video, Head Shot Photo, Full-

                    Length Photo, Swimwear Photo, and Interview Video..
                </div>


                <div class="ans">
                    <a id="8">I reside in -- -- -- country, can I still apply?</a>
                    Hello, yes you can. The Miss Fashion Week Contest is online-based. As far as you

                    meet the requirements, you can take part from anywhere in the world.
                </div>


                <div class="ans">
                    <a id="9">When is the contest going to take place?</a>
                    The contest has started. Follow us on Facebook at

                    <a href="http://www.facebook.com/missfashionweekafrica">www.facebook.com/missfashionweekafrica</a> to stay updated on our

                    announcements.
                </div>


                <div class="ans">
                    <a id="10">When is the deadline to submit my application?</a>
                    Hello, when the application portal opens, the deadline to submit your application

                    would be 14 th of October 2016(subject to change).
                </div>

                <div class="ans">
                    <a id="11">I am a fashion designer, photographer, publisher, etc and I would like to work/partner with your company on this project.</a>
                    Hello, thanks for contacting us. Since this is the first contest, we wish to focus on

                    the models, but we will be open to partner with you next year. Please fill this

                    contact form so that we can get your details: <a href="http://missfashionweekafrica.com/contact/">http://missfashionweekafrica.com/contact/</a>

                    .Thank you
                </div>

                <div class="ans">
                    <a id="12">I would like to be a promoter or brand ambassador for this contest.</a>
                    Thanks for your interest. Please, send an email to

                    <a>team@missfashionweekafrica.com</a> with your full name, email and social media

                    accounts, including your website address if any and we will get in touch with you

                    to discuss further.
                </div>

                <br/><br/><br/>
                <h4 class='title text-center'>TECHNICAL ISSUES</h4>


                <div class="ans">
                    <a id="13">I am having issues with filling the Quick Form.</a>
                    To minimize issues in filling the quick form, make sure that you sign in with your

                    Facebook book account and your Facebook profile picture is showing at the top

                    part of the form. You might need to refresh page once you sign in with Facebook.

                    Then complete the form and upload your 60 seconds video. Only .MP4 Format is

                    allowed.
                </div>


                <div class="ans">
                    <a id="14">My video is not uploading, what do I do?.</a>
                    Make sure that your video format is .MP4 and no longer than 60 seconds then try

                    again. Try using another browser if error persist.

                    Send emails to <a>team@missfashionweekafrica.com</a> to report any problems

                    experienced in using the site.
                </div>


                <div class="ans">
                    <a id="15">I have submitted my Photos but I have not received any confirmation email.</a>
                    Hello, it might take 24hrs before you receive an email confirmation. However if it

                    takes longer than that, please send us an email at

                    <a>team@missfashionweekafrica.com</a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class='clearfix'></div>








        <!-- <div style="width:70% !important;display:block;margin:auto;padding:30px;text-align:left;"><p><img alt="" src="http://missfashionweekafrica.com/images/mf.jpg" style="display:block;margin:auto;"><br></p><p style="display:block;margin:auto;text-align:center;margin-bottom:60px;"><b>MISS FASHION WEEK AFRICA</b><br></p><p>Dear Kehinde Omotoso,<b><br></b></p><p>You have successfully been choosen to qualify for the MissFashionWeekAfrica contest. Your referencen number is MFWA_uhdj. Please log in to you account with the credentials bellow.<br></p><p>Email: familyomotosho@gmail.com<br></p><p>Password: abcdef.<br></p><p>Click here <a target="_blank" rel="nofollow" href="http://missfashionweekafrica.com/join/">http://missfashionweekafrica.com/join/</a> to login and start your application process. Please always check your email for further instructions. Good Luck.</p><p><br></p><p>Regards,&nbsp;Miss&nbsp;Fashion&nbsp;Week&nbsp;Africa.<br></p></div> -->








        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="text" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if (count($blog) > 3) {
                    $count = 3;
                }

                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="../blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                ?>
            </div>

            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>

        <script src="../js/jquery.js"></script>
        <script src="../js/flick.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/jquery.vmap.js" type="text/javascript"></script>
        <script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
        <script type="text/javascript">
            $('.submitPre').click(function(e) {
                e.preventDefault();
                var fname = $('#fn').val();
                var lname = $('#ln').val();
                var em = $('#em').val();
                var sq = $('#sq').val();
                var sa = $('#sa').val();
                if (fname.length > 0 && lname.length > 0 && em.length > 0 && sa.length > 0 && sq.length > 0) {
                    $('.regError').fadeOut(1000);
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            var res = xhttp.responseText;
                            if (res === '2') {
                                $('.regError').text('An account already created for "' + em + '".If you are the owner of this account, please wait for you payment to be confirmed and a password sent to your email. Thank you');
                                $('.regError').fadeIn(1000);
                            }
                            else if (res === '0') {
                                $('.regError').text('Account could not be created. If this problem persists please contact our officials at kenny@mfmail.com');
                                $('.regError').fadeIn(1000);
                            }
                        }
                    };
                    xhttp.open("GET", "../handler.php?preReg&email=" + em + "&fname=" + fname + "&lname=" + lname + "&sa=" + sa + "&sq=" + sq, true);
                    xhttp.send();
                }
                else {
                    $('.regError').fadeIn(1000);
                }
            });
            $('#subscribeButton').click(function() {
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if (name.length > 0 && email.length > 0) {
                    $('#subscribeName').css('border-color', 'green');
                    $('#subscribeMail').css('border-color', 'green');
                    if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                        xhttp.onreadystatechange = function() {
                            if (xhttp.readyState === 4 && xhttp.status === 200) {
                                $('.subs').css('display', 'block');
                            }
                        };
                        xhttp.open("GET", "../handler.php?subscribe&email=" + email + "&name=" + name, true);
                        xhttp.send(null);
                    }
                    else {
                        $('#subscribeMail').css('border-color', 'red');
                    }
                }
                else {
                    $('#subscribeName').css('border-color', 'red');
                    $('#subscribeMail').css('border-color', 'red');
                }
            });
        </script>

    </body> 
    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>



    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div>  


    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="../js/main.js"></script>
</html>
