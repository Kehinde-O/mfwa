<?php

session_start();

class dataBaseContent {

    public $connection;

    public function __construct() {

        if (!$this->connection) {
            self::connect('localhost', 'root', '', 'missfw');
			/*self::connect('localhost', 'fashion_missfw', '<?php ?>', 'missfw');*/
        }
    }

    public function connect($host, $user, $password, $db) {
        $this->connection = new mysqli($host, $user, $password, $db);
    }

    public function setFileDirPath($fileDirPath) {
        $this->fileDirPath = $fileDirPath;
    }

    public function setPostLimit($postLimit) {
        $this->postLimit = $postLimit;
    }

    public function getPosts() {
        $gp = $this->connection->query("SELECT * FROM blog ORDER BY id DESC");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ID' => $ap['id'],
                'TITLE' => $ap['title'],
                'TAG' => $ap['tag'],
                'PICTURE' => $ap['picture'],
                'CONTENT' => $ap['content'],
                'DATE' => $ap['date'],
                'LINK' => str_replace(' ', '_', strtolower($ap['title'])) . '.html'
            );
        }
        return $this->arrayPost;
    }
    
    public function videoList() {
        $gp = $this->connection->query("SELECT * FROM videos");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ID' => $ap['id'],
                'TITLE' => $ap['videoName'],
                'SRC' => $ap['videoReference'],
                'PICTURE' => $ap['picture'],
                'LIKES' => $ap['likes'],
                'VIEWS' => $ap['views'],
                'FBID' => $ap['fbid'],
                'CONTESTANT' => $ap['reference'],
                'DATE' => $ap['date'],
                'SURL' => $ap['shortLink']
            );
        }
        return $this->arrayPost;
    }

    public function webContent() {
        $gp = $this->connection->query("SELECT * FROM webcontent");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ABOUT' => $ap['webAbout'],
                'ABOUTPICTURE' => $ap['webAboutPicture'],
                'PHONE' => $ap['webPhone'],
                'EMAIL' => $ap['webEmail'],
                'ADDRESS' => $ap['webOfficeAddress'],
                'LONGTITUDE' => $ap['webOfficeLocationLongtitude'],
                'LATITUDE' => $ap['webLocationLatitude'],
                'COUNTRIES' => $ap['webCountriesTotal'],
                'MODELS' => $ap['webModelTotal'],
                'PHOTOS' => $ap['webPhotoTotal'],
                'CITIES' => $ap['webCitiesTotal'],
                'GRANDPRICE' => $ap['webGrandPriceTotal'],
                'WHATSAPP' => $ap['webWhatsappNumber']
            );
        }
        return $this->arrayPost;
    }

    public function judges() {
        $gp = $this->connection->query("SELECT * FROM judges");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'PICTURE' => $ap['picture'],
                'POSITION' => $ap['position'],
                'FIRSTNAME' => $ap['firstName'],
                'LASTNAME' => $ap['lastName'],
                'BIOGRAPHY' => $ap['biography']
            );
        }
        return $this->arrayPost;
    }

    public function winners() {
        $gp = $this->connection->query("SELECT * FROM winnermodel");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'PICTURE' => $ap['picture'],
                'TYPE' => $ap['type'],
                'FIRSTNAME' => $ap['firstName'],
                'LASTNAME' => $ap['lastName'],
                'YEAR' => $ap['year'],
                'EMAIL' => $ap['email'],
                'FBID' => $ap['fbid'],
                'CONTESTID' => $ap['contestid'],
                'COUNTRY' => $ap['country'],
                'LIKES' => $ap['likes'],
                'STATE' => $ap['state'],
                'WINNERFOR' => $ap['winnerfor']
            );
        }
        return $this->arrayPost;
    }

    public function team() {
        $gp = $this->connection->query("SELECT * FROM team");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'PICTURE' => $ap['picture'],
                'POSITION' => $ap['position'],
                'FIRSTNAME' => $ap['firstName'],
                'LASTNAME' => $ap['lastName'],
                'JOINYEAR' => $ap['joinYear']
            );
        }
        return $this->arrayPost;
    }

    public function contestant() {
        $gc = $this->connection->query("SELECT * FROM application ORDER BY vote DESC");
        while ($g = $gc->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ID' => $g['id'],
                'REFERENCE' => $g['reference'],
                'FIRSTNAME' => $g['firstName'],
                'LASTNAME' => $g['lastName'],
                'EMAIL' => $g['emailAddress'],
                'PHONE' => $g['phoneNumber'],
                'PHONE2' => $g['aphoneNumber'],
                'ADDRESS' => $g['homeAddress'],
                'ADDRESS2' => $g['ahomeAddress'],
                'COUNTRY' => $g['country'],
                'STATE' => $g['state'],
                'CITY' => $g['city'],
                'HEIGHT' => $g['height'],
                'GENDER' => $g['gender'],
                'APPSTATUS' => $g['applicationStatus'],
                'DAY' => $g['ageDay'],
                'MONTH' => $g['ageMonth'],
                'YEAR' => $g['ageYear'],
                'REASON' => $g['reason'],
                'SHARES' => $g['share'],
                'VOTES' => $g['vote']
            );
        }
        return $this->arrayPost;
    }

   

    public function sponsors() {
        $gs = $this->connection->query("SELECT * FROM sponsors ORDER BY id DESC");
        while ($g = $gs->fetch_assoc()) {
            $this->res[] = array(
                'NAME' => $g['name'],
                'LINK' => $g['link'],
                'LOGO' => $g['logo']
            );
        }

        return $this->res;
    }

}

$mffdb = new dataBaseContent();
$mfdb = $mffdb->connection;
$wcc = new dataBaseContent();
$wc = $wcc->webContent();




if (isset($_REQUEST['subscribe'])) {
    $email = $_REQUEST['email'];
    $name = $_REQUEST['name'];
    $mfdb->query("INSERT INTO schedulesubscriber"
            . "(email,fullName) "
            . "VALUES"
            . "('$email','$name')");
}




if (isset($_REQUEST['likevote'])) {
    $action = $_REQUEST['action'];
    $reference = $_REQUEST['reference'];
    $email = $_REQUEST['email'];
    if ($action === 'share') {
        $getAction = $mfdb->query("SELECT share AS dbaction FROM application WHERE reference='$reference'")->fetch_assoc();
        $olddata = $getAction['dbaction'] + 1;
        $mfdb->query("INSERT INTO likers"
                . "(email,actionPerformed,actionContestant) VALUES"
                . "('$email','share','$reference')");
        $mfdb->query("UPDATE application SET share='$olddata' WHERE reference='$reference'");
        echo $olddata;
    } else if ($action === 'vote') {
        $reference = str_replace('vote', '', $reference);
        $seeaction = $mfdb->query("SELECT * FROM likers WHERE email='$email' AND actionPerformed='vote' AND actionContestant='$reference'");
        if (mysqli_num_rows($seeaction) > 0) {
            $getAction = $mfdb->query("SELECT vote AS dbaction FROM application WHERE reference='$reference'")->fetch_assoc();
            echo $olddata = $getAction['dbaction'];
        } else {
            $getAction = $mfdb->query("SELECT vote AS dbaction FROM application WHERE reference='$reference'")->fetch_assoc();
            $olddata = $getAction['dbaction'] + 1;
            $mfdb->query("INSERT INTO likers"
                    . "(email,actionPerformed,actionContestant) VALUES"
                    . "('$email','vote','$reference')");
            $mfdb->query("UPDATE application SET vote='$olddata' WHERE reference='$reference'");
            echo $olddata;
        }
    }
}

/* $seeaction = $mfdb->query("SELECT * FROM likers WHERE email='$email' AND actionPerformed='$action' AND actionContestant='$reference'");
  if (mysqli_num_rows($seeaction) > 0) {
  echo 1;
  } else {
  $getAction = $mfdb->query("SELECT $action AS dbaction FROM application WHERE reference='$reference'")->fetch_assoc();
  $olddata = $getAction['dbaction'] + 1;
  $mfdb->query("INSERT INTO likers"
  . "(email,actionPerformed,actionContestant) VALUES"
  . "('$email','$action','$reference')");
  $mfdb->query("UPDATE application SET $action='$olddata' WHERE reference='$reference'");
  } */

if (isset($_REQUEST['blogsub'])) {
    $email = $_REQUEST['email'];
    $mfdb->query("INSERT INTO blogsubscribers(email) VALUES('$email')");
    echo 1;
}

$auto = $mfdb->query("SELECT * FROM quickform");
while($a = $auto->fetch_assoc()){
    $re = $a['reference'];
    $auto2 = $mfdb->query("SELECT * FROM quickform WHERE reference='$re'")->fetch_assoc();
    $sem = $auto2['email'];
    $fn = $auto2['firstName'];
    $ln = $auto2['lastName'];
    $nextDate=$a['nextDate'];
    $nextmsg=$a['nextMsg'];
    $pw = $auto2['pw'];
    $today = date("d/m/Y");
    if($today === $nextDate && $nextmsg === 'false'){
        $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/images/mf.jpg"><br><br/><br/>'
                . 'Hurray! You have QUALIFIED to take part in the Miss Fashion Week Africa 2017 Contest. <br/><br/>'
                . 'You are few steps closer to making your dreams come true. '
                . '<br/><br/>Go to http://missfashionweekafrica.com/join/ to log-in and create a profile. Use the below log-in details:<br/><br/>'
                . 'Username: '.$sem.'<br/><br/>Password: '.$pw.'.<br><br/>'
                . '(You would be asked to change your password to a new password of your choice once you log-in.)<br/><br/>'
                . 'We believe you have what it takes to become Miss Fashion Week Africa. But are you going to be part of the three (3) winners from Africa to attend the grand finale in Miami,USA in Dec. 10th 2016? Would you win part of the $3000 and an additional chance to win $5,000 at the grand finale? You do not want to miss out on the opportunity to  get signed by an International Modelling Agency and appearance in New York Fashion Week. Not forgetting the contacts and exposure you would receive!<br/><br/>'
                . 'So register now! This is a one in a million opportunity.<br/><br/>'
                . 'Some of the contestants from Miss Fashion Week USA have a message for you! <a href="https://www.youtube.com/watch?v=jIprtG36nbU&feature=youtu.be">Click Here</a> and <a href="https://www.youtube.com/watch?v=zIRcgcG6VF8&feature=youtu.be">Click Here</a> to watch two short clips from  Jazzman Monee - Dallas, Texas and Alexis Musick - Nashville,Tennessee.<br/><br/>'
                . 'Have any questions? Email us at team@missfashionweekafrica.com.<br/><br/>'
                . 'FOLLOW US:<br/>'
                . 'Instagram: http://www.instagram.com/missfashionweekafrica<br/>'
                . 'Website: http://www.missfashionweekafrica.com<br/>'
                . 'Facebook: http://www.facebook.com/missfashionweekafrica<br/>'
                . 'YouTube: www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA<br/><br/>'
                . 'Thank you!<br/><br/>'
                . 'Miriam N.<br/> Project Coordinator.';
        $headers = "From: support@missfashionweekafrica.com \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($sem, 'Hurray! you qualify! - MissFashionWeekAfrica', $mailmsg, $headers);
        $mfdb->query("UPDATE quickform SET nextMsg='true' WHERE reference='$re'");
    }
}
$monthname = array('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec');
$stats = $mfdb->query("SELECT year FROM statistics ORDER BY year DESC")->fetch_assoc();
$lastyear = $stats['year'];
$thisyear = date("Y");
$thismonth = date("M");
if($lastyear < $thisyear){
    for($i = 0; $i < count($monthname); $i++){
        $mfdb->query("INSERT INTO statistics(monthname,data,year,value) "
            . "VALUES('$monthname[$i]','newmembers','$thisyear','0')");
    }
    for($i = 0; $i < count($monthname); $i++){
        $mfdb->query("INSERT INTO statistics(monthname,data,year,value) "
            . "VALUES('$monthname[$i]','visitors','$thisyear','0')");
    }
    for($i = 0; $i < count($monthname); $i++){
        $mfdb->query("INSERT INTO statistics(monthname,data,year,value) "
            . "VALUES('$monthname[$i]','income','$thisyear','0')");
    }
    
}
$getv = $mfdb->query("SELECT * FROM statistics WHERE data='visitors' AND monthname='$thismonth' AND year='$thisyear'")->fetch_assoc();
$oldv = $getv['value']+1;
$mfdb->query("UPDATE statistics SET value='$oldv' WHERE data='visitors' AND monthname='$thismonth' AND year='$thisyear'");


//echo '<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>';