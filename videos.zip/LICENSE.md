Copyright (c) Miss Fashion Week Africa

Permision is now granted for the edit and customization of this software by kehinde omotoso