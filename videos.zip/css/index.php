<?php
header('location:../');
echo 'ACCESS DENIED.';