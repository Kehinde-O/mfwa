<?php
include '../server/index.php';
$action = $_REQUEST['action'];
$operator = $_SESSION['operator'];

if (isset($_POST['adduser'])) {
    $username = $_POST['newusername'];
    $password = md5($_POST['newuserpassword']);
    $userfname = $_POST['userfname'];
    $userlname = $_POST['userlname'];
    $userpic = $_FILES['userpic']['tmp_name'];
    $userpicname = $_FILES['userpic']['name'];
    $year = date("Y");
    $bio = $_POST['bio'];
    $privilege = $_POST['newuserprivilege'];
    if ($privilege === 'Select Privilege') {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select a privilege for User "' . $username . '".<br/><br/><br/></div><div class="clearfix"></div>';
    } else if ($privilege === 'Judge') {
        $check = $c->query("SELECT username,privilege FROM systemusers WHERE username='$username'");
        if (mysqli_num_rows($check) > 0) {
            $checki = $check->fetch_assoc();
            $oldprivilege = $checki['privilege'];
            $error = '<div class="text-danger text-center col-sm-12"><br/>Sorry This Username: "' . $username . '" Already Exist with "' . $oldprivilege . '" privilege.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            if (move_uploaded_file($userpic, '../../images/judges/' . $userpicname)) {
                $c->query("INSERT INTO systemusers "
                        . "(username,password,privilege,firstName,lastName,picture) "
                        . "VALUES"
                        . "('$username','$password','$privilege','$userfname','$userlname','$userpicname')");
                $c->query("INSERT INTO judges"
                        . "(picture,position,firstName,lastName,joinYear,biography) "
                        . "VALUES"
                        . "('$userpicname','','$userfname','$userlname','$year','$bio')");
                $error = '<div class="text-success text-center col-sm-12"><br/>New user "' . $username . '" successfuly created with "' . $privilege . '" privilege.<br/><br/><br/></div><div class="clearfix"></div>';
            }
        }
    } else {
        $check = $c->query("SELECT username,privilege FROM systemusers WHERE username='$username'");
        if (mysqli_num_rows($check) > 0) {
            $checki = $check->fetch_assoc();
            $oldprivilege = $checki['privilege'];
            $error = '<div class="text-danger text-center col-sm-12"><br/>Sorry This Username: "' . $username . '" Already Exist with "' . $oldprivilege . '" privilege.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            if (move_uploaded_file($userpic, '../../images/judges/' . $userpicname)) {
                $c->query("INSERT INTO systemusers "
                        . "(username,password,privilege,firstName,lastName,picture) "
                        . "VALUES"
                        . "('$username','$password','$privilege','$userfname','$userlname','$userpicname')");
                $error = '<div class="text-success text-center col-sm-12"><br/>New user "' . $username . '" successfuly created with "' . $privilege . '" privilege.<br/><br/><br/></div><div class="clearfix"></div>';
            }
        }
    }
}

if (isset($_POST['rmu'])) {
    $username = $_POST['removinguser'];
    $password = md5($_POST['operatorpassword']);
    $gu = $c->query("SELECT * FROM systemusers WHERE username='$username'")->fetch_assoc();
    if ($username === 'Select User') {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select a user to remove.<br/><br/><br/></div><div class="clearfix"></div>';
    } else {
        $check = $c->query("SELECT password FROM systemusers WHERE username='$operator'")->fetch_assoc();
        if ($check['password'] === $password) {
            $c->query("DELETE FROM systemusers WHERE username='$username'");
            $fname = $gu['firstName'];
            $lname = $gu['lastName'];
            $c->query("DELETE FROM judges WHERE firstName='$fname' AND lastName='$lname'");
            $error = '<div class="text-success text-center col-sm-12"><br/>User: "' . $username . '" has been successfuly removed with all its privilege.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            $error = '<div class="text-danger text-center col-sm-12"><br/>Please Enter a correct password.<br/><br/><br/></div><div class="clearfix"></div>';
        }
    }
}

if (isset($_POST['cup'])) {
    $username = $_POST['olduser'];
    $password = md5($_POST['operatorpassword']);
    $privilege = $_POST['newprivilege'];
    if ($username === 'Select User') {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select a user.<br/><br/><br/></div><div class="clearfix"></div>';
    } else if ($privilege === 'Select New Privilege') {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select a new privilege.<br/><br/><br/></div><div class="clearfix"></div>';
    } else {
        $check = $c->query("SELECT password FROM systemusers WHERE username='$operator'")->fetch_assoc();
        if ($check['password'] === $password) {
            $c->query("UPDATE systemusers SET privilege='$privilege' WHERE username='$username'");
            $error = '<div class="text-success text-center col-sm-12"><br/>Privilege for User: "' . $username . '" has been successfuly changed.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            $error = '<div class="text-danger text-center col-sm-12"><br/>Please Enter a correct password.<br/><br/><br/></div><div class="clearfix"></div>';
        }
    }
}


if (isset($_POST['cupa'])) {
    $username = $_POST['usercp'];
    $userpassword = md5($_POST['newuserpassword']);
    if ($username === 'Select User') {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select a user.<br/><br/><br/></div><div class="clearfix"></div>';
    } else {
        $c->query("UPDATE systemusers SET password='$userpassword' WHERE username='$username'");
        $error = '<div class="text-success text-center col-sm-12"><br/>Password for User: "' . $username . '" has been successfuly changed.<br/><br/><br/></div><div class="clearfix"></div>';
    }
}

if (isset($_POST['delvercon'])) {
    $act = $_POST['delveract'];
    $ref = $_POST['delconref'];
    if ($act === 'Verify') {
        $ckc = $c->query("SELECT * FROM application WHERE reference='$ref'");
        if (mysqli_num_rows($ckc) > 0) {
            $c->query("UPDATE quickform SET accountStatus='Verified' WHERE reference='$ref'");
            $c->query("UPDATE application SET applicationStatus='completed' WHERE reference='$ref'");
            $error = '<div class="text-success text-center col-sm-12"><br/>Application with reference: "' . $ref . '" has been successfuly Verified.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            $error = '<div class="text-danger text-center col-sm-12"><br/>Applicant must complete profile information before verification.<br/><br/><br/></div><div class="clearfix"></div>';
        }
    } else if ($act === 'Delete Account with Files') {
        if ($c->query("DELETE FROM application WHERE reference='$ref'") && $c->query("DELETE FROM quickform WHERE reference='$ref'") && $c->query("DELETE FROM videos WHERE reference='$ref'")) {
            /* $delv = $c->query("SELECT * FROM videos WHERE reference='$ref'");
              while($del = $delv->fetch_assoc()){
              unlink('../../videos/'.$del['videoReference']);
              }
              $delv = $c->query("SELECT * FROM applicationdocuments WHERE reference='$ref'");
              while($del = $delv->fetch_assoc()){
              unlink('../../images/models/'.$del['videoReference']);
              } */
            $error = '<div class="text-success text-center col-sm-12"><br/>Application with reference: "' . $ref . '" has been successfuly Deleted.<br/><br/><br/></div><div class="clearfix"></div>';
        } else {
            $error = '<div class="text-danger text-center col-sm-12"><br/>No application exist with this reference number ' . $ref . '.<br/><br/><br/></div><div class="clearfix"></div>';
        }
    }
    else if ($act === 'Reset') {
            $reference = $ref;
            if ($c->query("UPDATE quickform SET applied='false',secondmedia='false',thirdmedia='false',lastmedia='false',appprocess='false',step='1' WHERE reference='$reference'")) {
                $c->query("DELETE FROM application WHERE reference='$ref'");
                $c->query("DELETE FROM applicationdocuments WHERE reference='$ref'");
                $error = '<div class="text-success text-center col-sm-12"><br/>Application with reference: "' . $ref . '" has successfuly been reset.<br/><br/><br/></div><div class="clearfix"></div>';
            } else {
                $error = '<div class="text-danger text-center col-sm-12"><br/>No application found with reference: "' . $ref . '".<br/><br/><br/></div><div class="clearfix"></div>';
            }
        }
        else if ($act === 'Reset Judgement') {
            $reference = $ref;
            if ($c->query("UPDATE applicationdocuments SET judged='false' WHERE reference='$reference'")) {
                $c->query("UPDATE videos SET judged='false' WHERE reference='$reference'");
                $c->query("UPDATE application SET judged='uncompleted',lastStepJudged='0',catwalkscore='0',headshotscore='0',fulllenghtscore='0',swimwearscore='0',interviewscore='0',totalscore='0' WHERE reference='$reference'");
                $error = '<div class="text-success text-center col-sm-12"><br/>Judgement For Application with reference: "' . $ref . '" has successfuly been reset.<br/><br/><br/></div><div class="clearfix"></div>';
            } else {
                $error = '<div class="text-danger text-center col-sm-12"><br/>No application found with reference: "' . $ref . '".<br/><br/><br/></div><div class="clearfix"></div>';
            }
        }
        else {
        $error = '<div class="text-danger text-center col-sm-12"><br/>Please select action bellow.<br/><br/><br/></div><div class="clearfix"></div>';
    }
}

$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if ($_SESSION['privilege'] === 'Judge' || $_SESSION['privilege'] === 'Blog Manager') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}

$operator = $_SESSION['operator'];
$picture = $c->query("SELECT picture FROM systemusers WHERE username='$operator'")->fetch_assoc();
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Kehinde Omotoso Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../css/pace.css" rel="stylesheet" type="text/css"/>
        <style>
            .<?php echo $action ?>{
                display:block !important;
            }
        </style>
    </head>
    <body>
        <header class="header">
            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../system/?logout=true"><li class="icon icon-power"></li></a>
            </ul>
            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href=""><?php echo $action ?></a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../images/site.png" alt=""/>
            <img class="adminlogo" src="<?php if ($picture['picture'] === '') {
    echo '../../images/loading.gif';
} else {
    echo '../../images/judges/' . $picture['picture'];
} ?>" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../contestants/nominated.view"><i class="icon icon-like"></i> Nominated Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li class="active"><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../website/affiliate.settings"><i class="icon icon-user"></i>Add Affiliate</a></li>
                        <li><a href="../website/viewaffiliate.settings"><i class="icon icon-user"></i>View Affiliate</a></li>
                        <li><a href="../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <!-- MAIN CONTENT STARTS HERE -->
        <section class="mainContent col-sm-11 col-xs-11 pull-right system">
            <!--Add system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-8 loginbox addUser">
                <h2 class="title"><i class="icon icon-user" style=""></i> ADD SYSTEM USER</h2>
<?php echo $error ?>
                <form class="loginForm col-sm-10 col-xs-10 center-block" action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="userfname" placeholder="First Name" required/>
                    <input type="text" name="userlname" placeholder="Last Name" required/>
                    <input type="file" name="userpic"/>
                    <input type="text" name="newusername" placeholder="UserName" required/>
                    <input type="password" name="newuserpassword" placeholder="Password" required/>
                    <select name="newuserprivilege" id="privilege">
                        <option>Select Privilege</option>
                        <?php
                        if ($_SESSION['privilege'] === 'Admin') {
                            echo '<option>Admin</option>';
                        }
                        ?>
                        <option>Judge</option>
                        <option>Blog Manager</option>
                        <option>Tech Support</option>
                    </select>
                    <textarea rows="6" name="bio" placeholder="Biography" id="bio" style="display:none;" maxlength="255"></textarea>
                    <button type="submit" class="btn btn-primary" name="adduser">Add</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Add system User----------------------End--------------------- -->


            <!--Remove system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-8 loginbox removeUser">
                <h3 class="title"><i class="icon icon-user" style=""></i> REMOVE SYSTEM USER</h3>
<?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-10 center-block" action="" method="post">
                    <select name="removinguser">
                        <option>Select User</option>
                        <?php
                        if ($_SESSION['privilege'] === 'Admin') {
                            $s = $c->query("SELECT * FROM systemusers");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        } else {
                            $s = $c->query("SELECT * FROM systemusers WHERE privilege !='Admin'");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        }
                        ?>
                    </select>
                    <input type="password" name="operatorpassword" placeholder="Enter Your Password" required/>
                    <button type="submit" class="btn btn-danger" name="rmu">Remove</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Remove system User----------------------End--------------------- -->


            <!--Remove system User---------------------------------------------- -->
<?php $su = $c->query("SELECT * FROM systemusers"); ?>
            <div class="col-sm-5 col-xs-8 loginbox viewUsers">
                <h3 class="title"><i class="icon icon-screen-desktop" style=""></i> ALL SYSTEM USERS (<?php echo mysqli_num_rows($su) ?>)</h3>
                <div class="clearfix"></div>
                <?php
                $su = $c->query("SELECT * FROM systemusers");
                while ($suu = $su->fetch_assoc()) {
                    echo '<div class="col-sm-12 allu">
                        <div class="col-sm-4">' . $suu['username'] . '</div>
                        <div class="col-sm-4">' . $suu['privilege'] . '</div>
                        <div class="col-sm-4">S/N ' . $suu['id'] . '</div>
                    </div>';
                }
                ?>

                <br/>
                <br/>
                <br/>
                <br/>
                <div class="clearfix"></div>
            </div>
            <!--Remove system User----------------------End--------------------- -->



            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-8 loginbox changePrivilege">
                <h3 class="title"><i class="icon icon-user" style=""></i> Change SYSTEM USER Privilege</h3>
<?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-10 center-block" action="" method="post">
                    <select name="olduser">
                        <option>Select User</option>
                        <?php
                        if ($_SESSION['privilege'] === 'Admin') {
                            $s = $c->query("SELECT * FROM systemusers");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        } else {
                            $s = $c->query("SELECT * FROM systemusers WHERE privilege !='Admin'");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        }
                        ?>
                    </select>
                    <select name="newprivilege">
                        <option>Select New Privilege</option>
                        <option>Admin</option>
                        <option>Judge</option>
                        <option>Blog Manager</option>
                        <option>Tech Support</option>
                    </select>
                    <input type="password" name="operatorpassword" placeholder="Enter Your Password" required/>
                    <button type="submit" class="btn btn-danger" name="cup">Change</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->


            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-8 loginbox changePassword">
                <h3 class="title"><i class="icon icon-user" style=""></i> Change SYSTEM USER Password</h3>
<?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-10 center-block" action="" method="post">
                    <select name="usercp">
                        <option>Select User</option>
                        <?php
                        if ($_SESSION['privilege'] === 'Admin') {
                            $s = $c->query("SELECT * FROM systemusers");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        } else {
                            $s = $c->query("SELECT * FROM systemusers WHERE privilege !='Admin'");
                            while ($si = $s->fetch_assoc()) {
                                echo '<option>' . $si['username'] . '</option>';
                            }
                        }
                        ?>
                    </select>

                    <input type="password" name="newuserpassword" placeholder="Enter New User Password" required/>
                    <button type="submit" class="btn btn-primary" name="cupa">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->


            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-8 loginbox delvercon">
                <h3 class="title"><i class="icon icon-users" style=""></i> Perform Action For Contestant</h3>
<?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-10 center-block" action="" method="post">
                    <input type="text" name="delconref" placeholder="Enter Contestant's Reference Number" required/>
                    <select name="delveract">
                        <option>Select Action</option>
                        <option>Verify</option>
                        <option>Reset</option>
                        <option>Reset Judgement</option>
                        <option>Delete Account with Files</option>
                    </select>
                    <button type="submit" class="btn btn-primary" name="delvercon">Take Action</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->




        </section>

        <!-- MAIN CONTENT ENDS HERE -->



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/bootstrap.js" type="text/javascript"></script>
        <script src="../js/pace.js" type="text/javascript"></script>
        <script src="../js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
        <script src="../js/mapstat.js" type="text/javascript"></script>
        <script src="../js/Chart.js" type="text/javascript"></script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">
            /*$('.rmus').click(function(){
             var username = $(this).attr('data-uname');
             var id = $(this).attr('id');
             confirm('Are you sure you want to remove "'+username+'" from system users?');
             });*/
            $('#privilege').change(function() {
                var val = $(this).find('option:selected').val();
                if (val === 'Judge') {
                    $('#bio').fadeIn(1000);
                }
                else {
                    $('#bio').fadeOut(1000).css('display', 'none');
                }
            });
        </script>
    </body>
</html>
