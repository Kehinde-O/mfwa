<?php
    include '../server/index.php';
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $auth = $c->query("SELECT * FROM systemusers WHERE username='$username' AND password='$password'");
        $cauth = $auth->fetch_assoc();
        if(mysqli_num_rows($auth) > 0){
            if($username === $cauth['username'] && $password === $cauth['password']){
                $_SESSION['operator'] = $cauth['username'];
                $_SESSION['privilege'] = $cauth['privilege'];
                if($_SESSION['privilege'] === 'Admin'){
                    header('location:../');
                }else if($_SESSION['privilege'] === 'Judge'){
                    header('location:../contestants/applications/');
                }else if($_SESSION['privilege'] === 'Blog Manager'){
                    header('location:../website/blogPost.settings');
                }else if($_SESSION['privilege'] === 'Tech Support'){
                    header('location:../website/contactPhone.settings');
                }
            }
            else{
                $error = '<div class="text-danger text-center col-sm-12">Incorect username or password. Please beware of case sensitivity.<br/><br/></div><div class="clearfix"></div>';
            }
        }
        else{
            $error = '<div class="text-danger text-center col-sm-12">Incorect username or password.<br/><br/></div><div class="clearfix"></div>';
        }
    }
    if(!isset($_SESSION['error'])){
        $error = $error;
    }
    else{
        $error = $_SESSION['error'];
    }
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Kehinde Omotoso Admin Template</title>
        <meta charset="UTF-8">
        <meta name="author" content="Kehinde Omotoso"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/bootstrap.css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/style.css"/>
        <link rel="stylesheet" href="../css/animate.min.css"/>
    </head>
    <body>
        <section class="loginPage col-sm-12">
            <div class="col-sm-3 col-xs-8 loginbox">
                <h2 class="title"><i class="icon icon-shield" style=""></i> Official Login</h2>
                <?php echo $error ?>
                <form class="loginForm col-sm-12 col-xs-10 center-block" action="" method="post">
                    <input type="text" name="username" placeholder="User Name" required/>
                    <input type="password" name="password" placeholder="Password" required/>
                    <button type="submit" class="btn btn-primary" name="login">Login</button>
                </form>
                <div class="clearfix"></div>
            </div>
        </section>
    </body>
</html>

<?php
    $_SESSION['error'] ='';

?>