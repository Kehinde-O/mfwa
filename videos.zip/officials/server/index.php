<?php

session_start();

class server {

    public $user;
    public $privilege;
    public $authenticate;
    public $goto;
    public $connection;

    public function __construct() {
        if (!$this->connection) {
            self::connect('localhost', 'root', '', 'missfw');
			/*self::connect('localhost', 'fashion_missfw', '<?php ?>', 'missfw');*/
        }
    }

    public function connect($host, $user, $password, $db) {
        $this->connection = mysqli_connect($host, $user, $password, $db) or die('Error: Cannot connect to database with this connection.');
    }

    public function webContent() {
        $gp = $this->connection->query("SELECT * FROM webcontent");
        while ($ap = $gp->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ABOUT' => $ap['webAbout'],
                'ABOUTPICTURE' => $ap['webAboutPicture'],
                'PHONE' => $ap['webPhone'],
                'EMAIL' => $ap['webEmail'],
                'ADDRESS' => $ap['webOfficeAddress'],
                'LONGTITUDE' => $ap['webOfficeLocationLongtitude'],
                'LATITUDE' => $ap['webLocationLatitude'],
                'COUNTRIES' => $ap['webCountriesTotal'],
                'MODELS' => $ap['webModelTotal'],
                'PHOTOS' => $ap['webPhotoTotal'],
                'JUDGES' => $ap['webJudgesTotal'],
                'GRANDPRICE' => $ap['webGrandPriceTotal'],
                'WHATSAPP' => $ap['webWhatsappNumber']
            );
        }
        return $this->arrayPost;
    }

    public function contestant() {
        $gc = $this->connection->query("SELECT * FROM application WHERE applicationStatus='completed' ORDER BY vote DESC");
        while ($g = $gc->fetch_assoc()) {
            $this->arrayPost[] = array(
                'ID' => $g['id'],
                'CONTESTANT' => $g['contestant'],
                'FIRSTNAME' => $g['firstName'],
                'LASTNAME' => $g['lastName'],
                'EMAIL' => $g['emailAddress'],
                'PHONE' => $g['phoneNumber'],
                'PHONE2' => $g['aphoneNumber'],
                'ADDRESS' => $g['homeAddress'],
                'ADDRESS2' => $g['ahomeAddress'],
                'COUNTRY' => $g['country'],
                'STATE' => $g['state'],
                'CITY' => $g['city'],
                'HEIGHT' => $g['height'],
                'GENDER' => $g['gender'],
                'APPTYPE' => $g['applicationType'],
                'APPSTATUS' => $g['applicationStatus'],
                'DAY' => $g['ageDay'],
                'MONTH' => $g['ageMonth'],
                'YEAR' => $g['ageYear'],
                'REASON' => $g['reason'],
                'SHARES' => $g['share'],
                'VOTES' => $g['vote'],
                'JUDGED' => $g['judged']
            );
        }
        return $this->arrayPost;
    }

    public function systemUsers() {
        $su = $this->connection->query("SELECT * FROM systemusers");
        while ($su = $su->fetch_assoc()) {
            $suu[] = array(
                'USERNAME' => $su['username'],
                'PRIVILEGE' => $su['privilege']
            );
            return $suu;
        }
    }
}
$con = new server();
$c = $con->connection;
$wc = $con->webContent();


if (isset($_REQUEST['judge'])) {
    $ref = $_REQUEST['id'];
    $score = $_REQUEST['score'];
    $judge = $_REQUEST['judger'];
    $type = $_REQUEST['type'];
    if ($type === 'Head Shot') {
        $c->query("UPDATE application SET headshotscore='$score' WHERE reference='$ref'");
        $c->query("UPDATE applicationdocuments SET judged='true',judgedby='$judge' WHERE documentType LIKE '%HEAD SHOT%' AND reference='$ref'");
    }
    if ($type === 'Full Length Shot') {
        $c->query("UPDATE application SET fulllenghtscore='$score' WHERE reference='$ref'");
        $c->query("UPDATE applicationdocuments SET judged='true',judgedby='$judge' WHERE documentType LIKE '%FULL LENGTH PHOTO%' AND reference='$ref'");
    }
    if ($type === 'Swim Wear Shot') {
        $c->query("UPDATE application SET swimwearscore='$score' WHERE reference='$ref'");
        $c->query("UPDATE applicationdocuments SET judged='true',judgedby='$judge' WHERE documentType LIKE '%SWIM WEAR%' AND reference='$ref'");
    }
    if ($type === 'Interview') {
        $c->query("UPDATE application SET interviewscore='$score' WHERE reference='$ref'");
        $c->query("UPDATE videos SET judged='true',judgedby='$judge' WHERE videoName LIKE '%Interview%' AND reference='$ref'");
    }
    if ($type === 'Cat Walk') {
        $c->query("UPDATE application SET catwalkscore='$score' WHERE reference='$ref'");
        $c->query("UPDATE videos SET judged='true',judgedby='$judge' WHERE videoName LIKE '%Cat Walk%' AND reference='$ref'");
    }
}

if (isset($_REQUEST['nominate'])) {
    $ref = $_REQUEST['reference'];
    $nominator = $_REQUEST['nominator'];
    $l = $c->query("SELECT nominatedno FROM application WHERE reference='$ref'")->fetch_assoc();
    $oldno = $l['nominatedno'] + 1;
    $nom = $c->query("SELECT * FROM nominator WHERE username='$nominator' AND reference='$ref'");
    if (mysqli_num_rows($nom) < 1) {
        $c->query("UPDATE application SET nominated='true',nominatedno='$oldno' WHERE reference='$ref'");
        $c->query("INSERT INTO nominator(username,reference) VALUES('$nominator','$ref')");
        echo $oldno;
    }
    else{
       echo $oldno-1; 
    }
}

if (isset($_REQUEST['movetop'])) {
    $ref = $_REQUEST['reference'];
    $c->query("UPDATE application SET top20='true' WHERE reference='$ref'");
}

if (isset($_REQUEST['removetop'])) {
    $ref = $_REQUEST['reference'];
    $c->query("UPDATE application SET top20='false' WHERE reference='$ref'");
}