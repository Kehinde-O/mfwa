<?php
include '../server/index.php';
$action = $_REQUEST['action'];
$height = $_POST['height'];
$scur = $_POST['score'];
$logout = $_REQUEST['logout'];
$pri = $_SESSION['privilege'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if ($_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Blog Manager') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
$year = date("Y");
//$countc = $c->query("SELECT * FROM application WHERE")

$operator = $_SESSION['operator'];$picture = $c->query("SELECT picture FROM systemusers WHERE username='$operator'")->fetch_assoc();
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Kehinde Omotoso Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../css/pace.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header class="header">
            <i class="icon icon-menu menu"></i>
            <form class="search">
                <input type="text" placeholder="Search..." name="search" id="search"/>
                <i class="icon icon-magnifier"></i>
            </form>

            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../message/?logout=true"><li class="icon icon-power"></li></a>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href=""><i class="icon icon-people"></i> <?php
                    if ($action === 'nominate') {
                        echo 'Nominate Contestant';
                    }
                    ?> <?php
                    if ($action === 'nominated') {
                        echo 'Nominated Contestant';
                    }
                    ?> <?php
                    if ($action === 'all') {
                        echo 'All Contestant';
                    }
                    ?><?php
                    if ($action === 'top20') {
                        echo 'Top 20 Contestant';
                    }
                    ?></a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../images/site.png" alt=""/>
            <img class="adminlogo" src="<?php if($picture['picture'] === ''){ echo '../../images/loading.gif';} else{ echo '../../images/judges/'.$picture['picture'];} ?>" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li class="active"><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../contestants/nominate.view"><i class="icon icon-like"></i>  Nominate Contestants</a></li>
                        <li><a href="../contestants/nominated.view"><i class="icon icon-check"></i>  Nominated Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->
        <?php
        
        if ($action === 'all') {
            $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' ORDER BY id DESC");
            if (isset($height) && !empty($height) && $height !=='Height (cm)') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND height='$height' ORDER BY id DESC");
            }
            if (isset($scur) && !empty($score) && $scur !=='Total Score') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' ORDER BY totalscore DESC");
            }
        }
        
        if ($action === 'nominate') {
            $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' ORDER BY id DESC");
            if (isset($height) && !empty($height) && $height !=='Height (cm)') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND height='$height' ORDER BY id DESC");
            }
            if (isset($scur) && !empty($score) && $scur !=='Total Score') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' ORDER BY totalscore DESC");
            }
        }

        if ($action === 'nominated') {
            $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND nominated='true' ORDER BY id DESC");
            if (isset($height) && !empty($height) && $height !=='Height (cm)') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND nominated='true' AND height='$height' ORDER BY id DESC");
            }
            if (isset($scur) && !empty($score) && $scur !=='Total Score') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND nominated='true' ORDER BY totalscore DESC");
            }
        }

        if ($action === 'top20') {
            $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND top20='true' ORDER BY id DESC");
            if (isset($height) && !empty($height) && $height !=='Height (cm)') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND top20='true' AND height='$height' ORDER BY id DESC");
            }
            if (isset($scur) && !empty($score) && $scur !=='Total Score') {
                $gc = $c->query("SELECT * FROM application WHERE applicationStatus='completed' AND lastStepJudged='3' AND judged='completed' AND top20='true' ORDER BY totalscore DESC");
            }
        }
        ?>
        <?php
        while ($g = $gc->fetch_assoc()) {
            $co[] = array(
                'ID' => $g['id'],
                'REFERENCE' => $g['reference'],
                'FIRSTNAME' => $g['firstName'],
                'LASTNAME' => $g['lastName'],
                'EMAIL' => $g['emailAddress'],
                'PHONE' => $g['phoneNumber'],
                'PHONE2' => $g['aphoneNumber'],
                'ADDRESS' => $g['homeAddress'],
                'ADDRESS2' => $g['ahomeAddress'],
                'COUNTRY' => $g['country'],
                'STATE' => $g['state'],
                'CITY' => $g['city'],
                'HEIGHT' => $g['height'],
                'GENDER' => $g['gender'],
                'APPTYPE' => $g['applicationType'],
                'APPSTATUS' => $g['applicationStatus'],
                'DAY' => $g['ageDay'],
                'MONTH' => $g['ageMonth'],
                'YEAR' => $g['ageYear'],
                'REASON' => $g['reason'],
                'SHARES' => $g['share'],
                'VOTES' => $g['vote'],
                'JUDGED' => $g['judged'],
                'NONO'=>$g['nominatedno']
            );
        }
        ?>
        <!-- MAIN CONTENT STARTS HERE -->
        <section class="mainContent col-sm-11 col-xs-11 pull-right">
            <div class="col-sm-12 pull-left result-no"><?php echo count($co); ?> Results found</div>
            <br/>
            <?php if (mysqli_num_rows($gc) > 0) { ?>
                <div class="col-sm-12 filter ">
                    <div class="col-sm-3 fb">Filter Contestants By:</div>
                    <div class="col-sm-9">
                        <form action="" method="post">
                            <select data-holder="height" class="filt" name="height">
                                <option>Height (cm)</option>
                                <?php
                                    $hei = $c->query("SELECT DISTINCT height FROM application");
                                    while($he = $hei->fetch_assoc()){
                                        echo '<option '.str_replace($height,'selected',$he['height']).'>'.$he['height'].'</option>';
                                    }
                                ?>
                            </select>
                            <select data-holder="score" class="filt" name="score">
                                <option>Total Score</option>
                                <?php
                                    $hei = $c->query("SELECT DISTINCT totalscore FROM application WHERE totalscore !='0'");
                                    while($he = $hei->fetch_assoc()){
                                        echo '<option '.str_replace($scur,'selected',$he['totalscore']).'>'.$he['totalscore'].'</option>';
                                    }
                                ?>
                            </select>
                        </form>
                    </div>
                </div>
            <?php } ?>

            <div class="clearfix divider"></div>
            <?php
            for ($i = 0; $i < count($co); $i++) {
                $age = date("Y") - $co[$i]['YEAR'];
                $cot = $co[$i]['REFERENCE'];
                $judged = str_replace('completed', 'icon-check', $co[$i]['JUDGED']);
                $newjudged = str_replace('uncompleted', 'icon-hourglass', $co[$i]['JUDGED']);
                $pic = $c->query("SELECT documentReference FROM applicationdocuments WHERE reference='$cot' AND documentType='HEAD SHOT FRONT VIEW'")->fetch_assoc();
                ?>
                <div class="col-sm-4 contestant <?php
                if ($action === 'nominate' || $action === 'nominated' || $action === 'top20') {
                    echo 'contnom';
                }
                ?>">
                    <a href="applications/<?php echo $co[$i]['REFERENCE'] ?>.details">
                        <div class="contester">
                            <div class="status">
                                <i class="icon <?php echo $judged . ' ' . $newjudged ?>" title="<?php echo $co[$i]['JUDGED'] ?>"></i>
                            </div>
                            <img src="../../images/models/<?php echo $pic['documentReference'] ?>" alt="" />
                            <div class="nameMail">
                                <h3><?php echo $co[$i]['FIRSTNAME'] . ' ' . $co[$i]['LASTNAME'] ?></h3> 
                                <h6><?php echo $co[$i]['EMAIL'] ?></h6>
                            </div>
                            <div class="ageDetails">
                                <div class="col-sm-4 col-xs-4">AGE 
                                    <span>
                                        <?php echo $age ?>
                                    </span>
                                </div>
                                <div class="col-sm-4 col-xs-4">HEIGHT 
                                    <span>
                                        <?php echo $co[$i]['HEIGHT'] ?>cm
                                    </span>
                                </div>
                                <div class="col-sm-4 col-xs-4">VOTES
                                    <span>
                                        <?php echo $co[$i]['VOTES'] ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </a>
                    <?php if ($action === 'nominate' || $action === 'nominated' || $action === 'top20') { ?>
                        <div class="nomi">
                            <?php if ($action === 'nominate') { ?>
                                <button type="button" class="nominatebtn btn btn-danger col-sm-4 col-xs-10 center-block" id="<?php echo $co[$i]['ID'] ?>" data-ref="<?php echo $co[$i]['REFERENCE'] ?>" data-action="nominate" <?php
                                if ($pri === 'Admin') {
                                    echo 'disabled';
                                }
                                ?>>Nominate (<?php echo $co[$i]['NONO'] ?>)</button>
                                    <?php } ?>
                                    <?php if ($action === 'nominated') { ?>
                                <button type="button" class="nominatebtn btn btn-danger col-sm-8 col-xs-12 center-block" data-ref="<?php echo $co[$i]['REFERENCE'] ?>" data-action="move"  id="<?php echo $co[$i]['ID'] ?>" <?php
                                if ($pri !== 'Admin') {
                                    echo 'disabled';
                                }
                                ?>>Nominators (<?php echo $co[$i]['NONO'] ?>), Move To Top 20</button>
                                    <?php } ?>
                                    <?php if ($action === 'top20') { ?>
                                <button type="button" class="nominatebtn btn btn-danger col-sm-9 col-xs-12 center-block" data-ref="<?php echo $co[$i]['REFERENCE'] ?>" data-action="remove" id="<?php echo $co[$i]['ID'] ?>" <?php
                                if ($pri !== 'Admin') {
                                    echo 'disabled';
                                }
                                ?>>Nominators (<?php echo $co[$i]['NONO'] ?>), Remove From Top 20</button>
                                    <?php } ?>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>


            <?php if ($action === 'nominated' && mysqli_num_rows($gc) < 1) { ?>

                <div class="col-sm-6 center-block lead" style="padding:30px 0px;text-align:center;"><h1>No Contestant Have Been Nominated To Qualify For The Top 20 Contestants.</h1></div>


            <?php } ?>


            <?php if ($action === 'nominate' && mysqli_num_rows($gc) < 1) { ?>

                <div class="col-sm-6 center-block lead" style="padding:30px 0px;text-align:center;"><h1>There Are No Completely Judged Applications Available For Nomination.</h1></div>

            <?php } ?>

            <?php if ($action === 'all' && mysqli_num_rows($gc) < 1) { ?>

                <div class="col-sm-6 center-block lead" style="padding:30px 0px;text-align:center;"><h1>There Are No Completed Applications Available.</h1></div>

            <?php } ?>

            <?php if ($action === 'top20' && mysqli_num_rows($gc) < 1) { ?>

                <div class="col-sm-6 center-block lead" style="padding:30px 0px;text-align:center;"><h1>There Are No Contestants Selected As Top 20 Contestants.</h1></div>

            <?php } ?>
            <div class="clearfix divider"></div>
            <div class="clearfix divider"></div>
            <!--<div class="col-sm-12 cpagination">
                Page 1 of 200
                <button class="prevPage pull-left"><i class="icon icon-arrow-left"></i> <i class="icon icon-arrow-left"></i> Prev</button>
                <button class="nextPage pull-right">Next <i class="icon icon-arrow-right"></i> <i class="icon icon-arrow-right"></i> </button>
            </div> -->

        </section>

        <!-- MAIN CONTENT ENDS HERE -->



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/bootstrap.js" type="text/javascript"></script>
        <script src="../js/pace.js" type="text/javascript"></script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">
            $('.nominatebtn').click(function() {
                var ref = $(this).attr('data-ref');
                var nominator = "<?php echo $_SESSION['operator'] ?>";
                var action = $(this).attr('data-action');
                if (action === 'nominate') {
                    var xhttp;
                    if (window.XMLHttpRequest) {
                        xhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            $('.nominatebtn').text('Nominate (' + xhttp.responseText + ')');
                        }
                    };
                    xhttp.open("GET", '../server/?nominate&reference=' + ref + '&nominator=' + nominator, true);
                    xhttp.send(null);
                }
                if (action === 'move') {
                    var xhttp;
                    if (window.XMLHttpRequest) {
                        xhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            alert('Contestant: ' + ref + ' has been moved to top 20 list.');
                            window.location.href="../contestants/<?php echo $action ?>.view";
                        }
                    };
                    xhttp.open("GET", '../server/?movetop&reference=' + ref, true);
                    xhttp.send(null);
                }
                if (action === 'remove') {
                    var xhttp;
                    if (window.XMLHttpRequest) {
                        xhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            alert('Contestant: ' + ref + ' has been removed from top 20 list.');
                            window.location.href="../contestants/<?php echo $action ?>.view";
                        }
                    };
                    xhttp.open("GET", '../server/?removetop&reference=' + ref, true);
                    xhttp.send(null);
                }
            });
            $('.filt').change(function(){
                $(this).parent().submit();
            });
        </script>
    </body>
</html>
