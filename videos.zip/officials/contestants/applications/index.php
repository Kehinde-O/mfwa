<?php
include '../../server/index.php';
$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../../login/');
}
if ($_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Blog Manager') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:../../login/');
}
$oper = $_SESSION['operator'];
$contestant = $_REQUEST['contestant'];
if (!isset($contestant)) {
    $gcc = $c->query("SELECT * FROM application WHERE lastStepJudged='0' AND applicationStatus='completed' LIMIT 1");
    $contest = $gcc->fetch_assoc();
    $contestant = $contest['reference'];
    $gc = $c->query("SELECT * FROM application WHERE reference='$contestant' AND applicationStatus='completed'");
    if (mysqli_num_rows($gc) < 1) {
        $gcc = $c->query("SELECT * FROM application WHERE lastStepJudged='1' AND applicationStatus='completed' LIMIT 1");
        $contest = $gcc->fetch_assoc();
        $contestant = $contest['reference'];
        $gc = $c->query("SELECT * FROM application WHERE reference='$contestant' AND applicationStatus='completed'");
    }
    if (mysqli_num_rows($gc) < 1) {
        $gcc = $c->query("SELECT * FROM application WHERE lastStepJudged='2' AND applicationStatus='completed' LIMIT 1");
        $contest = $gcc->fetch_assoc();
        $contestant = $contest['reference'];
        $gc = $c->query("SELECT * FROM application WHERE reference='$contestant' AND applicationStatus='completed'");
    }
} else {
    $gc = $c->query("SELECT * FROM application WHERE reference='$contestant' AND applicationStatus='completed'");
}


$pic = $c->query("SELECT documentReference FROM applicationdocuments WHERE reference='$contestant' AND documentType='HEAD SHOT FRONT FACE'")->fetch_assoc();
while ($g = $gc->fetch_assoc()) {
    $co[] = array(
        'ID' => $g['id'],
        'REFERENCE' => $g['reference'],
        'FIRSTNAME' => $g['firstName'],
        'LASTNAME' => $g['lastName'],
        'EMAIL' => $g['emailAddress'],
        'PHONE' => $g['phoneNumber'],
        'PHONE2' => $g['aphoneNumber'],
        'ADDRESS' => $g['homeAddress'],
        'ADDRESS2' => $g['ahomeAddress'],
        'COUNTRY' => $g['country'],
        'STATE' => $g['state'],
        'CITY' => $g['city'],
        'HEIGHT' => $g['height'],
        'GENDER' => $g['gender'],
        'APPTYPE' => $g['applicationType'],
        'APPSTATUS' => $g['applicationStatus'],
        'DAY' => $g['ageDay'],
        'MONTH' => $g['ageMonth'],
        'YEAR' => $g['ageYear'],
        'REASON' => $g['reason'],
        'SHARES' => $g['share'],
        'VOTES' => $g['vote'],
        'JUDGED' => $g['judged'],
        'HEADSHOT' => $g['headshotscore'],
        'FULLLENGTH' => $g['fulllenghtscore'],
        'SWIMWEAR' => $g['swimwearscore'],
        'CATWALK' => $g['catwalkscore'],
        'INTERVIEW' => $g['interviewscore'],
        'LASTSTEP' => $g['lastStepJudged'],
        'BUST' => $g['Bust'],
        'WAIST' => $g['Waist'],
        'SHOE' => $g['Shoe'],
        'HIPS' => $g['Hips']
    );
}
$contestant = $co[0]['REFERENCE'];
$email = $co[0]['EMAIL'];
$ts = $co[0]['CATWALK'] + $co[0]['FULLLENGTH'] + $co[0]['SWIMWEAR'] + $co[0]['HEADSHOT'] + $co[0]['INTERVIEW'];
$c->query("UPDATE application SET totalscore='$ts' WHERE reference='$contestant'");
$pictures = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant'");
while ($cd = $pictures->fetch_assoc()) {
    $result[] = array(
        'DOCREF' => $cd['documentReference'],
        'DOCTYPE' => $cd['documentType']
    );
}
$user = $c->query("SELECT * FROM application WHERE reference='$contestant'")->fetch_assoc();
//$docsV = $c->query("SELECT * FROM applicationdocuments WHERE contestant='$contestant' AND documentType='video'")->fetch_assoc();
//http://localhost/mfwa/contestant/applicationFiles/contestData/4/European%20Model%20Showcase%20Video%202016.mp4
$videourl = '';
$allc = $c->query("SELECT * FROM application");
$judges = $c->query("SELECT * FROM systemusers WHERE privilege='Judge'");
while ($jdd = $judges->fetch_assoc()) {
    $jc[] = array(
        'USERNAME' => $jdd['username'],
        'ID' => $jdd['id']
    );
}
$allp = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%HEAD SHOT%' AND judged='true'");
$allp1 = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%FULL LENGTH%' AND judged='true'");
$allv = $c->query("SELECT * FROM videos WHERE reference='$contestant' AND videoName LIKE '%Cat Walk%' AND judged='true'");
$nstp = mysqli_num_rows($allp) + mysqli_num_rows($allv) + mysqli_num_rows($allp1);
if ($nstp == '5') {
    if ($co[0]['LASTSTEP'] == '0') {
        $c->query("UPDATE application SET lastStepJudged='1' WHERE reference='$contestant'");
        $c->query("UPDATE quickform SET appprocess='false' WHERE reference='$contestant'");
        $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $co[0]['FIRSTNAME'] . ' ' . $co[0]['LASTNAME'] . ',<br/><br/>Here are your stage 1 judge scores: <br/><br/><b>Cat Walk: ' . $co[0]['CATWALK'] . ' /10<br/><br/>Head Shot: ' . $co[0]['HEADSHOT'] . ' /10<br/><br/> Full Length Shot: ' . $co[0]['FULLLENGTH'] . ' /10<br/><br/>Now login to your profile at http://missfashionweekafrica.com/profile/ to complete stage 2 of your application.<br/><br/>Please always check your email for further instructions.<br/><br/>Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
        $headers = "From: support@missfashionweekafrica.com \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($email, 'Stage 1 Judges Score - MissFashionWeekAfrica', $mailmsg, $headers);
        //header('location:../applications/');
    }
}

$allp2 = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType='SWIM WEAR PHOTO' AND judged='true'");
$nstp2 = mysqli_num_rows($allp2);
if ($nstp2 == '1') {
    if ($co[0]['LASTSTEP'] == '1') {
        $c->query("UPDATE application SET lastStepJudged='2' WHERE reference='$contestant'");
        $c->query("UPDATE quickform SET appprocess='false' WHERE reference='$contestant'");
        $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $co[0]['FIRSTNAME'] . ' ' . $co[0]['LASTNAME'] . ',<br/><br/>Here are your stage 2 judge scores: <br/><br/><b>Cat Walk: ' . $co[0]['CATWALK'] . ' /10<br/><br/>Head Shot: ' . $co[0]['HEADSHOT'] . ' /10<br/><br/> Full Length Shot: ' . $co[0]['FULLLENGTH'] . ' /10<br/><br/> Swim Wear Shot: ' . $co[0]['SWIMWEAR'] . ' /10<br/><br/>Now login to your profile at http://missfashionweekafrica.com/profile/ to complete stage 2 of your application.<br/><br/>Please always check your email for further instructions.<br/><br/>Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
        $headers = "From: support@missfashionweekafrica.com \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($email, 'Stage 2 Judges Score - MissFashionWeekAfrica', $mailmsg, $headers);
        //header('location:../applications/');
    }
}


$in = $c->query("SELECT * FROM videos WHERE reference='$contestant' AND videoName LIKE '%Interview%' AND judged='true'");
$nstp1 = mysqli_num_rows($in);
if ($nstp1 == '1') {
    if ($co[0]['LASTSTEP'] == '2') {
        $c->query("UPDATE application SET lastStepJudged='3',judged='completed' WHERE reference='$contestant'");
        $c->query("UPDATE quickform SET appprocess='false' WHERE reference='$contestant'");
        $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $co[0]['FIRSTNAME'] . ' ' . $co[0]['LASTNAME'] . ',<br/><br/>Here are your stage 3 judge scores: <br/><br/><b>Cat Walk: ' . $co[0]['CATWALK'] . ' /10<br/><br/>Head Shot: ' . $co[0]['HEADSHOT'] . ' /10<br/><br/> Full Length Shot: ' . $co[0]['FULLLENGTH'] . ' /10<br/><br/> Swim Wear Shot: ' . $co[0]['SWIMWEAR'] . ' /10<br/><br/> Interview Video: ' . $co[0]['INTERVIEW'] . ' /10<br/><br/>Now login to your profile at http://missfashionweekafrica.com/profile/ to complete stage 2 of your application.<br/><br/>Please always check your email for further instructions.<br/><br/>Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
        $headers = "From: support@missfashionweekafrica.com \r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
        mail($email, 'Stage 3 Judges Score - MissFashionWeekAfrica', $mailmsg, $headers);
        //header('location:../applications/');
    }
}


$allp = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%HEAD SHOT%'");
$intp = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%SCANNED COPY OF INTERNATIONAL PASSPORT%'");
$allp1 = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%FULL LENGTH%'");
$allv = $c->query("SELECT * FROM videos WHERE reference='$contestant' AND videoName LIKE '%Cat Walk%'");
$stg1 = mysqli_num_rows($allp) + mysqli_num_rows($allp1) + mysqli_num_rows($allv);
$allp2 = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType='SWIM WEAR PHOTO'");
$stg2 = mysqli_num_rows($allp2);
$in = $c->query("SELECT * FROM videos WHERE reference='$contestant' AND videoName LIKE '%Interview%'");
$stg3 = mysqli_num_rows($in);

$operator = $_SESSION['operator'];
$picture = $c->query("SELECT picture FROM systemusers WHERE username='$operator'")->fetch_assoc();
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Kehinde Omotoso Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/pace.css" rel="stylesheet" type="text/css"/>
        <link href="engine1/style.css" rel="stylesheet" type="text/css"/>
        <link href="../../../css/lightgallery.css" rel="stylesheet" type="text/css"/>
        <style>
            .grading.<?php echo $oper ?>{
                display:block;
            }
        </style>
    </head>
    <body>
        <header class="header">
            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../../message/?logout=true"><li class="icon icon-power"></li></a>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator']; ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege']; ?> / <a href="">Contestant: <?php echo $contestant; ?> </a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../../images/site.png" alt=""/>
            <img class="adminlogo" src="<?php if ($picture['picture'] === '') {
    echo '../../../images/loading.gif';
} else {
    echo '../../../images/judges/' . $picture['picture'];
} ?>" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li class="active"><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../../contestants/nominate.view"><i class="icon icon-like"></i>  Nominate Contestants</a></li>
                        <li><a href="../contestants/nominated.view"><i class="icon icon-check"></i> Nominated Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <!-- MAIN CONTENT STARTS HERE -->

        <?php if (mysqli_num_rows($gc) > 0) { ?>
                <?php
                $vii = $c->query("SELECT * FROM videos WHERE reference='$contestant'");
                while ($v = $vii->fetch_assoc()) {
                    $vid[] = array('VIDEO' => $v['videoReference'], 'NAME' => $v['videoName'], 'SCORE' => $v['score'], 'JUDGED' => $v['judged']);
                }
                ?>
            <div class="col-sm-11 col-xs-12 pull-right" style="padding:10px 25px;">
                <?php if ($stg1 > 0 && $nstp < 5) { ?>
                    <div class="showing" style="background:#d35400 !important;color:#fff !important;">
                        <div class="col-sm-12 col-xs-12 shw text-center" style="background:#d35400 !important;color:#fff !important;">Stage 1 Judging for <b>Full Length shot, Head shot and Catwalk</b> has not been completed</div>
                    </div>
                <?php } ?>

                <?php if ($stg2 > 0 && $nstp2 < 1) { ?>
                    <div class="showing" style="background:#d35400 !important;color:#fff !important;">
                        <div class="col-sm-12 col-xs-12 shw text-center" style="background:#d35400 !important;color:#fff !important;">Stage 2 Judging for <b>Swim Wear Shot</b> has not been completed</div>
                    </div>
                <?php } ?>

                <?php if ($stg3 > 0 && $nstp1 < 1) { ?>
                    <div class="showing" style="background:#d35400 !important;color:#fff !important;">
                        <div class="col-sm-12 col-xs-12 shw text-center" style="background:#d35400 !important;color:#fff !important;">Stage 3 Judging for <b>Interview Video</b> has not been completed</div>
                    </div>
                <?php } ?>

    <?php if (mysqli_num_rows($intp) < 1) { ?>
                    <div class="showing" style="background:#d35400 !important;color:#fff !important;">
                        <div class="col-sm-12 col-xs-12 shw text-center" style="background:#d35400 !important;color:#fff !important;"><b>Scanned Copy of International Passport</b> has not been uploaded yet.</div>
                    </div>
                            <?php } ?>
                <br/><br/>
                <div class="showing">
                    <div class="col-sm-2 col-xs-6 shw">Select Video to Play:</div>
                    <div class="col-sm-3 col-xs-6">
                        <select id="showing">
    <?php for ($i = 0; $i < count($vid); $i++) { ?>
                                <option id="video<?php echo $i ?>" data-src="../../../embed/player.php?v=../videos/<?php echo $vid[$i]['VIDEO'] ?>"><?php echo $vid[$i]['NAME'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="col-sm-7 videojudgement vj" data-type="video" alt="Cat Walk" id="video0i">
                        <div>
                            <div class="col-sm-3 jb">Judge Cat Walk:</div>
                            <div class="col-sm-9 judgedbar <?php
                            if ($vid[0]['JUDGED'] === 'false') {
                                if ($_SESSION['privilege'] === 'Admin') {
                                    echo 'naaa';
                                } else {
                                    echo 'active';
                                }
                            } else {
                                echo 'naa';
                            }
                            ?>">
                                <div class="pgress" style="width:<?php echo $co[0]['CATWALK'] * 10 ?>% !important;"></div>
                                <span title="Score: 1">1</span>
                                <span title="Score: 2">2</span>
                                <span title="Score: 3">3</span>
                                <span title="Score: 4">4</span>
                                <span title="Score: 5">5</span>
                                <span title="Score: 6">6</span>
                                <span title="Score: 7">7</span>
                                <span title="Score: 8">8</span>
                                <span title="Score: 9">9</span>
                                <span title="Score: 10">10</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7 videojudgement vj" data-type="video" alt="Interview" id="video1i" style="display:none;">
                        <div>
                            <div class="col-sm-3 jb">Judge Interview:</div>
                            <div class="col-sm-9 judgedbar <?php
                            if ($vid[1]['JUDGED'] === 'false') {
                                if ($_SESSION['privilege'] === 'Admin') {
                                    echo 'naaa';
                                } else {
                                    echo 'active';
                                }
                            } else {
                                echo 'naa';
                            }
                            ?>">
                                <div class="pgress" style="width:<?php echo $co[0]['INTERVIEW'] * 10 ?>% !important;"></div>
                                <span title="Score: 1">1</span>
                                <span title="Score: 2">2</span>
                                <span title="Score: 3">3</span>
                                <span title="Score: 4">4</span>
                                <span title="Score: 5">5</span>
                                <span title="Score: 6">6</span>
                                <span title="Score: 7">7</span>
                                <span title="Score: 8">8</span>
                                <span title="Score: 9">9</span>
                                <span title="Score: 10">10</span>
                            </div>
                        </div>
                    </div>
                </div>
                <iframe width="100%" height="500px" src="../../../embed/player.php?v=../videos/<?php echo $vid[0]['VIDEO'] ?>" frameborder="0" id="movie" allowfullscreen></iframe>
            </div>
            <!--<div id="wowslider-container1" class="col-sm-11 col-xs-12 pull-right">
                <div class="ws_images">
                    <ul>
            <?php
            $vii = $c->query("SELECT * FROM videos WHERE reference='$contestant'");
            while ($v = $vii->fetch_assoc()) {
                $vid[] = array('VIDEO' => $v['videoReference'], 'NAME' => $v['videoName'], 'SCORE' => $v['score'], 'JUDGED' => $v['judged']);
            }
            ?>
    <?php for ($i = 0; $i < count($vid); $i++) { ?>
                                                <li><iframe width="100%" height="100%" src="../../../embed/player.php?v=../videos/<?php echo $vid[$i]['VIDEO'] ?>" frameborder="0" id="ws_vimeo_114205651.png" allowfullscreen></iframe><img src="../../../images/playvideo.png" alt="<?php echo $vid[$i]['NAME']; ?>" title="<?php echo $vid[$i]['NAME']; ?>" id="wows1_5"/><?php echo $vid[$i]['NAME']; ?></li>
    <?php } ?>
                    </ul>
                </div>
                <div class="ws_bullets">
                    <div>
    <?php
    for ($i = 0; $i < count($vid); $i++) {
        echo '<a href="#wows0_' . $i . '" title="' . $result[$i]['DOCTYPE'] . '"><span><img src="../../../images/models/thumb_' . $result[$i]['DOCREF'] . '" alt="' . $result[$i]['DOCTYPE'] . '"/>1</span></a>';
    }
    ?>
                    </div>
                </div>
            </div> -->
            <div class="clearfix"></div>
            <div class="col-sm-1 col-xs-1"></div>
            <section class="mainContent col-sm-11 col-xs-11">
                <div class="col-sm-6 personalInfo">
                    <div class="infoHolder">
                        <div class="title">PERSONAL INFORMATION</div>
                        <div class="table">
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Application Reference</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['REFERENCE'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">First Name</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['FIRSTNAME'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Last Name</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['LASTNAME'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Age</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo date("Y") - $co[0]['YEAR'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Height</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['HEIGHT'] ?> cm</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Email</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['EMAIL'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Country</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['COUNTRY'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">State</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['STATE'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">City</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['CITY'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Phone Number 1</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['PHONE'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Phone Number 2</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['PHONE2'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Address 1</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['ADDRESS'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Address2</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['ADDRESS2'] ?></div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Votes</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['VOTES'] ?> Votes</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Waist</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['WAIST'] ?>cm</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Bust</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['BUST'] ?>cm</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Hips</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['HIPS'] ?>cm</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Shoe</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['SHOE'] ?> USA</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Head Shot Score</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['HEADSHOT'] ?> /10</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Cat Walk Score</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['CATWALK'] ?> /10</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Full Length Score</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['FULLLENGTH'] ?> /10</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Swim Wear Score</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['SWIMWEAR'] ?> /10</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Interview Video Score</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['INTERVIEW'] ?> /10</div>
                            </div>
                            <div class="tableTr">
                                <div class="tableTd col-sm-6 col-xs-6">Reason for participating</div>
                                <div class="tableTd col-sm-6 col-xs-6"><?php echo $co[0]['REASON'] ?></div>
                            </div>
                        </div>

                    </div>
                </div>


                <div class="col-sm-6 pictures">
                    <div class="pictureHolder">
                        <div class="title">CONTESTANT GRADING <small style="font-weight:bold;margin-left:10px;color:#c0392b;">Please click on image name bellow to view images in large scale</small></div>
                        <div class="clearfix"></div>
                        <div class="gradingChoose col-sm-12 col-xs-12" style="background:#7f8c8d;" alt="Head Shot" data-type="doc">
                            <div class="gc">
    <?php
    $pictures1 = $c->query("SELECT * FROM applicationdocuments WHERE documentType LIKE '%HEAD SHOT%' AND reference='$contestant'");
    $picturesc1 = $c->query("SELECT * FROM applicationdocuments  WHERE documentType LIKE '%HEAD SHOT%' AND reference='$contestant' AND judged='true'");
    while ($cd1 = $pictures1->fetch_assoc()) {
        ?>
                                    <a href="../../../images/models/<?php echo $cd1['documentReference'] ?>" alt="<?php echo $cd1['documentType'] ?>" id="<?php echo $cd1['id'] ?>" data-type="doc"><?php echo $cd1['documentType'] ?> <?php
                                    if ($cd1['judged'] === 'false') {
                                        echo '<small class="nt">Not Yet Rated</small>';
                                    } else {
                                        echo '<small class=""><i class="icon icon-check"></i> ' . $cd1['score'] . '</small> ';
                                    }
                                    ?> </a>
    <?php } ?>
                            </div>
                            <div class="col-sm-12 videojudgement" style="padding:10px 0px;" alt="" data-type="doc">
                                <div class="col-sm-3 jb"style="">Head Shot Judging Bar:</div>
                                <div class="col-sm-9 judgedbar <?php
    if (mysqli_num_rows($picturesc1) < 2) {
        if ($_SESSION['privilege'] === 'Admin') {
            echo 'naaa';
        } else {
            echo 'active';
        }
    } else {
        echo 'naa';
    }
    ?>">
                                    <div class="pgress" style="width:<?php echo $co[0]['HEADSHOT'] * 10 ?>% !important;"></div>
                                    <span title="Score: 1">1</span>
                                    <span title="Score: 2">2</span>
                                    <span title="Score: 3">3</span>
                                    <span title="Score: 4">4</span>
                                    <span title="Score: 5">5</span>
                                    <span title="Score: 6">6</span>
                                    <span title="Score: 7">7</span>
                                    <span title="Score: 8">8</span>
                                    <span title="Score: 9">9</span>
                                    <span title="Score: 10">10</span>
                                </div>
                            </div>
                        </div>


                        <!--- //Head Shot ---------------------->

                        <div class="gradingChoose col-sm-12 col-xs-12" alt="Full Length Shot" data-type="doc">
                            <div class="gc">
                                <?php
                                $pictures = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE '%FULL LENGTH PHOTO%'");
                                $picturesc = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant'  AND documentType LIKE '%FULL LENGTH PHOTO%' AND judged='true'");
                                while ($cd = $pictures->fetch_assoc()) {
                                    ?>
                                    <a href="../../../images/models/<?php echo $cd['documentReference'] ?>" alt="<?php echo $cd['documentType'] ?>" id="<?php echo $cd['id'] ?>" data-type="doc"><?php echo $cd['documentType'] ?> <?php
                                         if ($cd['judged'] === 'false') {
                                             echo '<small class="nt">Not Yet Rated</small>';
                                         } else {
                                             echo '<small class=""><i class="icon icon-check"></i> ' . $cd['score'] . '</small> ';
                                         }
                                         ?> </a>
    <?php } ?>
                            </div>
                            <div class="col-sm-12 videojudgement" style="padding:10px 0px;">
                                <div class="col-sm-3 jb"style="">Full Length Judging Bar:</div>
                                <div class="col-sm-9 judgedbar <?php
    if (mysqli_num_rows($picturesc) < 2) {
        if ($_SESSION['privilege'] === 'Admin') {
            echo 'naaa';
        } else {
            echo 'active';
        }
    } else {
        echo 'naa';
    }
    ?>">
                                    <div class="pgress" style="width:<?php echo $co[0]['FULLLENGTH'] * 10 ?>% !important;"></div>
                                    <span title="Score: 1">1</span>
                                    <span title="Score: 2">2</span>
                                    <span title="Score: 3">3</span>
                                    <span title="Score: 4">4</span>
                                    <span title="Score: 5">5</span>
                                    <span title="Score: 6">6</span>
                                    <span title="Score: 7">7</span>
                                    <span title="Score: 8">8</span>
                                    <span title="Score: 9">9</span>
                                    <span title="Score: 10">10</span>
                                </div>
                            </div>
                        </div>

                        <!--- //Swim Wear ------------------------>
                                <?php $wf = $c->query("SELECT thirdmedia FROM quickform WHERE reference='$contestant'")->fetch_assoc();
                                if ($wf['thirdmedia'] === 'true') { ?>
                            <div class="gradingChoose col-sm-12 col-xs-12" style="background:#7f8c8d;" alt="Swim Wear Shot" data-type="doc">
                                <div class="gc">
                                         <?php
                                         $pictureso = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType LIKE 'SWIM WEAR PHOTO'");
                                         $picturesc = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType='SWIM WEAR PHOTO' AND judged='true'");
                                         while ($cd = $pictureso->fetch_assoc()) {
                                             ?>
                                        <a href="../../../images/models/<?php echo $cd['documentReference'] ?>" alt="<?php echo $cd['documentType'] ?>" id="<?php echo $cd['id'] ?>" data-type="doc"><?php echo $cd['documentType'] ?> <?php
                                             if ($cd['judged'] === 'false') {
                                                 echo '<small class="nt">Not Yet Rated</small>';
                                             } else {
                                                 echo '<small class=""><i class="icon icon-check"></i> ' . $cd['score'] . '</small> ';
                                             }
                                             ?> </a>
        <?php } ?>
                                </div>
                                <div class="col-sm-12 videojudgement" style="padding:10px 0px;">
                                    <div class="col-sm-3 jb"style="">Swim Wear Judging Bar:</div>
                                    <div class="col-sm-9 judgedbar <?php
        if (mysqli_num_rows($picturesc) < 1) {
            if ($_SESSION['privilege'] === 'Admin') {
                echo 'naaa';
            } else {
                echo 'active';
            }
        } else {
            echo 'naa';
        } echo $cd['judged']
        ?>">
                                        <div class="pgress" style="width:<?php echo $co[0]['SWIMWEAR'] * 10 ?>% !important;"></div>
                                        <span title="Score: 1">1</span>
                                        <span title="Score: 2">2</span>
                                        <span title="Score: 3">3</span>
                                        <span title="Score: 4">4</span>
                                        <span title="Score: 5">5</span>
                                        <span title="Score: 6">6</span>
                                        <span title="Score: 7">7</span>
                                        <span title="Score: 8">8</span>
                                        <span title="Score: 9">9</span>
                                        <span title="Score: 10">10</span>
                                    </div>
                                </div>
                            </div>


                            <!---- INTERNATIONAL PASSPORT ---------------->
        <?php
        $pictures = $c->query("SELECT * FROM applicationdocuments WHERE reference='$contestant' AND documentType='SCANNED COPY OF INTERNATIONAL PASSPORT'");
        while ($cd = $pictures->fetch_assoc()) {
            ?>
                            <?php if(!strpos($cd['documentReference'],'.pdf')){ ?>
                            
                                <div class="gradingChoose col-sm-12 col-xs-12" style="background:#7f8c8d;">
                                    <div class="gc">

                                        <a href="../../../images/models/<?php echo $cd['documentReference'] ?>" alt="<?php echo $cd['documentType'] ?>" id="<?php echo $cd['id'] ?>" data-type="doc" target="_blank"><?php echo $cd['documentType'] ?></a>

                                    </div>
                                </div>
                            <?php } else {?>
                            
                                <div class="gradingChoose col-sm-12 col-xs-12 noopen" style="background:#7f8c8d;">
                                        <a href="../../../images/models/<?php echo $cd['documentReference'] ?>" alt="<?php echo $cd['documentType'] ?>" id="<?php echo $cd['id'] ?>" data-type="doc" target="_blank"><?php echo $cd['documentType'] ?></a>

                                </div>
                            <?php } ?>
        <?php } ?>
    <?php } ?>



                    </div>
                </div>

                <div class="clearfix divider"></div>
                <div class="clearfix divider"></div>
                <div class="col-sm-12 cpagination">
                    Contestant <?php echo $contestant ?>
                   <!-- <button class="prevPage pull-left"><i class="icon icon-arrow-left"></i> <i class="icon icon-arrow-left"></i> Prev</button>
                    <button class="nextPage pull-right">Next <i class="icon icon-arrow-right"></i> <i class="icon icon-arrow-right"></i> </button> 
                    -->
                </div>

<?php } ?>

<?php if (mysqli_num_rows($gc) < 1) { ?>

                <div class="col-sm-6 center-block lead" style="padding:30px 0px;text-align:center;"><h1>There are no Applications Pending for judgement now, Please check back later.</h1></div>


<?php } ?>
        </section>
        <div class="clearfix"></div>
        <!-- MAIN CONTENT ENDS HERE -->
        <div class="col-sm-1 col-xs-1"></div>
        <section class="col-sm-11 col-xs-11">

        </section>



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../../js/jquery.js" type="text/javascript"></script>
        <script src="../../js/bootstrap.js" type="text/javascript"></script>
        <script src="../../js/pace.js" type="text/javascript"></script>
        <script src="engine1/wowslider.js" type="text/javascript"></script>
        <script src="engine1/script.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lightgallery.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-fullscreen.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-thumbnail.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-zoom.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-hash.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-autoplay.js" type="text/javascript"></script>
        <script src="../../../js/gallery/lg-pager.js" type="text/javascript"></script>
        <script src="../../../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">
            $('#showing').change(function() {
                var sel = $(this).find('option:selected').attr('data-src');
                var vid = $(this).find('option:selected').attr('id');
                $('.vj').css('display', 'none');
                $('#' + vid + 'i').css('display', 'block');
                var fr = $('#movie');
                if (fr.length) {
                    fr.attr('src', sel);
                }
            });
            $('.judgedbar.active span').hover(function() {
                var inn = $(this).index();
                $('.judgedbar.active span').removeClass('active');
                $(this).addClass('active');
                $(this).parent().find('.pgress').css('width', inn * 10 + '%');
                //$('#cs').text(inn);
            });
            $('.judgedbar.active span').click(function() {
                var inn = $(this).index();
                var judger = '<?php echo $_SESSION["operator"] ?>';
                var file = $(this).parent().parent().parent().attr("alt");
                var type = $(this).parent().parent().parent().attr("data-type");
                var judge = confirm('Are you sure you want to judge \"' + file + '\" with score: \"' + inn + '\" ?');
                var id = '<?php echo $contestant ?>';
                if (judge) {
                    var xhttp;
                    if (window.XMLHttpRequest) {
                        xhttp = new XMLHttpRequest();
                    } else {
                        // code for IE6, IE5
                        xhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                }
                xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        window.location.href = "";
                        //alert(xhttp.responseText);
                    }
                };
                xhttp.open("GET", '../../server/?judge&id=' + id + '&score=' + inn + '&judger=' + judger + '&type=' + file, true);
                xhttp.send(null);
            });
            $('.gradingChoose .gc').lightGallery();
            $('.grading.<?php echo $oper ?>').addClass('currentAdmin');
            $('.grading.currentAdmin span').hover(function() {
                $(this).addClass('selected');
                $(this).prevAll().addClass('selected');
            });

            $('.grading.currentAdmin span').click(function() {
                $('.grading.currentAdmin span').removeClass('chosed');
                $(this).addClass('chosed');
                $(this).prevAll().addClass('chosed');
            });

            $('.grading.currentAdmin span').mouseleave(function() {
                $(this).parent().find('span').removeClass('selected');
            });
        </script>
    </body>


</html>
