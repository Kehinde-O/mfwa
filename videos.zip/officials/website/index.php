<?php
include '../server/index.php';
$action = $_REQUEST['action'];
$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if ($_SESSION['privilege'] === 'Judge') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if(strpos($action,' ')){
    $psn = strpos($action,' ')+1;
    $postid = substr($action,$psn,$psn+1);
    $action = substr($action,0,strpos($action,' '));
    $bd = $c->query("SELECT * FROM blog WHERE id='$postid'")->fetch_assoc();
    if($action === 'removeBlogPost'){
        if(is_file('../../images/'.$bd['picture'])){
                unlink('../../images/'.$bd['picture']);
            }
        $c->query("DELETE FROM blog WHERE id='$postid'");
        $error = '<div class="text-success text-center col-sm-12">'.substr($bd['title'],0,8).' Successfuly Removed From Blog.<br/><br/></div><div class="clearfix"></div>';
    }
    if($action === 'editBlogPost'){
        $action = 'editBlogPostBox';
        $bd = $c->query("SELECT * FROM blog WHERE id='$postid'")->fetch_assoc();
    }
    if($action === 'viewaffiliate'){
        $action = 'viewaffiliate';
        $bd = $c->query("SELECT * FROM sponsors WHERE id='$postid'")->fetch_assoc();
        $error = '<div class="text-success text-center col-sm-12">'.$bd['name'].' Successfuly Removed From Affiliates.<br/><br/></div><div class="clearfix"></div>';
        $c->query("DELETE FROM sponsors WHERE id='$postid'");
    }
    if($action === 'removeWinner'){
        $action = 'removeWinner';
        $c->query("DELETE FROM winnermodel WHERE id='$postid'");
        $error = '<div class="text-success text-center col-sm-12">'.$bd['firstName'].' Successfuly Removed From Winners.<br/><br/></div><div class="clearfix"></div>';
    }
}
$bd = $c->query("SELECT * FROM blog WHERE id='$postid'")->fetch_assoc();
if(isset($_POST['postblog'])){
    $picture = $_FILES['blogpic']['tmp_name'];
    $picturename = $_FILES['blogpic']['name'];
        $title = $_POST['blogtitle'];
        $tag = $_POST['blogtag'];
        $content = $_POST['blogcontent'];
        $date = date("d").' '.date("m").' '.date("Y");
        $ck = $c->query("SELECT * FROM blog WHERE title='".$title."' AND tag='".$tag."' AND content='".$content."'");
        if(mysqli_num_rows($ck) > 0){
            $error = '<div class="text-danger text-center col-sm-12">Sorry! Post Already Exist.<br/><br/></div><div class="clearfix"></div>';
        }else{
            move_uploaded_file($picture,'../../images/'.$picturename);
            $c->query("INSERT INTO blog"
                . "(title,tag,picture,date,content)"
                . " VALUES"
                . "('$title','$tag','$picturename','$date','$content')");
            $error = '<div class="text-success text-center col-sm-12">Post Successfuly Added.<br/><br/></div><div class="clearfix"></div>';
        }
        
    }
    if(isset($_POST['savedit'])){
        $ntitle = $_POST['edititle'];
        $ntag = $_POST['editag'];
        $npicture = $_FILES['editpicture']['tmp_name'];
        $npicturename = $_FILES['editpicture']['name'];
        $ncontent = $_POST['editcontent'];
        $doedit = '';
        if($ncontent === $bd['content'] && $ntag === $bd['tag'] && $ntitle === $bd['title'] && $npicturename === $bd['picture']){
            $error = '<div class="text-primary text-center col-sm-12">Nothing has changed!.<br/><br/></div><div class="clearfix"></div>';
        }
        else{
        if(isset($npicture)){
            if(is_file('../../images/'.$bd['picture'])){
                unlink('../../images/'.$bd['picture']);
            }
            move_uploaded_file($npicture,'../../images/'.$npicturename);
            $c->query("UPDATE blog SET title='$ntitle',tag='$ntag',content='$ncontent',picture='$npicturename' WHERE id='$postid'");
        }
        else{
            $c->query("UPDATE blog SET title='$ntitle',tag='$ntag',content='$ncontent' WHERE id='$postid'");
        }
        $error = '<div class="text-success text-center col-sm-12">Post Edit Successfuly Saved.<br/><br/></div><div class="clearfix"></div>';
        }
        
    }
    if(isset($_POST['changecontact'])){
        $webphone = $_POST['contactphone'];
        $c->query("UPDATE webcontent SET webPhone='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Contact Phone Number Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['savewhatsapp'])){
        $webphone = $_POST['whatsapp'];
        $c->query("UPDATE webcontent SET webWhatsappNumber='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Whatsapp Number Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['saveemail'])){
        $webphone = $_POST['webmail'];
        $c->query("UPDATE webcontent SET webEmail='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Contact Email Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['savecontacta'])){
        $webphone = $_POST['contacta'];
        $c->query("UPDATE webcontent SET webOfficeAddress='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Office Address Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['eventmodel'])){
        $webphone = $_POST['emodel'];
        $c->query("UPDATE webcontent SET webModelTotal='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Event Model has been Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['eventphoto'])){
        $webphone = $_POST['ephoto'];
        $c->query("UPDATE webcontent SET webPhotoTotal='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Event Photos has been Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['eventcountry'])){
        $webphone = $_POST['ecountry'];
        $c->query("UPDATE webcontent SET webCountriesTotal='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Countries has been Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['eventjudge'])){
        $webphone = $_POST['ejudge'];
        $c->query("UPDATE webcontent SET webJudgesTotal='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Judges has been Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['eventgrandprize'])){
        $webphone = $_POST['egrandprize'];
        $c->query("UPDATE webcontent SET webGrandPriceTotal='$webphone'");
        $error = '<div class="text-success text-center col-sm-12">Grand Prize has been Successfuly updated.<br/><br/></div><div class="clearfix"></div>';
    }
    if(isset($_POST['addwinner'])){
    $picture = $_FILES['winnerpic']['tmp_name'];
    $picturename = $_FILES['winnerpic']['name'];
        $fn = $_POST['winfname'];
        $ln = $_POST['winlname'];
        $em = $_POST['winemail'];
        $co = $_POST['wincountry'];
        $wy = $_POST['winyear'];
        $wl = $_POST['winlike'];
        $wf = $_POST['winfor'];
        $ck = $c->query("SELECT * FROM winnermodel WHERE email='$em' AND year='$wy' AND country='$co'");
        if(mysqli_num_rows($ck) > 0){
            $error = '<div class="text-danger text-center col-sm-12">Sorry! Winner Already Exist.<br/><br/></div><div class="clearfix"></div>';
        }else{
            move_uploaded_file($picture,'../../images/winners/'.$picturename);
            $c->query("INSERT INTO winnermodel"
                . "(firstName,lastName,email,country,year,likes,picture,winnerfor)"
                . " VALUES"
                . "('$fn','$ln','$em','$co','$wy','$wl','$picturename','$wf')");
            $error = '<div class="text-success text-center col-sm-12">New Winner Successfuly Added.<br/><br/></div><div class="clearfix"></div>';
        }
        
    }
    
    $operator = $_SESSION['operator'];$picture = $c->query("SELECT picture FROM systemusers WHERE username='$operator'")->fetch_assoc();

    if(isset($_POST['saveaffiliate'])){
        $name = $_POST['aname'];
        $link = $_POST['aurl'];
        $file = $_FILES ['afile']['tmp_name'];
        $filen = $_FILES['afile']['name'];
        $ck = $c->query("SELECT * FROM sponsors WHERE name='$name' AND link='$link'");
        if(mysqli_num_rows($ck) > 0){
            if(move_uploaded_file($file,'../../images/sponsors/'.$filen)){
            $c->query("UPDATE sponsors SET name='$name' link='$link' logo='$filen' WHERE name='$name' AND link='$link'");
               $error = '<div class="text-success text-center col-sm-12">Affiliate Information Updated.<br/><br/></div><div class="clearfix"></div>'; 
            }
        }
        else{
            if(move_uploaded_file($file,'../../images/sponsors/'.$filen)){
            //$c->query("UPDATE sponsors SET name='$name' link='$link' logo='$filen' WHERE name='$name' AND link='$link'");
            $c->query("INSERT INTO sponsors(name,link,logo) VALUES('$name','$link','$filen')");
               $error = '<div class="text-success text-center col-sm-12">New Affiliate Information Added.<br/><br/></div><div class="clearfix"></div>'; 
            }
        }
    }
    $sui = $c->query("SELECT * FROM sponsors");
    ?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Kehinde Omotoso Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../css/pace.css" rel="stylesheet" type="text/css"/>
        <style>
            .<?php echo $action ?>{
                display:block !important;
            }
        </style>
    </head>
    <body>
        <header class="header">

            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../website/?logout=true"><li class="icon icon-power"></li></a>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href="../">Website Settings</a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../images/site.png" alt=""/>
            <img class="adminlogo" src="<?php if($picture['picture'] === ''){ echo '../../images/loading.gif';} else{ echo '../../images/judges/'.$picture['picture'];} ?>" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../contestants/disqualified.view"><i class="icon icon-list"></i>  Disqualified Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li class="active"><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../website/affiliate.settings"><i class="icon icon-user"></i>Add Affiliate</a></li>
                        <li><a href="../website/viewaffiliate.settings"><i class="icon icon-user"></i>View Affiliate</a></li>
                        <li><a href="../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <!-- MAIN CONTENT STARTS HERE -->
        <section class="mainContent col-sm-11 col-xs-11 pull-right system">

            <!--Change Phone---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox contactPhone">
                <h3 class="title"><i class="icon icon-phone" style=""></i> Change Contact Phone</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter one or more Phone numbers separated by comma.
                    </div>
                    <input type="text" name="contactphone" placeholder="Enter Phone Numbers" required value="<?php echo $wc[0]['PHONE']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="changecontact">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Add system User----------------------End--------------------- -->


            <!--Change Whatsapp Phone---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox whatsappNumber">
                <h3 class="title"><i class="fa fa-whatsapp" style=""></i> Change Whatsapp Number</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter whatsapp contact numbers separated by comma.
                    </div>
                    <input type="text" name="whatsapp" placeholder="Enter Whatsapp Number" required value="<?php echo $wc[0]['WHATSAPP']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="savewhatsapp">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Add system User----------------------End--------------------- -->
            
            
            <!--Change Whatsapp Phone---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox affiliate">
                <h3 class="title"><i class="fa fa-user" style=""></i> Add New Or Update Affiliate</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="aname" placeholder="Affliate Name" required/>
                    <input type="url" name="aurl" placeholder="Affliate Website Address"/>
                    <input type="file" name="afile" placeholder="Picture" required/>
                    <button type="submit" class="btn btn-primary" name="saveaffiliate">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Add system User----------------------End--------------------- -->

            
            <?php $su = $c->query("SELECT * FROM blog"); ?>
            <div class="col-sm-5 col-xs-8 loginbox viewaffiliate">
                <h3 class="title"><i class="icon icon-notebook" style=""></i> Affiliates ( <?php echo mysqli_num_rows($sui) ?> )</h3>
                <?php echo $error ?>
                <div class="clearfix"></div>
                <?php
                        //$sui = $c->query("SELECT * FROM blog");
                        while($suu = $sui->fetch_assoc()){
                            echo '<div class="col-sm-12 allu">
                        <div class="col-sm-4" title="'.$suu['name'].'">'.substr($suu['name'],0,10).'...</div>
                        <div class="col-sm-4" title="'.$suu['link'].'">'.substr($suu['link'],0,15).'...</div>
                        <div class="col-sm-4"><a href="viewaffiliate '.$suu['id'].'.settings"><i class="icon icon-close"></i> Remove</i></a></div>
                    </div>';
                        }
                ?>
                
                <br/>
                <br/>
                <br/>
                <br/>
                <div class="clearfix"></div>
            </div>



            <!--Change Contact Email---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox contactEmail">
                <h3 class="title"><i class="icon icon-envelope" style=""></i> Change Contact Email</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter one or more contact email separated by comma.
                    </div>
                    <input type="email" name="webmail" placeholder="Enter Contact Emain" required value="<?php echo $wc[0]['EMAIL']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="saveemail">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Contact Email----------------------End--------------------- -->


            <!--Change Contact Email---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox contactAddress">
                <h3 class="title"><i class="icon icon-directions" style=""></i> Change Contact Address</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter one or more contact address separated by comma.
                    </div>
                    <input type="text" name="contacta" placeholder="Enter Contact Address" required value="<?php echo $wc[0]['ADDRESS']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="savecontacta">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Contact Email----------------------End--------------------- -->





            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox contestWinner">
                <h3 class="title"><i class="icon icon-trophy" style=""></i> Add Contest Winner</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-12 center-block" action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="winfname" placeholder="Enter Winner First Name" required/>
                    <input type="text" name="winlname" placeholder="Enter Winner Last Name" required/>
                    <input type="email" name="winemail" placeholder="Enter Winner Email" required/>
                    <select id="country" name="wincountry"></select>
                    <input type="text" name="winyear" placeholder="Enter Win Year" required/>
                    <input type="text" name="winlike" placeholder="Enter Winner Likes" required/>
                    <input type="text" name="winfor" placeholder="Enter Contest Name" required/>
                    <input type="file" name="winnerpic" placeholder="Choose Picture" required/>
                    <button type="submit" class="btn btn-primary" name="addwinner">Upload</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->
            
            
            <!--------------------REMOVE WINNER ---------------------------------->
            <?php $su = $c->query("SELECT * FROM winnermodel"); ?>
            <div class="col-sm-5 col-xs-8 loginbox removeWinner">
                <h3 class="title"><i class="icon icon-close" style=""></i> Remove Contest Winners (<?php echo mysqli_num_rows($su) ?>)</h3>
                <?php echo $error ?>
                <div class="clearfix"></div>
                <?php
                        $su = $c->query("SELECT * FROM winnermodel");
                        while($suu = $su->fetch_assoc()){
                            echo '<div class="col-sm-12 allu">
                        <div class="col-sm-4 col-xs-4" title="'.$suu['firstName'].' '.$suu['lastName'].'">'.substr($suu['firstName'].' '.$suu['lastName'],0,20).'...</div>
                        <div class="col-sm-4 col-xs-4" title="'.$suu['email'].'">'.substr($suu['email'],0,15).'...</div>
                        <div class="col-sm-4 col-xs-4"><a href="removeWinner '.$suu['id'].'.settings"><i class="icon icon-close"></i> Remove</i></a></div>
                    </div>';
                        }
                ?>
                
                <br/>
                <br/>
                <br/>
                <br/>
                <div class="clearfix"></div>
            </div>
            <!--------------------REMOVE WINNER ---------------------------------->


            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-7 col-xs-12 loginbox blogPost">
                <h3 class="title"><i class="icon icon-notebook" style=""></i> Add Blog Post</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-12 center-block" action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="blogtitle" placeholder="Title" required value="<?php echo $title; ?>"/>
                    <input type="text" name="blogtag" placeholder="Tag" required value="<?php echo $tag; ?>"/>
                    <textarea name="blogcontent" placeholder="Blog Post Body..." rows="10" style="resize:none;"><?php echo $content; ?></textarea>
                    <input type="file" class="" name="blogpic" id="blogPic" required/>
                    <button type="submit" name="postblog" class="btn btn-primary">Post</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->
            
            
            
            <!--Alter system User---------------------------------------------- -->
            <div class="col-sm-7 col-xs-12 loginbox editBlogPostBox">
                <h3 class="title"><i class="icon icon-notebook" style=""></i> Edit Blog Post</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-9 col-xs-12 center-block" action="" method="post" enctype="multipart/form-data">
                    <input type="text" name="edititle" placeholder="Title" required value="<?php echo $bd['title'] ?>"/>
                    <input type="text" name="editag" placeholder="Tag" required value="<?php echo $bd['tag'] ?>"/>
                    <textarea placeholder="Blog Post Body..." rows="10" style="resize:none;" name="editcontent"><?php echo $bd['content'] ?></textarea>
                    <input type="file" class="" id="blogPic" name="editpicture"/>
                    <button type="submit" class="btn btn-primary" name="savedit">Save Edit</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Alter system User----------------------End--------------------- -->


            <?php $su = $c->query("SELECT * FROM blog"); ?>
            <div class="col-sm-5 col-xs-8 loginbox removeBlogPost">
                <h3 class="title"><i class="icon icon-notebook" style=""></i> Blog Posts (<?php echo mysqli_num_rows($su) ?>)</h3>
                <?php echo $error ?>
                <div class="clearfix"></div>
                <?php
                        $su = $c->query("SELECT * FROM blog");
                        while($suu = $su->fetch_assoc()){
                            echo '<div class="col-sm-12 allu">
                        <div class="col-sm-4" title="'.$suu['title'].'">'.substr($suu['title'],0,10).'...</div>
                        <div class="col-sm-4" title="'.$suu['content'].'">'.substr($suu['content'],0,15).'...</div>
                        <div class="col-sm-4"><a href="removeBlogPost '.$suu['id'].'.settings"><i class="icon icon-close"></i> Remove</i></a></div>
                    </div>';
                        }
                ?>
                
                <br/>
                <br/>
                <br/>
                <br/>
                <div class="clearfix"></div>
            </div>
            
            
            <?php $su = $c->query("SELECT * FROM blog"); ?>
            <div class="col-sm-5 col-xs-8 loginbox editBlogPost">
                <h3 class="title"><i class="icon icon-notebook" style=""></i> Blog Posts (<?php echo mysqli_num_rows($su) ?>)</h3>
                <div class="clearfix"></div>
                <?php
                        $su = $c->query("SELECT * FROM blog");
                        while($suu = $su->fetch_assoc()){
                            echo '<div class="col-sm-12 allu">
                        <div class="col-sm-4" title="'.$suu['title'].'">'.substr($suu['title'],0,10).'...</div>
                        <div class="col-sm-4" title="'.$suu['content'].'">'.substr($suu['content'],0,15).'...</div>
                        <div class="col-sm-4"><a href="editBlogPost '.$suu['id'].'.settings"><i class="icon icon-note"></i> Edit</i></a></div>
                    </div>';
                        }
                ?>
                
                <br/>
                <br/>
                <br/>
                <br/>
                <div class="clearfix"></div>
            </div>
            <!-------------------------------------------------------------------->
            
            <!--Change Event Model---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox eventModel">
                <h3 class="title"><i class="icon icon-note" style=""></i> Change Event Models</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter new model data and click save.
                    </div>
                    <input type="text" name="emodel" placeholder="Enter New Data" required value="<?php echo $wc[0]['MODELS']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="eventmodel">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Event Model---------------------------------------------- -->
            
            
            
            <!--Change Event Model---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox eventPhoto">
                <h3 class="title"><i class="icon icon-note" style=""></i> Change Event Photos</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter new photo data and click save.
                    </div>
                    <input type="text" name="ephoto" placeholder="Enter New Data" required value="<?php echo $wc[0]['PHOTOS']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="eventphoto">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Event Model---------------------------------------------- -->
            
            
            <!--Change Event Model---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox eventCountries">
                <h3 class="title"><i class="icon icon-note" style=""></i> Change Event Countries</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter new country data and click save.
                    </div>
                    <input type="text" name="ecountry" placeholder="Enter New Data" required value="<?php echo $wc[0]['COUNTRIES']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="eventcountry">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Event Model---------------------------------------------- -->
            
            
            <!--Change Event Model---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox eventJudges">
                <h3 class="title"><i class="icon icon-note" style=""></i> Change Event Judges</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter new judges data and click save.
                    </div>
                    <input type="text" name="ejudge" placeholder="Enter New Data" required value="<?php echo $wc[0]['JUDGES']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="eventjudge">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Event Model---------------------------------------------- -->
            
            <!--Change Event Model---------------------------------------------- -->
            <div class="col-sm-5 col-xs-12 loginbox eventGrandPrize">
                <h3 class="title"><i class="icon icon-note" style=""></i> Change Event Grand Prize</h3>
                <?php echo $error ?>
                <form class="loginForm col-sm-8 col-xs-12 center-block" action="" method="post">
                    <div class="well col-sm-12 text-center">
                        Enter new Grand Prize data and click save.
                    </div>
                    <input type="text" name="egrandprize" placeholder="Enter New Data" required value="<?php echo $wc[0]['GRANDPRICE']; ?>"/>
                    <button type="submit" class="btn btn-primary" name="eventgrandprize">Save</button>
                </form>
                <div class="clearfix"></div>
            </div>
            <!--Change Event Model---------------------------------------------- -->
            
            


        </section>

        <!-- MAIN CONTENT ENDS HERE -->



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/bootstrap.js" type="text/javascript"></script>
        <script src="../js/pace.js" type="text/javascript"></script>
        <script src="../js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
        <script src="../js/mapstat.js" type="text/javascript"></script>
        <script src="../js/Chart.js" type="text/javascript"></script>
        <script src="../../js/countries.js" type="text/javascript"></script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">
            populateCountries("country");
        </script>
    </body>
</html>
