<?php
include '../../server/index.php';

$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../../login/');
}
/* if ($_SESSION['privilege'] !== 'Admin' || $_SESSION['privilege'] !== 'Tech Support') {
  $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
  header('location:../login/');
  } */

$email = $_REQUEST['action'];
$id = $_REQUEST['id'];
$c->query("UPDATE messages SET status='read' WHERE id='$id'");
$inbox = $c->query("SELECT * FROM messages WHERE type='inbox'");
$sent = $c->query("SELECT * FROM messages WHERE type='sent'");
$trash = $c->query("SELECT * FROM messages WHERE type='trash'");
$message = $c->query("SELECT * FROM messages WHERE id='$id' AND email='$email'")->fetch_assoc();

if($_REQUEST['action'] === 'delete'){
    $c->query("UPDATE messages SET type='trash' WHERE id='$id'");
    header('location:../inbox.open');
}
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Miss Fashion Week Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Kehinde Omotoso"/>
        <link href="../../css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../../fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/bootstrap3-wysihtml5.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../../css/pace.css" rel="stylesheet" type="text/css"/>
        <style>
            .messageOptions a.inbox{
                border-left-color:#428bca;
                font-weight:bold;
            }
        </style>
    </head>
    <body>
        <header class="header">
            <i class="icon icon-menu menu"></i>

            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../../message/?logout=true"><li class="icon icon-power"></li></a>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href="../">Messages</a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../../images/site.png" alt=""/>
            <img class="adminlogo" src="../../images/admin.jpg" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../../contestants/disqualified.view"><i class="icon icon-list"></i>  Disqualified Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li class="active"><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <section class="mainContent col-sm-11 col-xs-11 pull-right">

            <div class="col-sm-3 inbox-section col-xs-12">
                    <a href="../compose/" class="btn btn-primary col-sm-12 col-xs-12">Compose</a>
                    <div class="col-sm-12 clearfix"></div>
                    <br/>
                    <div class="col-sm-12 messageOptions">
                        <a href="../inbox.open" class="inbox"><i class="fa fa-inbox"></i> Inbox <span class="label label-info pull-right"><?php echo mysqli_num_rows($inbox) ?></span></a>
                        <a href="../sent.open" class="sent"><i class="icon icon-envelope"></i> Sent <span class="label label-info pull-right"><?php echo mysqli_num_rows($sent) ?></span></a>
                        <a href="../trash.open" class="trash"><i class="icon icon-trash"></i> Trash <span class="label label-danger pull-right"><?php echo mysqli_num_rows($trash) ?></span></a>
                    </div>
                </div>

            <div class="col-sm-1"></div>

            <div class="col-sm-9 inbox-body col-xs-12">
                <h4 class="title">Read Message</h4>
                <div class="titlesubject">
                    <h4><?php echo $message['name'] ?></h4>
                    <span style="font-weight:normal;color:#999;">From: <?php echo $message['email'] ?></span>
                    <br/>
                    <span style="font-weight:normal;color:#999;">Sent: <?php echo $message['date'] ?></span>
                </div>
                <div class="col-sm-12 col-xs-12 readbody">
                    <?php echo $message['message'] ?>
                </div>
                <div class="clearfix"><br/></div>
                <a href="../read/<?php echo 'delete_'.$id.'.read'; ?>" class="btn btn-danger pull-left"><i class="fa fa-trash"></i> Delete</a>
                <a href="../compose/<?php echo $email ?>.send" class="btn btn-primary pull-right"><i class="icon icon-action-redo"></i> Reply</a>
            </div>


        </section>



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="../http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../../js/jquery.js" type="text/javascript"></script>
        <script src="../../js/bootstrap.js" type="text/javascript"></script>
        <script src="../../js/pace.js" type="text/javascript"></script>
        <script src="../../js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
        <script src="../../js/mapstat.js" type="text/javascript"></script>
        <script src="../../js/Chart.js" type="text/javascript"></script>
        <script src="../../js/bootstrap3-wysihtml5.all.js" type="text/javascript"></script>
        <script type="text/javascript">
                    $('#sendbody').wysihtml5();
        </script>
        <script src="../../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">

        </script>
    </body>
</html>
