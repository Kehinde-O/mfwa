<?php
include '../server/index.php';

$action = $_REQUEST['action'];
$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}
/*if ($_SESSION['privilege'] !== 'Admin' || $_SESSION['privilege'] !== 'Tech Support') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:../login/');
}*/
$inbox = $c->query("SELECT * FROM messages WHERE type='inbox'");
$sent = $c->query("SELECT * FROM messages WHERE type='sent'");
$trash = $c->query("SELECT * FROM messages WHERE type='trash'");
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Miss Fashion Week Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Kehinde Omotoso"/>
        <link href="../css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="../css/pace.css" rel="stylesheet" type="text/css"/>
        <style>
            .messageOptions a.<?php echo $action ?>{
                border-left-color:#428bca;
                font-weight:bold;
            }
        </style>
    </head>
    <body>
        <header class="header">
            <i class="icon icon-menu menu"></i>

            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="../message/?logout=true"><li class="icon icon-power"></li></a>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href="../">Messages</a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="../images/site.png" alt=""/>
            <img class="adminlogo" src="../images/admin.jpg" alt=""/>
            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="../">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="../contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="../contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="../contestants/disqualified.view"><i class="icon icon-list"></i>  Disqualified Contestants</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li class="active"><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="../message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="../message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="../system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="../system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="../system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="../system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="../system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="../website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="../website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="../website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="../website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="../website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="../website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="../website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="../website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="../website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="../website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="../website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="../website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="../website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="../website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <section class="mainContent col-sm-11 col-xs-11 pull-right">

                <div class="col-sm-3 inbox-section col-xs-12">
                    <a href="compose/" class="btn btn-primary col-sm-12 col-xs-12">Compose</a>
                    <div class="col-sm-12 clearfix"></div>
                    <br/>
                    <div class="col-sm-12 messageOptions">
                        <a href="inbox.open" class="inbox"><i class="fa fa-inbox"></i> Inbox <span class="label label-info pull-right"><?php echo mysqli_num_rows($inbox) ?></span></a>
                        <a href="sent.open" class="sent"><i class="icon icon-envelope"></i> Sent <span class="label label-info pull-right"><?php echo mysqli_num_rows($sent) ?></span></a>
                        <a href="trash.open" class="trash"><i class="icon icon-trash"></i> Trash <span class="label label-danger pull-right"><?php echo mysqli_num_rows($trash) ?></span></a>
                    </div>
                </div>

            <div class="col-sm-1"></div>

            <div class="col-sm-9 inbox-body col-xs-12">
                <div class="title" style="overflow:hidden;"><?php echo $action ?>
                    <div class="col-sm-4 col-xs-9 pull-right">
                        <form class="sm">
                            <input type="text" placeholder="Search Messages" class="col-xs-9 col-sm-9"/>
                            <button class="btn btn-default col-xs-3 col-sm-3"><i class="icon icon-magnifier"></i></button>
                        </form>
                    </div>
                </div>
                
                <ul>
                    <?php
                        $messages = $c->query("SELECT * FROM messages WHERE type='$action' ORDER BY id DESC");
                        while($m = $messages->fetch_assoc()){
                            if($m['type'] === 'inbox'){
                            $status = str_replace('unread',' icon-envelope',$m['status']);
                            $statusr = str_replace('read',' icon-envelope-open',$m['status']);
                            }
                            $statuss = '';
                            if($m['type'] === 'trash'){
                                $statuss = str_replace('trash',' icon-trash',$m['type']);
                            }
                            else if($m['type'] === 'sent'){
                                $statuss = str_replace('sent',' icon-cursor',$m['type']);
                            }
                            echo '<li>
                        <span class="col-xs-5 col-sm-4 msender" title="'.$m['name'].'"><i class="icon '.$status.' '.$statusr.' '.$statuss.'"></i> <a href="read/'.$m['email'].'_'.$m['id'].'.read">'.$m['name'].'</a></span>
                        <span class="col-xs-4 col-sm-3 mtitle unread" title="'.$m['email'].'">'.substr($m['email'],0,15).'...</span>
                        <span class="col-xs-3 col-sm-3 mbody hidden-xs" title="'.$m['message'].'">'.htmlspecialchars(substr($m['message'],0,20)).'...</span>
                        <span class="col-xs-3 col-sm-2 mdate" title="'.$m['date'].'">'.$m['date'].'</span>
                    </li>';
                        }
                        
                    ?>
                </ul>
                
            </div>
           

        </section>



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="../http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/bootstrap.js" type="text/javascript"></script>
        <script src="../js/pace.js" type="text/javascript"></script>
        <script src="../js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
        <script src="../js/mapstat.js" type="text/javascript"></script>
        <script src="../js/Chart.js" type="text/javascript"></script>
        <script type="text/javascript">
            
        </script>
        <script src="../js/main.js" type="text/javascript"></script>
        <script type="text/javascript">

        </script>
    </body>
</html>
