<?php
include 'server/index.php';
$completed = $c->query("SELECT * FROM application WHERE judged='completed'");
$uncompleted = $c->query("SELECT * FROM application WHERE judged='uncompleted' AND applicationStatus='completed'");
$co = mysqli_num_rows($completed);
$uco = mysqli_num_rows($uncompleted);

$countries = array(
    'Nigeria ',
    'South Africa ',
    'Uganda ',
    'Kenya',
    'Congo'
    
);

$ng = $c->query("SELECT country FROM application WHERE country='Nigeria'");
$ngcount = mysqli_num_rows($ng);
$sa = $c->query("SELECT country FROM application WHERE country='South Africa'");
$sacount = mysqli_num_rows($sa);
$ug = $c->query("SELECT country FROM application WHERE country='Uganda'");
$ugcount = mysqli_num_rows($ug);
$ke = $c->query("SELECT country FROM application WHERE country='Kenya'");
$kecount = mysqli_num_rows($ke);
$con = $c->query("SELECT country FROM application WHERE country LIKE '%Congo%'");
$cocount = mysqli_num_rows($con);
$et = $c->query("SELECT country FROM application WHERE country LIKE '%Ethiopia%'");
$etcount = mysqli_num_rows($et);
$bot = $c->query("SELECT country FROM application WHERE country LIKE '%Botswana%'");
$botcount = mysqli_num_rows($bot);
$tz = $c->query("SELECT country FROM application WHERE country LIKE '%Tanzania%'");
$tzcount = mysqli_num_rows($tz);
$year = date("Y");
$visitors = $c->query("SELECT * FROM statistics WHERE year='$year' AND data='visitors'");
$visi = array();
while($vs = $visitors->fetch_assoc()){
    array_push($visi,$vs['value']);
}
$members = $c->query("SELECT * FROM statistics WHERE year='$year' AND data='newmembers'");
$mem = array();
while($me = $members->fetch_assoc()){
    array_push($mem,$me['value']);
}
$income = $c->query("SELECT * FROM statistics WHERE year='$year' AND data='income'");
$inco = array();
while($inc = $income->fetch_assoc()){
    array_push($inco,$inc['value']);
}

$appcount = $c->query("SELECT * FROM application WHERE paid='true'");
$logout = $_REQUEST['logout'];
if (isset($logout)) {
    session_unset();
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Please Login...<br/><br/></div><div class="clearfix"></div>';
    header('location:login/');
}
if (!isset($_SESSION['operator'])) {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Access Denied, you must login first.<br/><br/></div><div class="clearfix"></div>';
    header('location:login/');
}
if ($_SESSION['privilege'] !== 'Admin') {
    $_SESSION['error'] = '<div class="text-danger text-center col-sm-12">Unauthorised access, Access Denied.<br/><br/></div><div class="clearfix"></div>';
    header('location:login/');
}
$gm = $c->query("SELECT * FROM messages WHERE status='unread' AND type='inbox'");
$memc = $c->query("SELECT SUM(value) as val FROM statistics WHERE year='$year' AND data='newmembers'")->fetch_assoc();
$visc = $c->query("SELECT SUM(value) as val FROM statistics WHERE year='$year' AND data='visitors'")->fetch_assoc();

$operator = $_SESSION['operator'];
$picture = $c->query("SELECT picture FROM systemusers WHERE username='$operator'")->fetch_assoc();
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>Miss Fashion Week Admin Template</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="Kehinde Omotoso"/>
        <link href="css/bootstrap-theme.css" rel="stylesheet" type="text/css"/>
        <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/source-sans-pro.css" rel="stylesheet" type="text/css"/>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
        <link href="css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css"/>
        <link href="css/pace.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header class="header">
            <!-- RIGHT CONTENTS STARTS HERE --------------- -->
            <ul class="rightPanel">
                <a href="?logout=true"><li class="icon icon-power"></li></a>
                <li class="icon icon-envelope"><span><?php echo mysqli_num_rows($gm) ?></span>
                    <ul class="animated bounceInDown">
                        <?php
                        while ($gmm = $gm->fetch_assoc()) {
                            echo '
                        <li>
                            <div class="col-sm-12">
                                <a href="message/read/' . $gmm['email'] . '_'.$gmm['id'].'.read" class="col-xs-8 pull-left text-left"><i class="icon icon-envelope"></i> ' . substr($gmm['message'], 0, 20) . '...</a>
                                <div class="col-xs-4 pull-right text-right">05 Sep 2016</div>
                            </div>
                        </li>';
                        }
                        ?>
                    </ul>
                </li>
            </ul>

            <!-- RIGHT CONTENTS ENDS HERE --------------- -->
        </header>
        <!-- HEADER ENDS ===================================== -->


        <!-- TREE PANEL STARTS ===================================== -->
        <header class="treePanel">
            <div class="col-sm-3 treeTitle"><?php echo $_SESSION['operator'] ?></div>
            <div class="treeTree"><?php echo $_SESSION['privilege'] ?> / <a href="">Statistics</a></div>
        </header>

        <!-- TREE PANEL ENDS ===================================== -->



        <!-- LEFT NAVIGATION STARTS HERE --------------- -->
        <div class="leftNav">
            <img class="logo" src="images/site.png" alt=""/>
            <img class="adminlogo" src="<?php if($picture['picture'] === ''){ echo '../images/loading.gif';} else{ echo '../images/judges/'.$picture['picture'];} ?>" alt=""/>

            <ul class="leftlist">
                <?php
                if ($_SESSION['privilege'] === 'Admin') {
                    echo '<li class="active"><i class="icon icon-home"></i>
                    <ul>
                        <li><a href="">Statistics</a></li>
                    </ul>
                </li>';
                }
                ?>


                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support' || $_SESSION['privilege'] === 'Judge') {
                    echo '<li><i class="icon icon-people"></i>
                    <ul>
                        <li><a>Contestants</a></li>
                        <li><a href="contestants/all.view"><i class="icon icon-list"></i>  View All Contestants</a></li>
                        <li><a href="contestants/top20.view"><i class="icon icon-list"></i>  Top 20 Contestants</a></li>
                        <li><a href="contestants/nominated.view"><i class="icon icon-check"></i> Nominated Contestants</a></li>
                        <li><a href="system/delvercon.settings"><i class="icon icon-trash"></i>  Delete Application</a></li>
                        <li><a href="system/delvercon.settings"><i class="icon icon-check"></i>  Verify Contestant</a></li>
                        <li><a href="system/delvercon.settings"><i class="icon icon-refresh"></i>  Reset Contestant</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-envelope"></i>
                    <ul>
                        <li><a>Messages</a></li>
                        <li><a href="message/inbox.open"><i class="icon icon-envelope-letter"></i>  Inbox</a></li>
                        <li><a href="message/compose/"><i class="icon icon-note"></i>  Compose New</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-settings"></i>
                    <ul>
                        <li><a>System Settings</a></li>
                        <li><a href="system/addUser.settings"><i class="icon icon-user"></i> Add System User</a></li>
                        <li><a href="system/removeUser.settings"><i class="icon icon-close"></i> Remove System User</a></li>
                        <li><a href="system/changePrivilege.settings"><i class="icon icon-note"></i> Change User Privilege</a></li>
                        <li><a href="system/changePassword.settings"><i class="icon icon-key"></i> Change User Password</a></li>
                        <li><a href="system/viewUsers.settings"><i class="icon icon-people"></i> View All Users</a></li>
                    </ul>
                </li>';
                }
                ?>

                <?php
                if ($_SESSION['privilege'] === 'Admin' || $_SESSION['privilege'] === 'Tech Support') {
                    echo '<li><i class="icon icon-globe"></i>
                    <ul>
                        <li><a>Website Settings</a></li>
                        <li><a href="website/affiliate.settings"><i class="icon icon-user"></i>Add Affiliate</a></li>
                        <li><a href="website/viewaffiliate.settings"><i class="icon icon-user"></i>View Affiliate</a></li>
                        <li><a href="website/contactPhone.settings"><i class="icon icon-phone"></i>Change Contact Phone</a></li>
                        <li><a href="website/whatsappNumber.settings"><i class="fa fa-whatsapp"></i>Change Whatsapp</a></li>
                        <li><a href="website/contactEmail.settings"><i class="icon icon-envelope-letter"></i>  Change Contact Email</a></li>
                        <li><a href="website/contactAddress.settings"><i class="icon icon-directions"></i>  Change Contact Address</a></li>
                        <li><a href="website/contestWinner.settings"><i class="icon icon-user"></i> Add Winner</a></li>
                        <li><a href="website/removeWinner.settings"><i class="icon icon-close"></i> Remove Winner</a></li>
                        <li><a href="website/blogPost.settings"><i class="icon icon-book-open"></i> Add New Blog Post</a></li>
                        <li><a href="website/editBlogPost.settings"><i class="icon icon-note"></i> Edit Blog Post</a></li>
                        <li><a href="website/removeBlogPost.settings"><i class="icon icon-close"></i> Remove Blog Post</a></li>
                        <li><a href="website/eventModel.settings"><i class="icon icon-note"></i> Update Event Models</a></li>
                        <li><a href="website/eventPhoto.settings"><i class="icon icon-note"></i> Update Event Photos</a></li>
                        <li><a href="website/eventCountries.settings"><i class="icon icon-note"></i> Update Event Countries</a></li>
                        <li><a href="website/eventJudges.settings"><i class="icon icon-note"></i> Update Event Judges</a></li>
                        <li><a href="website/eventGrandPrize.settings"><i class="icon icon-note"></i> Update Grand Prize</a></li>
                    </ul>
                </li>';
                }
                ?>

            </ul>
        </div>
        <!-- LEFT NAVIGATION ENDS HERE --------------- -->

        <section class="mainContent col-sm-11 col-xs-11 pull-right">

            <div class="col-sm-8 mapping statistics col-xs-12">
                <div class="title">STATISTIC OF MEMBERS IN AFRICA</div>
                <div id="map"></div>
            </div>

            <div class="col-sm-1"></div>

            <div class="stats col-sm-4 statistics col-xs-12">
                <div class="title">ALL APPLICATION STATUS</div>
                <div id="doughnutChart" class="chart"></div>
                <div class="pieSummary">
                    <div class="col-xs-6 col-sm-6 uncompleted">
                        <span>Not Judged</span>
                        <?php echo $uco ?>
                    </div>
                    <div class="col-xs-6 col-sm-6 completed">
                        <span>Judged</span>
                        <?php echo $co; ?>
                    </div>
                </div>
            </div>



            <div class='col-sm-8 statistics col-xs-12'>
                <div class='title'>
                    VISITORS ( <?php echo $visc['val'] ?> )
                </div>
                <div class='linechart' id='p1'>
                    <canvas id='c1'></canvas>
                </div>
            </div>

            <div class='stats col-sm-4 statistics col-xs-12' style="height:350px;overflow:hidden;">
                <div class='title'>
                    NEW MEMBERS ( <?php echo $memc['val'] ?> )
                </div>
                <div class='linechart' id='p2'>
                    <canvas id='c2'></canvas>
                </div>
            </div>

            <div class="clearfix"></div>
            <div class='col-sm-12 statistics col-xs-12' style="height:350px;overflow:hidden; width:100% !important;">
                <div class='title'>
                    INCOME ($) USD <?php echo mysqli_num_rows($appcount) * 25 ?>
                </div>
                <div class='linechart' id='p3'>
                    <canvas id='c3'></canvas>
                </div>
            </div>

        </section>



        <div class="clearfix divider"></div>
        <div class="clearfix divider"></div>
        <footer class="footer">Admin Theme brought to you by: <a href="http://facebook.com/kehindejohnomotoso" target="_blank">Kehinde Omotoso</a></footer>
        <script src="js/jquery.js" type="text/javascript"></script>
        <script src="js/bootstrap.js" type="text/javascript"></script>
        <script src="js/pace.js" type="text/javascript"></script>
        <script src="js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
        <script src="js/mapstat.js" type="text/javascript"></script>
        <script src="js/Chart.js" type="text/javascript"></script>
        <script type="text/javascript">
            var data1 = {
                labels: ["Jan", "Feb", "Mar", "April", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets: [
                    {
                        fillColor: "rgba(255,255,255,.1)",
                        strokeColor: "#4f5467",
                        pointColor: "#4f5467",
                        pointStrokeColor: "#4f5467",
                        data: [<?php echo $visi[0] ?>, <?php echo $visi[1] ?>, <?php echo $visi[2] ?>, <?php echo $visi[3] ?>, <?php echo $visi[4] ?>, <?php echo $visi[5] ?>, <?php echo $visi[6] ?>, <?php echo $visi[7] ?>, <?php echo $visi[8] ?>, <?php echo $visi[9] ?>, <?php echo $visi[10] ?>, <?php echo $visi[11] ?>]
                    }
                ]
            };
            var data2 = {
                labels: ["Jan", "Feb", "Mar", "April", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets: [
                    {
                        fillColor: "rgba(255,255,255,.1)",
                        strokeColor: "#4f5467",
                        pointColor: "#4f5467",
                        pointStrokeColor: "#4f5467",
                        data: [<?php echo $mem[0] ?>, <?php echo $mem[1] ?>, <?php echo $mem[2] ?>, <?php echo $mem[3] ?>, <?php echo $mem[4] ?>, <?php echo $mem[5] ?>, <?php echo $mem[6] ?>, <?php echo $mem[7] ?>, <?php echo $mem[8] ?>, <?php echo $mem[9] ?>, <?php echo $mem[10] ?>, <?php echo $mem[11] ?>]
                    }
                ]
            };
            var data3 = {
                labels: ["Jan", "Feb", "Mar", "April", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                datasets: [
                    {
                        fillColor: "rgba(255,255,255,.1)",
                        strokeColor: "#4f5467",
                        pointColor: "#4f5467",
                        pointStrokeColor: "#4f5467",
                        data: [<?php echo $inco[0] ?>, <?php echo $inco[1] ?>, <?php echo $inco[2] ?>, <?php echo $inco[3] ?>, <?php echo $inco[4] ?>, <?php echo $inco[5] ?>, <?php echo $inco[6] ?>, <?php echo $inco[7] ?>, <?php echo $inco[8] ?>, <?php echo $inco[9] ?>, <?php echo $inco[10] ?>, <?php echo $inco[11] ?>]
                    }
                ]
            };
            var gdpData = {
                "NG": <?php echo $ngcount ?>,
                "ZA": <?php echo $sacount ?>,
                "UG": <?php echo $ugcount ?>,
                "KE": <?php echo $kecount ?>,
                "CG": <?php echo $cocount ?>,
                "ET": <?php echo $etcount ?>,
                "BW": <?php echo $botcount ?>,
                "TZ": <?php echo $tzcount ?>
            };
        </script>
        <script src="js/main.js" type="text/javascript"></script>
        <script type="text/javascript">

            $(function() {
                $("#doughnutChart").drawDoughnutChart([
                    {title: "Not Judged Applications", value: <?php echo $uco ?>, color: "#fb9678"},
                    {title: "Judged Applications", value: <?php echo $co ?>, color: "#4f5467"}
                ]);
            });
        </script>
    </body>
</html>
