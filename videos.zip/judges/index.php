<?php
    include '../handler.php';

?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Judges - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <meta name="author" content="Kehinde Omotoso">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../howitworks/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><a href="../join/"><span><i class="icon icon-user"></i> New Member?</span> Register</a></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a class="active" href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-3 col-xs-8'>OUR JUDGES</h2>
        </section>


        <section class="about team judge col-sm-11 col-xs-11 center-block">

            <?php
            $j = new dataBaseContent();
            $jd = $j->judges();
            for ($i = 0; $i < count($jd); $i++) {
                echo '<div class="col-sm-3 teamMate">
                <div class="tVeil">
                    <span class="biog">' . $jd[$i]['BIOGRAPHY'] . '</span>
                </div>
                <div class="mate">
                    <img src="../images/judges/' . $jd[$i]['PICTURE'] . '" alt="" />
                    <h4 class="name">' . $jd[$i]['FIRSTNAME'] . ' ' . $jd[$i]['LASTNAME'] . '</h4>
                    <div class="jobDescription">' . $jd[$i]['POSITION'] . '</div>
                </div>
            </div>';
            }
            ?>

            <div class="clearfix"><br/></div>
        </section>

        
        <div class='clearfix'></div>
        

        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="text" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social">
                    <h5>Connect with us</h5>
                    <a class="social"><i class="icon icon-social-facebook"></i></a>
                    <a class="social"><i class="icon icon-social-youtube"></i></a>
                    <a class="social"><i class="icon icon-social-google"></i></a>
                    <a class="social"><i class="icon icon-social-twitter"></i></a>
                    <a class="social"><i class="icon icon-social-instagram"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if(count($blog) > 3){
                    $count = 3;
                }
                
                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="../blog/post/'.$blog[$i]['LINK'].'">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/'.$blog[$i]['PICTURE'].'" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                
                
                ?>
            </div>
            
            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>

        <script src="../js/jquery.js"></script>
        <script src="../js/flick.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/jquery.vmap.js" type="text/javascript"></script>
        <script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
        <script src="../js/main.js"></script>
        <script type="text/javascript">
            $('.submitPre').click(function(e){
                e.preventDefault();
                var fname = $('#fn').val();
                var lname = $('#ln').val();
                var em = $('#em').val();
                var sq = $('#sq').val();
                var sa = $('#sa').val();
                if(fname.length > 0 && lname.length > 0 && em.length > 0 && sa.length > 0 && sq.length > 0){
                    $('.regError').fadeOut(1000);
                    xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        var res = xhttp.responseText;
                        if(res === '2'){
                            $('.regError').text('An account already created for "'+em+'".If you are the owner of this account, please wait for you payment to be confirmed and a password sent to your email. Thank you');
                            $('.regError').fadeIn(1000);
                        }
                        else if(res === '0'){
                            $('.regError').text('Account could not be created. If this problem persists please contact our officials at kenny@mfmail.com');
                            $('.regError').fadeIn(1000);
                        }
                    }
                };
                xhttp.open("GET", "../handler.php?preReg&email=" + em + "&fname=" + fname+"&lname="+lname+"&sa="+sa+"&sq="+sq, true);
                xhttp.send();
                }
                else{
                   $('.regError').fadeIn(1000);
                }
            });
            $('#subscribeButton').click(function(){
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if(name.length >0 && email.length > 0){
                    $('#subscribeName').css('border-color','green');
                    $('#subscribeMail').css('border-color','green');
                    if(email.indexOf('.com') !==-1 && email.indexOf('@') !==-1){
                        xhttp.onreadystatechange = function(){
                      if(xhttp.readyState === 4 && xhttp.status === 200){
                          $('.subs').css('display','block');
                      }  
                    };
                    xhttp.open("GET","../handler.php?subscribe&email="+email+"&name="+name,true);
                    xhttp.send(null);
                    }
                    else{
                        $('#subscribeMail').css('border-color','red');
                    }
                }
                else{
                    $('#subscribeName').css('border-color','red');
                    $('#subscribeMail').css('border-color','red');
                }
            });
        </script>

    </body> 
    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>
    
    
    <div class="sideSocials blogSocial">
        <a class="" href="http://www.facebook.com/missfashionweekafrica"><i class="icon icon-social-facebook"></i></a>
        <a class="" href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA"><i class="icon icon-social-youtube"></i></a>
        <a class="" href="http://www.pinterest.com/missfwafrica"><i class="icon icon-social-pinterest"></i></a>
        <a class="" href="http://www.twitter.com/missfwafrica"><i class="icon icon-social-twitter"></i></a>
        <a class="" href="http://www.instagram.com/missfashionweekafrica"><i class="icon icon-social-instagram"></i></a>
        <a class="" href="http://missfashionweekafrica.tumblr.com/"><i class="icon icon-social-tumblr"></i></a>
        <?php 
            $wp = new dataBaseContent();
            $wpp = $wp->webcontent();
        ?>
        <a class="" href="tel:<?php echo $wpp[0]['WHATSAPP'] ?>" title="<?php echo $wpp[0]['WHATSAPP'] ?>"><i class="fa fa-whatsapp"></i></a>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div>  
    
   

</html>
