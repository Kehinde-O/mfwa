<?php
include '../handler.php';
?><!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Rules And Regulations - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-3 col-xs-6'>CONTEST RULES</h2>
        </section>

        <div class='account howitworks col-sm-8 col-xs-11 center-block'>

            <div class='col-sm-9 col-xs-12 accountForms center-block'>
                <h4 class='title'>To be eligible for this program you need to be:</h4>
                1. An African model. <br/>
                2. Between the age of 18 - 30 years <br/>
                3. Possess a valid international passport with at least two (2) years to expiration date
            </div>
            <br/>
            <div class="clearfix"></div>

            <div class='col-sm-9 col-xs-12 accountForms center-block'>
                <h4 class='title'>Requirements</h4>
                Such term as "Contestants" used in these rules 
                and regulations are referring to the person applying 
                for entrance into the Miss Fashion Week Africa contest.
                Such term as "Winner" used in these rules and regulations
                are referring to the person who has applied for entrance,
                paid the entry fee, was accepted as a participant, 
                and won a city, state, or national title. 
                <ul style="margin:20px auto;">
                    <li>a.Contestants must have completed and submitted the online form to take part in the contest.</li>
                    <li>b.African models between the ages 18-30 years old can compete.</li>
                    <li>c.Contestants must be a naturally born female in order to compete in the Miss Fashion Week Africa contest. </li>
                    <li>d.Contestants must be an African residing in one of the African countries in order to compete in the Miss Fashion Week Africa contest. </li>
                    <li>e.Contestants understand that the ENTRY FEE in the amount of $25.00 must be paid for the entrance of the Miss Fashion Week Africa contest.  </li>
                    <li>f.Contestants understand that the ENTRY FEE is non-refundable and non-transferable; and must be paid in full before she can compete in the Miss Fashion Week Africa Contest. </li>
                    <li>g.Contestants understands that her entry fee includes entry into the city, state, and national title; and includes her crown and sash prize package for the title of which she wins for the contest. </li>
                    <li>h.Contestants understand that her crown and sash package will be shipped directly from the manufacturers and will take up to 4-6 weeks to be received. </li>
                    <li>i.Contestants understands she must compete in the five main areas of competition in order to be selected as a Miss Fashion Week contest winner; which includes the Interview, Platform, and Photogenic competitions. </li>
                    <li>j.Contestants understand that she must submit the required materials and information for the appropriate competitions (which includes the Interview Questions, and Photogenic head-shot photo) along with her entry application and entry fee. </li>
                    <li>k.Contestants understand that she must uphold a pleasant, professional, and friendly demeanor at all times while representing a Miss Fashion Week title. </li>
                    <li>l.Contestants understand that the judges' decisions and scoring are final and will not be changed. </li>
                    <li>m. If the Contestants become a Fashion Week title winner, she understands that she will receive the following city, state, or national prizes and awards for the title she wins for 1 year: rhinestone crown, satin embroidered sash, and official certificate from the Miss Fashion Week organization.  </li>
                    <li>n.We reserve the right to accept or reject photos submitted. All submitted photos and other materials and information become property of Miss Fashion Week Africa, Miss Fashion Week USA, and their franchisees, affiliates and subsidiaries. We are not responsible or liable for photos and materials submitted in violation of copyright laws. </li>
                    <li>o.Contestants understand that the Miss Fashion Week organization reserves the right to the rules and regulations of the contest.  </li>
                    <li>p.Contestants are required to strictly adhere to the Miss Fashion Week rules and regulations; and if any of these rules are broken by the contestant, contestant understands that participation disqualification and title revocation will be the resulting resolution to the matter. </li>
                    <li>q.Winner understands that crown and sash must be turned in at the end of their 1 year title term. </li>
                    <li>r.Scoring is conducted on a 10-point scale:
                        <ul style="margin:10px auto;">
                            <li>9-10 = Excellent</li>
                            <li>7-8 = Very Good</li>
                            <li>5-6 = Good</li>
                            <li>3-4 = Average</li>
                            <li>1-2 = Below Average </li>
                            <li><a href="../quickform/"> Click here to get started!</a></li>
                        </ul>
                    </li>
                </ul>

            </div>
            <div class="clearfix"></div>
        </div>
        <div class='clearfix'></div>








        <!-- <div style="width:70% !important;display:block;margin:auto;padding:30px;text-align:left;"><p><img alt="" src="http://missfashionweekafrica.com/images/mf.jpg" style="display:block;margin:auto;"><br></p><p style="display:block;margin:auto;text-align:center;margin-bottom:60px;"><b>MISS FASHION WEEK AFRICA</b><br></p><p>Dear Kehinde Omotoso,<b><br></b></p><p>You have successfully been choosen to qualify for the MissFashionWeekAfrica contest. Your referencen number is MFWA_uhdj. Please log in to you account with the credentials bellow.<br></p><p>Email: familyomotosho@gmail.com<br></p><p>Password: abcdef.<br></p><p>Click here <a target="_blank" rel="nofollow" href="http://missfashionweekafrica.com/join/">http://missfashionweekafrica.com/join/</a> to login and start your application process. Please always check your email for further instructions. Good Luck.</p><p><br></p><p>Regards,&nbsp;Miss&nbsp;Fashion&nbsp;Week&nbsp;Africa.<br></p></div> -->








        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="text" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if (count($blog) > 3) {
                    $count = 3;
                }

                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="../blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                ?>
            </div>

            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>

        <script src="../js/jquery.js"></script>
        <script src="../js/flick.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/jquery.vmap.js" type="text/javascript"></script>
        <script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
        <script type="text/javascript">
            $('.submitPre').click(function(e) {
                e.preventDefault();
                var fname = $('#fn').val();
                var lname = $('#ln').val();
                var em = $('#em').val();
                var sq = $('#sq').val();
                var sa = $('#sa').val();
                if (fname.length > 0 && lname.length > 0 && em.length > 0 && sa.length > 0 && sq.length > 0) {
                    $('.regError').fadeOut(1000);
                    xhttp.onreadystatechange = function() {
                        if (xhttp.readyState === 4 && xhttp.status === 200) {
                            var res = xhttp.responseText;
                            if (res === '2') {
                                $('.regError').text('An account already created for "' + em + '".If you are the owner of this account, please wait for you payment to be confirmed and a password sent to your email. Thank you');
                                $('.regError').fadeIn(1000);
                            }
                            else if (res === '0') {
                                $('.regError').text('Account could not be created. If this problem persists please contact our officials at kenny@mfmail.com');
                                $('.regError').fadeIn(1000);
                            }
                        }
                    };
                    xhttp.open("GET", "../handler.php?preReg&email=" + em + "&fname=" + fname + "&lname=" + lname + "&sa=" + sa + "&sq=" + sq, true);
                    xhttp.send();
                }
                else {
                    $('.regError').fadeIn(1000);
                }
            });
            $('#subscribeButton').click(function() {
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if (name.length > 0 && email.length > 0) {
                    $('#subscribeName').css('border-color', 'green');
                    $('#subscribeMail').css('border-color', 'green');
                    if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                        xhttp.onreadystatechange = function() {
                            if (xhttp.readyState === 4 && xhttp.status === 200) {
                                $('.subs').css('display', 'block');
                            }
                        };
                        xhttp.open("GET", "../handler.php?subscribe&email=" + email + "&name=" + name, true);
                        xhttp.send(null);
                    }
                    else {
                        $('#subscribeMail').css('border-color', 'red');
                    }
                }
                else {
                    $('#subscribeName').css('border-color', 'red');
                    $('#subscribeMail').css('border-color', 'red');
                }
            });
        </script>

    </body> 
    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>


    
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div>  


<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        <script src="../js/main.js"></script>
</html>
