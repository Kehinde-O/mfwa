<?php
include '../handler.php';
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Blog - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <meta property="og:url"                content="<?php echo $actual_link ?>" />
        <meta property="og:image"                content="http://missfashionweekafrica.com/images/mf.jpg" />
        <meta property="og:type"               content="article" />
        <meta property="og:title"              content="Miss Fashion Week Africa Blog" />
        <meta property="og:description"        content="Welcome to the official blog page of the Miss Fashion Week Africa " />
        <meta property="fb:app_id"              content="308022776226378" />

        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
        <style>
            .social a{
                text-align:center !important;
                padding:8px;
            }
        </style>
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/" class="active">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader col-xs-12'>
            <h2 class='col-sm-3 col-xs-5'>OUR BLOG</h2>
            <form action="" method="post" class="msearch col-sm-3 col-xs-7 pull-right">
                <input type="text" placeholder="Search for a post" name="blog" class="col-sm-10 col-xs-9"/>
                <button type="submit" class="btn btn-primary col-sm-2 col-xs-3"><i class="icon icon-magnifier"></i> </button>
            </form>
        </section>

        <div class='blogList col-sm-12 col-xs-12 center-block'>

            <div class="col-sm-11 col-xs-12 center-block">
                <?php if (!isset($_POST['blog'])) { ?>

                    <?php
                    $dbc = new dataBaseContent();
                    $blog = $dbc->getPosts();

                    for ($i = 0; $i < count($blog); $i++) {
                        $blogId = $blog[$i]['ID'];
                        echo '<div class="blog col-sm-5 col-xs-12">
                    <span class="tag"><i class="icon icon-tag"></i> ' . $blog[$i]['TAG'] . '</span>
                    <h3 class="title">' . substr($blog[$i]['TITLE'], 0, 30) . '...</h3>
                    <span class="tag"><i class="icon icon-calendar"></i> ' . $blog[$i]['DATE'] . '</span>
                    <img src="../images/' . $blog[$i]['PICTURE'] . '" alt="" />
                    <div class="text lead">
                        ' . substr($blog[$i]['CONTENT'], 0, 50) . '...
                        <section class="social">
                            <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u='.$actual_link.'post/'.$blog[$i]['LINK'].'" target="_blank"><i class="icon icon-social-facebook"></i></a>
                            <a class="twitter" href="http://www.twitter.com/'.$actual_link .'post/'.$blog[$i]['LINK'].'" target="_blank"><i class="icon icon-social-twitter"></i></a>
                            <a class="google" href="http://plus.google.com/share?url='.$actual_link.'post/'.$blog[$i]['LINK'].'" target="_blank"><i class="icon icon-social-google"></i></a>
                            <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url='.$actual_link.'post/'.$blog[$i]['LINK'].'&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
                            <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url='.$actual_link.'post/'.$blog[$i]['LINK'].'&media=http://missfashionweekafrica.com/images/playvideo.png" target="_blank"><i class="icon icon-social-pinterest"></i></a>
                        </section>';
                        ?>
                        <div class="col-sm-5">
                            <?php
                            $commentCount = $mfdb->query("SELECT * FROM blogcomments WHERE postId='$blogId'");
                            ?>
                            <a href="post/<?php echo str_replace(' ', '_', strtolower($blog[$i]['LINK'])); ?>#comments" class="comments"><i class="icon icon-speech"> </i>&nbsp; <?php echo mysqli_num_rows($commentCount); ?> Comments</a>
                        </div>
                        <div class="clearfix"></div>
                        <a class="openPost col-sm-4 col-xs-6 center-block" href="post/<?php echo str_replace(' ', '_', strtolower($blog[$i]['LINK'])); ?>">Read More</a>
                    </div>
                </div>
                <div class="col-sm-1"></div>

            <?php } ?>
        <?php } ?>


        <?php if (isset($_POST['blog'])) { ?>

            <?php
            $vb = $_POST['blog'];
            $gpp = $mfdb->query("SELECT * FROM blog WHERE title LIKE '%$vb%' OR tag LIKE '%$vb%'  OR content LIKE '%$vb%'  OR date LIKE '%$vb%' ORDER BY id DESC");
            $bl = array();
            while ($ap = $gpp->fetch_assoc()) {
                $bl[] = array(
                    'ID' => $ap['id'],
                    'TITLE' => $ap['title'],
                    'TAG' => $ap['tag'],
                    'PICTURE' => $ap['picture'],
                    'CONTENT' => $ap['content'],
                    'DATE' => $ap['date'],
                    'LINK' => str_replace(' ', '_', strtolower($ap['title'])) . '.html'
                );
            }

            for ($i = 0; $i < count($bl); $i++) {
                $blogId = $bl[$i]['ID'];
                echo '<div class="blog col-sm-5">
                    <span class="tag"><i class="icon icon-tag"></i> ' . $bl[$i]['TAG'] . '</span>
                    <h3 class="title">' . substr($bl[$i]['TITLE'], 0, 30) . '...</h3>
                    <span class="tag"><i class="icon icon-calendar"></i> ' . $bl[$i]['DATE'] . '</span>
                    <img src="../images/' . $bl[$i]['PICTURE'] . '" alt="" />
                    <div class="text lead">
                        ' . substr($bl[$i]['CONTENT'], 0, 100) . '...
                        <section class="social">
                            <a class="social"><i class="icon icon-social-facebook"></i></a>
                            <a class="social"><i class="icon icon-social-youtube"></i></a>
                            <a class="social"><i class="icon icon-social-google"></i></a>
                            <a class="social"><i class="icon icon-social-twitter"></i></a>
                            <a class="social"><i class="icon icon-social-instagram"></i></a>
                        </section>';
                ?>
                <div class="col-sm-5">
                    <?php
                    $commentCount = $mfdb->query("SELECT * FROM blogcomments WHERE postId='$blogId'");
                    ?>
                    <a href="post/<?php echo str_replace(' ', '_', strtolower($bl[$i]['LINK'])); ?>#comments" class="comments"><i class="icon icon-speech"> </i>&nbsp; <?php echo mysqli_num_rows($commentCount); ?> Comments</a>
                </div>
                <div class="clearfix"></div>
                <a class="openPost col-sm-4 col-xs-6 center-block" href="post/<?php echo str_replace(' ', '_', strtolower($bl[$i]['LINK'])); ?>">Read More</a>
            </div>
        </div>
        <div class="col-sm-1"></div>
        
    <?php } ?>
        <?php
        if (count($bl) === 0) {
            echo '<h1>No results found</h1> <br/><a href="">Back to All Blog Posts</a><br/><br/>';
        }
        ?>
<?php } ?>




</div>


</div>
<div class='clearfix'></div>






<section class="footer">

    <div class="col-sm-3 subscriber">
        <form>
            <div class="text lead">
                Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
            </div>
            <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
            <input type="text" name="" placeholder="Email" id="subscribeMail"/>
            <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
        </form>

        <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
    </div>


    <div class="col-sm-5" id="footerMap">
        <h4>We Are Around the globe</h4>
    </div>
    <div class="col-sm-4 fromBlog">
        <h4>From The Blog</h4>
        <div class='clearfix'></div>
        <?php
        $dbc = new dataBaseContent();
        $blog = $dbc->getPosts();
        $count = count($blog);
        if (count($blog) > 3) {
            $count = 3;
        }

        for ($i = 0; $i < $count; $i++) {
            echo '<a href="../blog/post/' . $blog[$i]['LINK'] . '">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/' . $blog[$i]['PICTURE'] . '" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
        }
        ?>
    </div>

    <div class="clearfix"></div>
    <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
    <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
</section>

<script src="../js/jquery.js"></script>
<script src="../js/flick.js"></script>
<script src="../js/plugins.js"></script>
<script src="../js/jquery.vmap.js" type="text/javascript"></script>
<script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
<script type="text/javascript">
    $('.submitPre').click(function(e) {
        e.preventDefault();
        var fname = $('#fn').val();
        var lname = $('#ln').val();
        var em = $('#em').val();
        var sq = $('#sq').val();
        var sa = $('#sa').val();
        if (fname.length > 0 && lname.length > 0 && em.length > 0 && sa.length > 0 && sq.length > 0) {
            $('.regError').fadeOut(1000);
            xhttp.onreadystatechange = function() {
                if (xhttp.readyState === 4 && xhttp.status === 200) {
                    var res = xhttp.responseText;
                    if (res === '2') {
                        $('.regError').text('An account already created for "' + em + '".If you are the owner of this account, please wait for you payment to be confirmed and a password sent to your email. Thank you');
                        $('.regError').fadeIn(1000);
                    }
                    else if (res === '0') {
                        $('.regError').text('Account could not be created. If this problem persists please contact our officials at kenny@mfmail.com');
                        $('.regError').fadeIn(1000);
                    }
                }
            };
            xhttp.open("GET", "../handler.php?preReg&email=" + em + "&fname=" + fname + "&lname=" + lname + "&sa=" + sa + "&sq=" + sq, true);
            xhttp.send();
        }
        else {
            $('.regError').fadeIn(1000);
        }
    });
    $('#subscribeButton').click(function() {
        var name = $(this).parent().find('#subscribeName').val();
        var email = $(this).parent().find('#subscribeMail').val();
        if (name.length > 0 && email.length > 0) {
            $('#subscribeName').css('border-color', 'green');
            $('#subscribeMail').css('border-color', 'green');
            if (email.indexOf('.com') !== -1 && email.indexOf('@') !== -1) {
                xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        $('.subs').css('display', 'block');
                    }
                };
                xhttp.open("GET", "../handler.php?subscribe&email=" + email + "&name=" + name, true);
                xhttp.send(null);
            }
            else {
                $('#subscribeMail').css('border-color', 'red');
            }
        }
        else {
            $('#subscribeName').css('border-color', 'red');
            $('#subscribeMail').css('border-color', 'red');
        }
    });
</script>

</body> 
<div class="contactMsgi subs animated bounceInUp col-sm-4">
    <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
    <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
    <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
    <br>
    <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
    <br><br>
</div>


<div class="sideSocials blogSocial">
    <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
    <span>SHARE</span>
    <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-facebook"></i></a>
    <a class="google" href="http://plus.google.com/share?url=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-google"></i></a>
    <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link ?>&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
    <a class="twitter" href="http://www.twitter.com/<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-twitter"></i></a>
    <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url=<?php echo $actual_link ?>&media=http://missfashionweekafrica.com/images/mf.jpg" target="_blank"><i class="icon icon-social-pinterest"></i></a>

    <span class="co cl" data-action="close" title="Close Share Panel"><i class="icon icon-control-forward"></i><i class="icon icon-control-forward"></i></span>
    <span class="co op" data-action="open" title="Open Share Panel"><i class="icon icon-control-rewind"></i><i class="icon icon-control-rewind"></i></span>
</div>
<div class="minnav">
    <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
</div>  

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        <script src="../js/main.js"></script>

</html>
