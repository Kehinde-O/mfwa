<?php
include '../handler.php';
$refe = 'MFWA_' . rand(1234, 9999);
$characters = "1234567890ABCFGHIJKLMNPQRSTVWXYZabcdfghijklmnpqrstvwxyz";
$string = '';
$password = '';
$error = '';
$nextDay = date('d/m/Y', strtotime(' +1 day'));
/* echo 'Day: '.date('d');
  $day = '30'/*date('d');
  $month = date('m');
  $year = date('Y');
  $nextDay='';$nextMonth='';$nextYear='';
  echo ' Month: '.date('m');
  echo ' Year: '.date('Y');

  if(date('L', mktime(0, 0, 0, 1, 1, $year))){

  $nextDay = $day+2;
  $nextMonth = $month;
  $nextYear = $year;
  if($day === '29' && $month ==='02'){
  $nextDay = '02';
  $nextMonth = $month+1;
  $nextYear = $year;
  }
  if($month === '09' || $month === '04' || $month === '05' || $month === '11' && $day === '30'){
  $nextDay = '02';
  $nextMonth = $month+1;
  $nextYear = $year;
  }
  if($month === '09' || $month === '04' || $month === '05' || $month === '11' && $day === '29'){
  $nextDay = '01';
  $nextMonth = $month+1;
  $nextYear = $year;
  }
  if($month === '09' || $month === '04' || $month === '05' || $month === '11' && $day !== '29' || $day !=='29'){
  $nextDay = $day+2;
  $nextMonth = $month;
  $nextYear = $year;
  }
  if($month === '12' && $day === '31'){
  $nextDay = '02';
  $nextMonth = '01';
  $nextYear = $year+1;
  }
  if($day === '31' && $month !=='12'){
  $nextDay = '02';
  $nextMonth = $month+1;
  $nextYear = $year;
  }
  } */

$max = strlen($characters) - 1;
for ($i = 0; $i < 12; $i++) {
    $string .= $characters[mt_rand(0, $max)];
}
for ($i = 0; $i < 12; $i++) {
    $password .= $characters[mt_rand(0, $max)];
}
//if($mfdb->query("INSERT INTO "))
$pw = md5($password);
if (isset($_POST['save'])) {
    $fbid = $_POST['quickid'];
    $em = $_POST['em'];
    $fn = $_POST['fn'];
    $ln = $_POST['ln'];
    $ad = $_POST['ad'];
    $co = $_POST['co'];
    $pn = $_POST['pn'];
    $st = $_POST['st'];
    $str = $_POST['str'];
    $ref = $_POST['refno'];
    $thisyear = date("Y");
    $thismonth = date("M");
    $date = date('d-m-Y');
    $time = date('h:m a');
    $ckk = $mfdb->query("SELECT * FROM quickform WHERE email='$em'");
    if (mysqli_num_rows($ckk) > 0) {
        $error = '<div class="col-sm-12 text-danger" style="padding:12px;background:#fff;border:1px #ebebeb solid;margin-bottom:10px;">A user with this email already registered. if this email belongs to you, please always check your email for further instructions to continue your application process.</div>';
    } else {
        if(is_file('../videos/'.$ref.'_Cat_Walk_Video.mp4')){
        if ($mfdb->query("INSERT INTO quickform (firstName,lastName,email,address,phone,country,state,reference,fbid,pw,accountStatus,accountSetup,password,securityQuestion,securityAnswer,applied,secondmedia,thirdmedia,lastmedia,appprocess,nextDate,step,nextMsg,profilecount)"
                        . "VALUES ('$fn','$ln','$em','$ad','$pn','$co','$st','$ref','$fbid','$password','NotVerified','false','$pw','','','false','false','false','false','false','$nextDay','1','false','0')")) {
            $getv = $mfdb->query("SELECT * FROM statistics WHERE data='newmembers' AND monthname='$thismonth' AND year='$thisyear'")->fetch_assoc();
            $oldv = $getv['value'] + 1;
            $mfdb->query("UPDATE statistics SET value='$oldv' WHERE data='newmembers' AND monthname='$thismonth' AND year='$thisyear'");
            $filename = $ref . '_Cat_Walk_Video.mp4';
            $mfdb->query("INSERT INTO videos "
                    . "(reference,firstName,lastName,time,date,videoName,applicationStep,shortLink,videoReference,judged,judgedby,linked) "
                    . "VALUES('$ref','$fn','$ln','$time','$date','Cat Walk Video for $fn $ln','1','$string','$filename','false','','true')");

            //$mfdb->query("INSERT INTO useraccount(email,password,reference,nextDate) VALUES('$em','$pw','$ref','$nextDay')");
            $mailmsg = '<img alt="" src="http://missfashionweekafrica.com/officials/images/site.png"><br><br>Dear ' . $fn . ' ' . $ln . ',<br/><br/>Your quick entry form has successfully been submitted, your Quick ID is: "<b>' . $fbid . '</b>" and your Reference Number is: "<b>' . $ref . '</b>". <br/><br/> We have received your video, within 24hrs our judges will review your submission. If you qualify, you '
                    . 'will receive your Login information and further instructions regarding your application.'
                    . '<br/><br/>Have any questions? Email us at team@missfashionweekafrica.com<br/><br/>Thanks,<br/><br/>Miss Fashion Week Africa.';
            $headers = "From: support@missfashionweekafrica.com \r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            mail($em, 'Quick Entry Form was successful-MissFashionWeekAfrica', $mailmsg, $headers);
            header('location:https://www.facebook.com/sharer/sharer.php?u=http://missfashionweekafrica.com/videos/?watch=' . $str . '&player=true');
        }
        }else{
        $error = '<div class="col-sm-12 text-danger" style="padding:12px;background:#fff;border:1px #ebebeb solid;margin-bottom:10px;">Sorry, your video was not properly uploaded. Please choose and upload video again.</div>';
    }
    }


    //unset($_POST['save']);
}
?>
<html>
    <head>
        <title>Quick Form - Miss Fashion Week Africa</title>
        <link rel="stylesheet" href="../css/main.css"/>
        <link rel="icon" href="../images/mf.jpg" />
        <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../fonts/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/simple-line-icon.css" rel="stylesheet" type="text/css"/>
        <link href="../css/animate.min.css" rel="stylesheet" type="text/css"/>
        <link href="../js/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet" type="text/css"/>
        <link rel="icon ico" href="../images/mf.jpg">
        <meta charset="UTF-8">
        <style>
            .fb-login-button{
                //display:block !important;
                float:none !important;
                //margin:10px auto !important;
                //padding:10px 0px;
            }
            .status{
                text-align: center;
                padding:10px 0px;
            }
            .center-block{
                display:block;
                float:none !important;
                margin:auto;
            }
            .input-div{
                padding:0px;
                margin-bottom: 30px;
            }
            .input-div input,
            .input-div textarea,
            .input-div select,
            .input-div button{
                display:block;
                width:100%;
                padding:5px 8px;
                outline-color: rgba(0,0,0,0);
                transition:all .30s ease;
            }

            form{
                margin-top:50px !important;
                font-family:'Oswald-Regular';
                background:#f7f7f7;
                overflow:hidden;
                position: relative;
                padding:30px;
            }
            form label{
                font-weight:100;
            }
            .radio-btn{
                padding:5px;
                transition:all .5s ease;
                cursor:pointer;
                text-align:left;
                cursor:pointer;
                padding-left:20px;
            }
            .radio-btn input{
                width:10px;
                float:left;
                padding:5px;
                display:block;
                border-width:1px;
                border-style:solid;
            }
            .radio-btn.active{
                background:#fff;
            }
            .radio-btn:hover{
                background:#f1f1f1;
            }
            .radio-child{
                padding:0px;
            }
            .radio-btn label{
                margin-top:5px;
                font-size:smaller;
            }
            .fbImg{
                max-height:90px;
                max-width:100px;
                position:absolute;
                bottom:0px !important;
                right:-20px;
            }
            .image{
                border-top:1px #ccc solid;
            }
            .image img{
                max-height:500px;
                margin:20px auto;
                float:none;
                display:block;
                opacity: .5;
            }
            .spanTitle{
                font-size:small;
                font-family:'Open sans';
                color:#888;
                display:block;
                font-weight:400;
                padding:5px;
            }
            .save{
                border-radius: 0px;
            }
            .textfw{
                padding:0px;
                margin:30px auto;

            }
            .title{
                color:#444;
                font-family:'Oswald-Regular';
                margin:0px;
                margin-top:20px;
            }
            .save{
                //display:none;
            }
        </style>
    </head>
    <body onload="checkLoginState();">
        <div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-3 col-xs-12'>QUICK ENTRY FORM</h2>
            <span class=" col-sm-5 col-xs-12" pull-right>
                <span class="status col-xs-8"></span> 
                <img class="fbImg col-xs-4 pull-right" />
            </span>
        </section>
        <?php if(1===0){ ?>
        <div class="col-sm-6 col-xs-11 center-block">
            <h3 class="title">Miss Fashion Week Africa Quick Entry Form <div class="fb-login-button col-sm-1 col-xs-3" data-max-rows="1" data-size="medium" data-show-faces="false" data-auto-logout-link="true"></div></h3>
            <div class="textfw col-sm-12">
                To compete in the Miss Fashion Week Africa contest you must first qualify by submitting a
                video that is not more than 60 seconds;
                <br/><br/>
                <ul>
                    <li>Telling us your name and country and showing us your best catwalk.</li>
                </ul>
                Video submissions will be shared on your Facebook Page with the hashtag #IamMissFashionWeek.<br/><br/>
                Ask your friends and family to like your video.
                <br/><br/>
                Qualifying models will receive an invitation via email to apply in order to contest for the
                $3000 cash prize and a chance to win $5,000 at the grand finale in Florida, USA.
                <br/><br/>
                <b>Note:</b> After filling the bellow form, click on the Complete and Share button, you would be led to a Facebook share page, make sure you write #IamMissFashionWeek in the "Say Something" section before sharing your video submission.
            </div>
        </div>
        <form class="col-sm-6 col-xs-11 center-block" method="post" action="">
            <?php echo $error ?>
            <div class="col-sm-5 pull-left col-xs-12 input-div">
                <label>First Name</label>
                <input type="text" id="fn" placeholder="First Name" required class="il" name="fn"/>
            </div>

            <div class="col-sm-5 pull-right col-xs-12 input-div">
                <label>Last Name</label>
                <input type="text" id="ln" placeholder="Last Name" required class="il" name="ln"/>
            </div>
            <div class="clearfix"></div>

            <div class="col-sm-5 pull-left col-xs-12 input-div">
                <label>Email Address</label>
                <span class="spanTitle">Winner will be contacted by email.</span>
                <input type="email" id="em" placeholder="Email Address" required class="il" name="em"/>
            </div>

            <div class="col-sm-5 pull-right col-xs-12 input-div">
                <br/>
                <label>Phone Number</label>
                <input type="number" id="phone" placeholder="Phone Number" required class="il" name="pn"/>
            </div>
            <div class="clearfix"></div>

            <div class="col-sm-5 pull-left col-xs-12 input-div">
                <label>Country</label>
                <select name="co" id="country" required class="il"></select>
            </div>

            <div class="col-sm-5 pull-right col-xs-12 input-div">
                <label>State</label>
                <select name="st" id="state" required class="il" ></select>
            </div>
            <div class="clearfix"></div>

            <div class="col-sm-12 col-xs-12 input-div">
                <label>Full Address *</label>
                <input type="text" id="address" placeholder="Full Address" required class="il" name="ad" />
            </div>
            <div class="clearfix"></div>

            <div class="col-sm-12 col-xs-12 input-div">
                <label>Quick ID *</label>
                <span class="spanTitle">Please jot this ID as it will be useful for qualification.</span>
                <input type="text" id="" placeholder="Quick ID Or FB ID" class="il fbid" name="" disabled/>
                <input type="hidden" id="fbid" placeholder="Quick ID" class="il" name="quickid"/>
            </div>

            <div class="col-sm-12 col-xs-12 input-div">
                <label>Your Reference Number *</label>
                <span class="spanTitle">Please jot this REFERENCE NUMBER as it will be useful during the contest.</span>
                <input type="text" placeholder="Reference Number" class="il" name="r" value="<?php echo $refe ?>" disabled/>
                <input type="hidden" id="ref" placeholder="Reference Number" class="il" name="refno" value="<?php echo $refe ?>"/>
                <input type="hidden" id="ref" placeholder="str" class="il" name="str" value="<?php echo $string ?>"/>
            </div>
            <div class="clearfix"></div>

            <div class="col-sm-12 image accountForms">
                <label>Upload Video</label>
                <span class="spanTitle">
                    Please note that you must fill up the form above and upload a 60 seconds video, showing your runway catwalk, introducing
                    yourself briefly and telling us why you feel you have what it takes to win Miss Fashion Week Africa
                    <br/><b>Video Uploading can not be completed without filling up the form above</b>
                    <br/><br/>
                    <div class="text-danger well text-well invalidvideo" style="display:none;">Invalid Video Format, Please select another video only in .MP4 format</div>
                </span>
                <label for="beauty" class="chooseLabel">Choose File
                    <div id="progress" class="progress">
                        <div class="progress-bar progress-striped progress-bar-success" style='width:0%;'></div>
                    </div>
                </label>
                <input type='file' class='col-sm-12 col-xs-12 videoChoose' id='beauty' name='files' disabled/>
            </div>
            <div class="clearfix"></div>
            <button class="btn btn-primary col-sm-12 col-xs-12 save" type="submit" name="save" disabled>Complete and share</button>
        </form> <?php } else{?>
        
        <div class="col-sm-6 col-xs-11 center-block">
            <h3 class="title">Miss Fashion Week Africa Quick Entry Form <div class="fb-login-button col-sm-1 col-xs-3" data-max-rows="1" data-size="medium" data-show-faces="false" data-auto-logout-link="true"></div></h3>
            <div class="textfw col-sm-12">
                Entry Form Closed.
            </div>
        </div>
        
        <?php }?>
    </body>


    <script src="../js/jquery.js" type="text/javascript"></script>
    <script src="../js/countries.js" type="text/javascript"></script>
    <script src="../js/jquery.ui.widget.js" type="text/javascript"></script>
    <script src="../js/jquery.fileupload.js" type="text/javascript"></script>
    <script>
        $('form input').blur(function(){
           var fnn = $('#fn').val();
           var ln = $('#ln').val();
           if(fnn.length < 1 && ln.length < 1){
               $('#beauty').prop('disabled',true);
           }
           else{
               $('#beauty').prop('disabled',false);
           }
        });
        $('.save').prop('disabled', true);
        var ref = '<?php echo $refe ?>';
        var shortUrl = '<?php echo $string ?>';
        $('#ref').val('<?php echo $refe ?>');
        var firstName, lastName, email, gender, ageMax, picture, id, modelcat, country, state, address, phone, videourl;
        function statusChangeCallback(response) {
            if (response.status === 'connected') {
                //$('.save').prop('disabled', false);
                testAPI();
            } else if (response.status === 'not_authorized') {
                document.getElementById('status').innerHTML = 'Please log ' + 'into this app.';
            } else { //document.getElementById('status').innerHTML = 'Please log ' + 'into Facebook.';
                $('.status').html('Please Login To Facebook to continue and refresh this page after login');
                firstName, lastName, email, gender, ageMax, picture, id = '';
                $('.fbImg').attr('src', '');
                //$('.save').prop('disabled', true);
            }
        }
        function checkLoginState() {
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
                responseold = response.status;
            });
        }


        window.fbAsyncInit = function() {
            FB.init({
                appId: '308022776226378',
                cookie: true, // enable cookies to allow the server to access 
                statue: true, // the session
                xfbml: true, // parse social plugins on this page
                version: 'v2.5' // use graph api version 2.5
            });
            FB.getLoginStatus(function(response) {
                statusChangeCallback(response);
                responseold = response.status;
            });

        };

        (function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id))
                return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));


        function testAPI() {
            FB.api('/me', {fields: 'first_name,last_name,email,gender,age_range,picture,id'}, function(response) {
                firstName = response.first_name;
                if (firstName === undefined) {
                    firstName = $('#fn').val();
                }
                lastName = response.last_name;
                if (lastName === undefined) {
                    lastName = $('#ln').val();
                }
                email = response.email;
                if (email === undefined) {
                    email = $('#em').val();
                }
                gender = response.gender;
                ageMax = response.age_range.max;
                picture = response.picture.data.url;
                if (response.id === undefined) {
                    id = $('#fbid').val();
                }
                else {
                    id = response.id;
                }
                $('.status').html('Logged In as ' + firstName + ' ' + lastName);
                $('.fbImg').attr('src', picture);
                $('#fn').val('' + firstName);
                $('#ln').val('' + lastName);
                $('#em').val('' + email);
                $('#fbid').val('' + id);
                $('.fbid').val('' + id);
            });

        }


        populateCountries('country', 'state');
        $('.status').html('Logging in to Facebook...');


        $(function() {
            'use strict';
            $('#country').change(function() {
                country = $(this).val();
            });
            $('#state').change(function() {
                state = $(this).val();
            });
            $('#address').blur(function() {
                address = $(this).val();
            });
            $('#phone').blur(function() {
                phone = $(this).val();
            });
            
            $('.videoChoose').click(function(){
                firstName = $('#fn').val();
                lastName = $('#ln').val();
            });
            
            var abort = true;
            $('.videoChoose').change(function(e){
                var nf = $(this).val();
                if(nf.indexOf('.mp4') ===-1){
                    //alert('Invalid Video Format');
                    $('.invalidvideo').fadeIn(1000);
                }else{
                    abort = false;
                    $('.invalidvideo').fadeOut(1000);
                }
            });

            // Change this to the location of your server-side upload handler:
            var url = window.location.hostname === 'upload.php' ?
                    '//jquery-file-upload.appspot.com/' : 'upload.php';
            $('.videoChoose').fileupload({
                url: url,
                done: function(e, data) {
                    $(this).parent().css('opacity', .9);
                    $(this).parent().addClass('uploaded');
                    $(this).parent().find('#progress .progress-bar').text('Upload Completed, Click Here to change.');
                    $('.save').fadeIn(1000);
                    $('.save').prop('disabled', false);
                    abort = true;
                },
                start: function(e, data) {
                    if(abort === true){data.abort();$(this).parent().find('#progress').fadeOut(1000);}
                    $(this).parent().find('#progress').fadeIn(1000);
                },
                progressall: function(e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    $(this).parent().find('#progress .progress-bar').css(
                            'width',
                            progress + '%'
                            );
                    $(this).parent().find('#progress .progress-bar').text('Please wait... '+progress + '%');
                }
            }).bind('fileuploadsubmit', function(e, data) {
                data.formData = {reference: ref};
            });
        });

        //$('.save').prop('disabled', true);

        function gri(min, max) {
            min = Math.ceil(min);
            max = Math.floor(max);
            return Math.floor(Math.random() * (max - min)) + min;
        }
    </script>

    <div class="sideSocials blogSocial">
<?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
        <span>SHARE</span>
        <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-facebook"></i></a>
        <a class="google" href="http://plus.google.com/share?url=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-google"></i></a>
        <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link ?>&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
        <a class="twitter" href="http://www.twitter.com/<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-twitter"></i></a>
        <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url=<?php echo $actual_link ?>&media=http://missfashionweekafrica.com/images/mf.jpg" target="_blank"><i class="icon icon-social-pinterest"></i></a>

        <span class="co cl" data-action="close" title="Close Share Panel"><i class="icon icon-control-forward"></i><i class="icon icon-control-forward"></i></span>
        <span class="co op" data-action="open" title="Open Share Panel"><i class="icon icon-control-rewind"></i><i class="icon icon-control-rewind"></i></span>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div> 
    <script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="../js/bootstrap-sweetalert/sweet-alert.min.js" type="text/javascript"></script>
    <script src="../js/main.js"></script>
</html>