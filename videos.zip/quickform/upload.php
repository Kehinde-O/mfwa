<?php
include '../handler.php';
$file = $_FILES['files']['tmp_name'];
$file_name = $_FILES['files']['name'];
$ext = explode('.',$file_name);
$end = '';
if(count($ext) > 0){
    $end = array_pop($ext);
}
$filename = $_REQUEST['reference'].'_Cat_Walk_Video.mp4';
$date = date('d-m-Y');
$time = date('h:m a');

$dir = '../videos/';
if(!is_dir($dir)){
    mkdir($dir);
}
    move_uploaded_file($file,'../videos/'.$filename);

