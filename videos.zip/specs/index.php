<?php
    include '../handler.php';

?>
<!DOCTYPE html>
<!--
This Application is created by kehinde omotoso.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>IMAGE AND VIDEO SPECIFICATION - Miss Fashion Week Africa</title>
        <meta name="description" content="">
        <!-- <meta name="author" content="Kehinde Omotoso"> -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">


        <link rel="stylesheet" href="../css/normalize.css">
        <link rel="stylesheet" href="../css/simple-line-icon.css">
        <link rel="stylesheet" href="../css/animate.min.css">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../fonts/font-awesome.css">
        <link rel="stylesheet" href="../fonts/source-sans-pro.css">
        <link rel="stylesheet" href="../css/flick.css">
        <link href="../css/jqvmap.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../css/main.css">
        <link rel="icon ico" href="../images/mf.jpg">
    </head>
    <!--[if lt IE 7]>
        <p class="chromeframe">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> or <a href="http://www.google.com/chromeframe/?redirect=true">activate Google Chrome Frame</a> to improve your experience.</p>
    <![endif]-->
    <body><div class="pageloader"><img src="../images/mf.jpg" alt="" class="animated"/>Loading...</div>

        <div class="memberPanel">
            <ul>
                <li class="col-sm-1 col-xs-2 pull-left" title="How To"><a href="../help/"><i class="icon icon-question"></i>&nbsp; Help</a></li>
                <li class="col-sm-2 col-xs-6 pull-right"><div id="google_translate_element"></div></li>
                <li class="col-sm-1 col-xs-4 pull-right"><a href="../join/"><i class="icon icon-login"></i>&nbsp; Login</a></li>
            </ul>
        </div>
        <header class="header animated">
            <nav class="navigation">
                <img src="../images/mf.jpg" alt="MissFashionWeekAfrica"/>
                <ul>
                    <li><a href="../">Home</a></li>
                    <li><a href="../models/">Models</a>
                        <div class="animated bounceInDown">
                            <a href="../models/">Contestants</a>
                            <a href="../quickform/">Entry Form</a>
                            <a href='../howitworks/'>HOW IT WORKS</a>
                            <a href="../specs/">IMAGE AND VIDEO SPECIFICATION</a>
                            <a href="../rules/">RULES AND REGULATIONS</a>
                        </div>
                    </li>
                    <li><a href="../judges/">Our Judges</a></li>
                    <li><a href="../contact/">Contact Us</a></li>
                    <li><a href="../about/">About Us</a></li>
                    <li><a href="../blog/">Blog</a></li>
                    <li><a href="../videos/">Videos</a></li>
                </ul>
                <div class="drop">
                    <span class="line"></span>
                    <span class="line"></span>
                    <span class="line"></span>
                </div>
            </nav>
        </header>
        <section class='accountHeader'>
            <h2 class='col-sm-5 col-xs-12'>IMAGE AND VIDEO SPECIFICATION</h2>
        </section>

        <div class='account howitworks col-sm-10 col-xs-11 center-block'>
            <br/>
            <div class='col-sm-12 col-xs-12 accountForms center-block'>
                <h4 class='title'>IMPORTANT NOTICE</h4>
                "Please take the following images using a normal point and shoot digital camera or good quality camera phone.
                The images must be in colour and must NOT be manipulated or photo-shopped at all. 

                Please do not wear make up or hair products as we would like to see you as naturally as possible.
                Try to take the images against a plain background"
                <div class="clearfix"></div>
            </div>
            <br/><br/>
            <div class="clearfix"></div>
            <div class='col-sm-6 col-xs-12 accountForms pull-left'>
                <h4 class='title'>HEADSHOT FRONT VIEW (White Background)</h4>
                Head Shot photo showing your front face view, if you 
                have long hair please hold it away from your face for a shot.
                <br/><b>Samples:</b>
                <div class="clearfix"></div>
                <br/>
                <img src="../images/specs/front.JPG"/>
            </div>

            <div class='col-sm-6 col-xs-12 accountForms pull-right'>
                <h4 class='title'>HEADSHOT SIDE VIEW (White Background)</h4>
                Head Shot photo showing your side face view, if you 
                have long hair please hold it away from your face for a shot.
                <br/><b>Sample:</b>
                <div class="clearfix"></div>
                <br/>
                <img src="../images/specs/side.JPG"/>
                
            </div>
            <div class="clearfix"></div>

            <div class='col-sm-6 col-xs-12 accountForms pull-left'>
                <h4 class='title'>FULL LENGHT FRONT VIEW</h4>
                This is a picture showing the models full body front view, preferable standing in front of a clear background
                -studio style with NO MAKE-UP
                <b>Samples:</b>
                <div class="clearfix"></div>
                <br/>
                <img src="../images/specs/fullfront.JPG"/>
                <br/><br/>
            </div>
            
            <div class='col-sm-6 col-xs-12 accountForms pull-right'>
                <h4 class='title'>FULL LENGTH SIDE VIEW.</h4>
                This is a picture showing the models full body side view, preferable standing in front of a clear background
                -studio style with NO MAKE-UP
                <b>Samples:</b>
                <div class="clearfix"></div>
                <br/>
                <img src="../images/specs/fullside.JPG" />
                <br/><br/>
            </div>
            <div class="clearfix"></div>
            
            <div class='col-sm-12 col-xs-12 accountForms pull-right'>
                <div class="col-sm-6">
                <h4 class='title'>SWIM WEAR PICTURE.</h4>
                This is a picture of the model wearing a decent swimwear, such as bikinis.
                <b>Samples:</b>
                <div class="clearfix"></div>
                <br/>
                </div>
                <div class="col-sm-6">
                    <img src="../images/specs/swimsuit.jpg" />
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="clearfix"></div>
            <br/><br/><br/><br/>
            <div class='col-sm-12 col-xs-12 accountForms pull-right'>
                <h4 class='title'>Video Interview Upload</h4>
                Contestants must upload a 60 seconds video.
                <br/>
                In one short sentence tell us why you should win the Miss Fashion Week Africa.<br/>
                <div class="clearfix"></div>
            </div>

            <div class="clearfix"></div>
        </div>
        
        
        <div class='clearfix'></div>
        

        <section class="footer">

            <div class="col-sm-3 subscriber">
                <form>
                    <div class="text lead">
                        Subscribe to our newsletter to get updates on the Miss Fashion Week contest.
                    </div>
                    <input type="text" name="" placeholder="Full Name" id="subscribeName"/>
                    <input type="text" name="" placeholder="Email" id="subscribeMail"/>
                    <button type="button" id="subscribeButton" class="btn btn-primary">Subscribe</button>
                </form>

                <section class="social con">
                    <h5>Connect with us</h5>
                    <a href="http://www.facebook.com/missfashionweekafrica" class="social"><i class="icon icon-social-facebook"></i></a>
                    <a href="https://www.youtube.com/channel/UCcJuF1fkq8tV3L8TnpK75tA" class="social"><i class="icon icon-social-youtube"></i></a>
                    <a href="http://www.pinterest.com/missfwafrica" class="social"><i class="icon icon-social-pinterest"></i></a>
                    <a href="http://www.twitter.com/missfwafrica" class="social"><i class="icon icon-social-twitter"></i></a>
                    <a href="http://www.instagram.com/missfashionweekafrica" class="social"><i class="icon icon-social-instagram"></i></a>
                    <a href="http://missfashionweekafrica.tumblr.com/" class="social"><i class="icon icon-social-tumblr"></i></a>
                </section>
            </div>


            <div class="col-sm-5" id="footerMap">
                <h4>We Are Around the globe</h4>
            </div>
            <div class="col-sm-4 fromBlog">
                <h4>From The Blog</h4>
                <div class='clearfix'></div>
                <?php
                $dbc = new dataBaseContent();
                $blog = $dbc->getPosts();
                $count = count($blog);
                if(count($blog) > 3){
                    $count = 3;
                }
                
                for ($i = 0; $i < $count; $i++) {
                    echo '<a href="../blog/post/'.$blog[$i]['LINK'].'">
                <div class="fBlogPost col-sm-10">
                <div class="col-sm-4 col-xs-4 image">
                    <img src="../images/'.$blog[$i]['PICTURE'].'" alt="" />
                </div>
                    <div class="col-sm-7 pull-right col-xs-7">
                        ' . $blog[$i]['TITLE'] . '
                    </div>
                </div></a>
                <div class="clearfix"></div>';
                }
                
                
                ?>
            </div>
            
            <div class="clearfix"></div>
            <div class="copy pull-left">&copy;2016 MISS FASHION WEEK AFRICA</div>
            <div class="designed pull-right">DESIGNED BY KEHINDE OMOTOSO</div>
        </section>

        <script src="../js/jquery.js"></script>
        <script src="../js/flick.js"></script>
        <script src="../js/plugins.js"></script>
        <script src="../js/jquery.vmap.js" type="text/javascript"></script>
        <script src="../js/jquery.vmap.world.js" type="text/javascript"></script>
        <script type="text/javascript">
            $('.submitPre').click(function(e){
                e.preventDefault();
                var fname = $('#fn').val();
                var lname = $('#ln').val();
                var em = $('#em').val();
                var sq = $('#sq').val();
                var sa = $('#sa').val();
                if(fname.length > 0 && lname.length > 0 && em.length > 0 && sa.length > 0 && sq.length > 0){
                    $('.regError').fadeOut(1000);
                    xhttp.onreadystatechange = function() {
                    if (xhttp.readyState === 4 && xhttp.status === 200) {
                        var res = xhttp.responseText;
                        if(res === '2'){
                            $('.regError').text('An account already created for "'+em+'".If you are the owner of this account, please wait for you payment to be confirmed and a password sent to your email. Thank you');
                            $('.regError').fadeIn(1000);
                        }
                        else if(res === '0'){
                            $('.regError').text('Account could not be created. If this problem persists please contact our officials at kenny@mfmail.com');
                            $('.regError').fadeIn(1000);
                        }
                    }
                };
                xhttp.open("GET", "../handler.php?preReg&email=" + em + "&fname=" + fname+"&lname="+lname+"&sa="+sa+"&sq="+sq, true);
                xhttp.send();
                }
                else{
                   $('.regError').fadeIn(1000);
                }
            });
            $('#subscribeButton').click(function(){
                var name = $(this).parent().find('#subscribeName').val();
                var email = $(this).parent().find('#subscribeMail').val();
                if(name.length >0 && email.length > 0){
                    $('#subscribeName').css('border-color','green');
                    $('#subscribeMail').css('border-color','green');
                    if(email.indexOf('.com') !==-1 && email.indexOf('@') !==-1){
                        xhttp.onreadystatechange = function(){
                      if(xhttp.readyState === 4 && xhttp.status === 200){
                          $('.subs').css('display','block');
                      }  
                    };
                    xhttp.open("GET","../handler.php?subscribe&email="+email+"&name="+name,true);
                    xhttp.send(null);
                    }
                    else{
                        $('#subscribeMail').css('border-color','red');
                    }
                }
                else{
                    $('#subscribeName').css('border-color','red');
                    $('#subscribeMail').css('border-color','red');
                }
            });
        </script>

    </body> 
    <div class="contactMsgi subs animated bounceInUp col-sm-4">
        <h3 class="title"><i class="icon icon-check"></i> SUBSCRIPTION</H3>
        <div class="cmt text-center">Thank you for subscribing to our newsletter. You will receive email of our contest and events. You can always un subscribe.</div>
        <button type="button" class="close-btn center-block col-sm-4 col-xs-5 btn btn-danger" onclick="closecms();">Close</button>
        <br>
        <div class="col-sm-12 text-center">Fashion Week Africa 2016.</div>
        <br><br>
    </div>
    
    
    <div class="sideSocials blogSocial">
        <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
        <span>SHARE</span>
        <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-facebook"></i></a>
        <a class="google" href="http://plus.google.com/share?url=<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-google"></i></a>
        <a class="linkedin" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $actual_link ?>&title=&summary=&source=" target="_blank"><i class="icon icon-social-linkedin"></i></a>
        <a class="twitter" href="http://www.twitter.com/<?php echo $actual_link ?>" target="_blank"><i class="icon icon-social-twitter"></i></a>
        <a class="pinterest" href="http://www.pinterest.com/pin/create/button/?url=<?php echo $actual_link ?>&media=http://missfashionweekafrica.com/images/mf.jpg" target="_blank"><i class="icon icon-social-pinterest"></i></a>
        
        <span class="co cl" data-action="close" title="Close Share Panel"><i class="icon icon-control-forward"></i><i class="icon icon-control-forward"></i></span>
        <span class="co op" data-action="open" title="Open Share Panel"><i class="icon icon-control-rewind"></i><i class="icon icon-control-rewind"></i></span>
    </div>
    <div class="minnav">
        <div class="menu_head"><i class="icon icon-menu"></i> MENU</div>
    </div>  
    
   
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
        <script src="../js/main.js"></script>
</html>
